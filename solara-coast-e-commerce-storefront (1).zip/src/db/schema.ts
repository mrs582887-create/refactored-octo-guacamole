import { pgTable, serial, text, varchar, integer, decimal, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import type { InferSelectModel } from "drizzle-orm";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  department: varchar("department", { length: 100 }).notNull().default("Electronics"),
  departmentSlug: varchar("department_slug", { length: 100 }).notNull().default("electronics"),
  image: text("image"),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  brand: varchar("brand", { length: 100 }).notNull().default("Solara Coast"),
  sku: varchar("sku", { length: 50 }).notNull().default(""),
  tagline: text("tagline"),
  description: text("description"),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  originalPrice: decimal("original_price", { precision: 12, scale: 2 }),
  categoryId: integer("category_id").references(() => categories.id),
  categorySlug: varchar("category_slug", { length: 100 }).notNull().default(""),
  categoryName: varchar("category_name", { length: 100 }).notNull().default(""),
  department: varchar("department", { length: 100 }).notNull().default("Electronics"),
  departmentSlug: varchar("department_slug", { length: 100 }).notNull().default("electronics"),
  featured: boolean("featured").default(false),
  newArrival: boolean("new_arrival").default(false),
  bestSeller: boolean("best_seller").default(false),
  trending: boolean("trending").default(false),
  flashDeal: boolean("flash_deal").default(false),
  imageMain: text("image_main").notNull(),
  images: text("images").array(),
  specs: text("specs").array(),
  colors: text("colors").array(),
  sizes: text("sizes").array(),
  tags: text("tags").array(),
  rating: decimal("rating", { precision: 3, scale: 1 }).notNull().default("4.5"),
  reviewCount: integer("review_count").notNull().default(0),
  stock: integer("stock").notNull().default(25),
  soldCount: integer("sold_count").notNull().default(0),
  deliveryDays: integer("delivery_days").notNull().default(3),
  returnDays: integer("return_days").notNull().default(7),
  warranty: varchar("warranty", { length: 100 }).default("No warranty"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id, { onDelete: "cascade" }),
  author: varchar("author", { length: 100 }).notNull(),
  avatar: text("avatar"),
  rating: integer("rating").notNull(),
  title: varchar("title", { length: 200 }),
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id, { onDelete: "cascade" }),
  author: varchar("author", { length: 100 }).notNull(),
  question: text("question").notNull(),
  answer: text("answer"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type OrderItem = {
  productId: number;
  name: string;
  slug: string;
  image: string;
  price: number;
  qty: number;
  color?: string;
  size?: string;
};

export type OrderAddress = {
  fullName: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
};

export type StatusEvent = { status: string; at: string; note?: string };

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderId: varchar("order_id", { length: 40 }).notNull().unique(),
  customerName: varchar("customer_name", { length: 120 }).notNull(),
  customerEmail: varchar("customer_email", { length: 200 }).notNull(),
  customerPhone: varchar("customer_phone", { length: 30 }).notNull().default(""),
  items: jsonb("items").$type<OrderItem[]>().notNull(),
  subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
  discount: decimal("discount", { precision: 12, scale: 2 }).notNull().default("0"),
  shipping: decimal("shipping", { precision: 12, scale: 2 }).notNull().default("0"),
  tax: decimal("tax", { precision: 12, scale: 2 }).notNull().default("0"),
  total: decimal("total", { precision: 12, scale: 2 }).notNull(),
  couponCode: varchar("coupon_code", { length: 40 }),
  paymentMethod: varchar("payment_method", { length: 40 }).notNull(),
  paymentMode: varchar("payment_mode", { length: 20 }).notNull().default("demo"),
  deliveryMethod: varchar("delivery_method", { length: 40 }).notNull().default("standard"),
  address: jsonb("address").$type<OrderAddress>().notNull(),
  status: varchar("status", { length: 40 }).notNull().default("Order Placed"),
  statusHistory: jsonb("status_history").$type<StatusEvent[]>().notNull().default([]),
  expectedDelivery: timestamp("expected_delivery"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const coupons = pgTable("coupons", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 40 }).notNull().unique(),
  type: varchar("type", { length: 20 }).notNull(), // percent | flat | freeship
  value: decimal("value", { precision: 12, scale: 2 }).notNull().default("0"),
  minOrder: decimal("min_order", { precision: 12, scale: 2 }).notNull().default("0"),
  maxDiscount: decimal("max_discount", { precision: 12, scale: 2 }),
  description: text("description"),
  active: boolean("active").notNull().default(true),
  isDemo: boolean("is_demo").notNull().default(true),
});

export const notificationLogs = pgTable("notification_logs", {
  id: serial("id").primaryKey(),
  orderId: varchar("order_id", { length: 40 }).notNull(),
  channel: varchar("channel", { length: 40 }).notNull(), // owner_webhook | customer_email
  recipient: text("recipient"),
  status: varchar("status", { length: 20 }).notNull(), // sent | simulated | failed
  subject: text("subject"),
  detail: text("detail"),
  payload: jsonb("payload"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 200 }).notNull().unique(),
  phone: varchar("phone", { length: 30 }).default(""),
  totalOrders: integer("total_orders").notNull().default(0),
  totalSpent: decimal("total_spent", { precision: 12, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type Category = InferSelectModel<typeof categories>;
export type Product = InferSelectModel<typeof products>;
export type Review = InferSelectModel<typeof reviews>;
export type Question = InferSelectModel<typeof questions>;
export type Order = InferSelectModel<typeof orders>;
export type Coupon = InferSelectModel<typeof coupons>;
export type NotificationLog = InferSelectModel<typeof notificationLogs>;
export type Customer = InferSelectModel<typeof customers>;
