import { db } from "./index";
import { categories, products, reviews, questions, coupons, orders, notificationLogs, customers } from "./schema";
import { DEPARTMENTS, PRODUCTS, POOLS, COUPONS, REVIEW_TEMPLATES, REVIEWERS, QA_TEMPLATES, slugify } from "./catalog";

export async function seed() {
  await db.delete(notificationLogs);
  await db.delete(orders);
  await db.delete(customers);
  await db.delete(questions);
  await db.delete(reviews);
  await db.delete(products);
  await db.delete(categories);
  await db.delete(coupons);

  // Categories
  const catMap = new Map<string, { id: number; slug: string; name: string; department: string; departmentSlug: string }>();
  for (const dept of DEPARTMENTS) {
    const pool = POOLS[dept.slug] || POOLS.essentials;
    let i = 0;
    for (const name of dept.categories) {
      const slug = slugify(name);
      const [row] = await db.insert(categories).values({ name, slug, department: dept.name, departmentSlug: dept.slug, image: pool[i % pool.length] }).returning();
      catMap.set(name, { id: row.id, slug, name, department: dept.name, departmentSlug: dept.slug });
      i++;
    }
  }

  // Products
  const poolCounters: Record<string, number> = {};
  let idx = 0;
  for (const p of PRODUCTS) {
    const cat = catMap.get(p.c);
    if (!cat) throw new Error(`Unknown category ${p.c}`);
    const pool = POOLS[cat.departmentSlug] || POOLS.essentials;
    const pc = poolCounters[cat.departmentSlug] ?? 0;
    poolCounters[cat.departmentSlug] = pc + 1;
    const main = p.img || pool[pc % pool.length];
    const gallery = p.imgs || [main, pool[(pc + 1) % pool.length], pool[(pc + 2) % pool.length]];
    const flags = p.f || "";
    const rating = (3.8 + ((idx * 7) % 13) / 10).toFixed(1);
    const reviewCount = 24 + ((idx * 37) % 880);
    const soldCount = 50 + ((idx * 53) % 4200);
    const stock = p.st ?? [25, 3, 0, 12, 5, 60, 8][idx % 7];
    const discount = Math.round(((p.o - p.p) / p.o) * 100);
    const description = p.d || `${p.n} by ${p.b} — ${p.tg} Designed for everyday life, it combines thoughtful materials with dependable performance. Backed by Solara Coast's easy returns and responsive support, it's a purchase you can feel good about. Save ${discount}% for a limited time.`;
    const [row] = await db.insert(products).values({
      name: p.n,
      slug: slugify(p.n),
      brand: p.b,
      sku: `SC-${cat.departmentSlug.slice(0, 3).toUpperCase()}-${String(1000 + idx)}`,
      tagline: p.tg,
      description,
      price: p.p.toFixed(2),
      originalPrice: p.o.toFixed(2),
      categoryId: cat.id,
      categorySlug: cat.slug,
      categoryName: cat.name,
      department: cat.department,
      departmentSlug: cat.departmentSlug,
      featured: flags.includes("F"),
      newArrival: flags.includes("N"),
      bestSeller: flags.includes("B"),
      trending: flags.includes("T"),
      flashDeal: flags.includes("D") || discount >= 35,
      imageMain: main,
      images: gallery,
      specs: p.s || ["Brand: " + p.b, "Category: " + cat.name, "Quality checked by Solara Coast"],
      colors: p.col || [],
      sizes: p.sz || [],
      tags: p.t || [],
      rating,
      reviewCount,
      stock,
      soldCount,
      deliveryDays: p.dd ?? (cat.departmentSlug === "grocery" ? 1 : 2 + (idx % 3)),
      returnDays: p.rd ?? (cat.departmentSlug === "fashion" ? 15 : 7),
      warranty: p.w || (cat.departmentSlug === "electronics" ? "1 Year Manufacturer Warranty" : "No warranty"),
    }).returning();

    // Reviews (3-4 per product)
    const count = 3 + (idx % 2);
    const reviewRows = [];
    for (let r = 0; r < count; r++) {
      const t = REVIEW_TEMPLATES[(idx + r) % REVIEW_TEMPLATES.length];
      const author = REVIEWERS[(idx * 3 + r) % REVIEWERS.length];
      reviewRows.push({ productId: row.id, author, avatar: `https://i.pravatar.cc/150?u=${encodeURIComponent(author)}`, rating: t.rating, title: t.title, comment: t.comment });
    }
    await db.insert(reviews).values(reviewRows);

    // Q&A (2 per product)
    const qa1 = QA_TEMPLATES[idx % QA_TEMPLATES.length];
    const qa2 = QA_TEMPLATES[(idx + 2) % QA_TEMPLATES.length];
    await db.insert(questions).values([
      { productId: row.id, author: REVIEWERS[(idx + 5) % REVIEWERS.length], question: qa1.q, answer: qa1.a },
      { productId: row.id, author: REVIEWERS[(idx + 8) % REVIEWERS.length], question: qa2.q, answer: qa2.a },
    ]);
    idx++;
  }

  await db.insert(coupons).values(COUPONS.map((c) => ({ ...c, active: true, isDemo: true })));

  console.log(`Seeded ${idx} products across ${catMap.size} categories.`);
}
