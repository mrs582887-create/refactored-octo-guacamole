import { Suspense } from "react";
import AdminClient from "./AdminClient";
import { getAdminStats, getAllProducts, getAllOrders, getAllCategories, getAllCoupons, getNotificationLogs, getAllCustomers, getAllReviews } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const [stats, products, orders, categories, coupons, logs, customers, reviews] = await Promise.all([
    getAdminStats(), getAllProducts(), getAllOrders(), getAllCategories(), getAllCoupons(), getNotificationLogs(), getAllCustomers(), getAllReviews(),
  ]);
  return (
    <Suspense fallback={<div className="p-10 text-sm text-stone-500">Loading admin…</div>}>
      <AdminClient stats={stats} products={products} orders={orders} categories={categories} coupons={coupons} logs={logs} customers={customers} reviews={reviews} webhookConfigured={!!process.env.STORE_ORDER_WEBHOOK_URL} emailConfigured={!!(process.env.RESEND_API_KEY || process.env.CUSTOMER_EMAIL_WEBHOOK_URL)} />
    </Suspense>
  );
}
