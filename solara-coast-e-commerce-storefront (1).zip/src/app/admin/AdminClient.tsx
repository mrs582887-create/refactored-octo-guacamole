"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { LayoutDashboard, Package, ShoppingCart, Users, Layers, Ticket, Star, Bell, ArrowLeft, Plus, Trash2, Pencil, Check, X, AlertTriangle, IndianRupee, Loader2, Boxes } from "lucide-react";
import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell } from "recharts";
import type { Product, Order, Category, Coupon, NotificationLog, Customer } from "@/db/schema";
import { formatINR, fmtDate, ORDER_STATUSES, cn, num } from "@/lib/utils";
import { Logo, DemoTag, ConfirmDialog, EmptyState } from "@/components/ui";

type Stats = { productCount: number; lowStock: number; orderCount: number; revenue: number; pending: number; delivered: number; customerCount: number };
type ReviewRow = { id: number; author: string; rating: number; title: string | null; comment: string | null; createdAt: Date | null; productName: string | null; productSlug: string | null };
const NAV = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard }, { id: "products", label: "Products", icon: Package }, { id: "inventory", label: "Inventory", icon: Boxes }, { id: "orders", label: "Orders", icon: ShoppingCart },
  { id: "customers", label: "Customers", icon: Users }, { id: "categories", label: "Categories", icon: Layers }, { id: "coupons", label: "Coupons", icon: Ticket }, { id: "reviews", label: "Reviews", icon: Star }, { id: "logs", label: "Notification Logs", icon: Bell },
];
const COLORS = ["#1c1917", "#f59e0b", "#14b8a6", "#f43f5e", "#8b5cf6", "#0ea5e9", "#84cc16", "#f97316"];

export default function AdminClient({ stats, products, orders, categories, coupons, logs, customers, reviews, webhookConfigured, emailConfigured }: { stats: Stats; products: Product[]; orders: Order[]; categories: Category[]; coupons: Coupon[]; logs: NotificationLog[]; customers: Customer[]; reviews: ReviewRow[]; webhookConfigured: boolean; emailConfigured: boolean }) {
  const sp = useSearchParams();
  const router = useRouter();
  const tab = sp.get("tab") || "dashboard";
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [editing, setEditing] = useState<Product | null>(null);
  const [confirm, setConfirm] = useState<{ title: string; action: () => void } | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [newP, setNewP] = useState({ name: "", brand: "Solara Coast", price: "", originalPrice: "", stock: "25", categoryId: "", tagline: "", description: "", imageMain: "", specs: "", colors: "", warranty: "" });
  const [newC, setNewC] = useState({ code: "", type: "percent", value: "", minOrder: "", maxDiscount: "", description: "" });
  const [newCat, setNewCat] = useState({ name: "", department: "Daily Essentials" });
  const [search, setSearch] = useState("");

  const go = (t: string) => router.push(`/admin?tab=${t}`);
  const call = async (action: string, data: Record<string, unknown>, okText: string) => {
    setBusy(true); setMsg(null);
    try {
      const res = await fetch("/api/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, data }) });
      const d = await res.json();
      if (!res.ok || d.error) throw new Error(d.error || "Failed");
      setMsg({ ok: true, text: okText });
      router.refresh();
    } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : "Failed" }); } finally { setBusy(false); }
  };
  const updateStatus = async (orderId: string, status: string) => {
    setBusy(true);
    try { await fetch(`/api/orders/${orderId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) }); setMsg({ ok: true, text: `${orderId} → ${status}` }); router.refresh(); } finally { setBusy(false); }
  };

  // Charts (last 14 days; demo baseline blended with real orders)
  const series = useMemo(() => {
    const days: { day: string; sales: number; orders: number; revenue: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      const key = d.toDateString();
      const real = orders.filter((o) => o.createdAt && new Date(o.createdAt).toDateString() === key);
      const base = 4 + ((i * 7) % 9);
      days.push({ day: d.toLocaleDateString("en-IN", { day: "numeric", month: "short" }), orders: base + real.length, sales: base * 1800 + real.reduce((s, o) => s + num(o.total), 0), revenue: base * 1500 + real.reduce((s, o) => s + num(o.total), 0) * 0.82 });
    }
    return days;
  }, [orders]);
  const topCats = useMemo(() => {
    const m = new Map<string, number>();
    products.forEach((p) => m.set(p.department, (m.get(p.department) || 0) + p.soldCount));
    return Array.from(m.entries()).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 6);
  }, [products]);
  const topProducts = useMemo(() => [...products].sort((a, b) => b.soldCount - a.soldCount).slice(0, 6).map((p) => ({ name: p.name.length > 18 ? p.name.slice(0, 18) + "…" : p.name, sold: p.soldCount })), [products]);
  const filteredProducts = products.filter((p) => !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.brand.toLowerCase().includes(search.toLowerCase()) || p.sku.toLowerCase().includes(search.toLowerCase()));
  const input = "h-10 px-3 rounded-xl bg-white border border-stone-200 text-sm outline-none focus:border-stone-400 w-full";

  return (
    <div className="min-h-screen bg-stone-100 flex">
      <aside className="hidden md:flex w-60 flex-col bg-stone-950 text-stone-300 p-5 sticky top-0 h-screen">
        <Logo dark />
        <p className="text-[10px] uppercase tracking-[0.2em] text-stone-500 mt-6 mb-2">Admin</p>
        <nav className="space-y-0.5">{NAV.map((n) => <button key={n.id} onClick={() => go(n.id)} className={cn("w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-left", tab === n.id ? "bg-white text-stone-950" : "hover:bg-white/5")}><n.icon className="h-4 w-4" /> {n.label}</button>)}</nav>
        <Link href="/" className="mt-auto inline-flex items-center gap-2 text-xs text-stone-400 hover:text-white"><ArrowLeft className="h-3.5 w-3.5" /> Back to store</Link>
      </aside>

      <div className="flex-1 min-w-0">
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur border-b border-stone-200 px-4 md:px-8 h-14 flex items-center gap-3">
          <Link href="/" className="md:hidden"><ArrowLeft className="h-5 w-5" /></Link>
          <h1 className="text-base font-[550] capitalize">{NAV.find((n) => n.id === tab)?.label}</h1>
          <DemoTag>Demo admin · no auth</DemoTag>
          {busy && <Loader2 className="h-4 w-4 animate-spin text-stone-400" />}
          {msg && <span className={cn("ml-auto text-xs px-3 py-1 rounded-full", msg.ok ? "bg-teal-50 text-teal-700" : "bg-rose-50 text-rose-700")}>{msg.text}</span>}
        </header>
        <div className="md:hidden flex gap-1 overflow-x-auto p-3 bg-white border-b border-stone-200 [scrollbar-width:none]">{NAV.map((n) => <button key={n.id} onClick={() => go(n.id)} className={cn("shrink-0 px-3 py-1.5 rounded-full text-xs", tab === n.id ? "bg-stone-900 text-white" : "bg-stone-100")}>{n.label}</button>)}</div>

        <main className="p-4 md:p-8 space-y-6">
          {tab === "dashboard" && (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-3">
                {[{ l: "Total Sales", v: formatINR(stats.revenue), i: IndianRupee }, { l: "Orders", v: stats.orderCount, i: ShoppingCart }, { l: "Customers", v: stats.customerCount, i: Users }, { l: "Products", v: stats.productCount, i: Package }, { l: "Low Stock", v: stats.lowStock, i: AlertTriangle, warn: stats.lowStock > 0 }, { l: "Pending Orders", v: stats.pending, i: Loader2 }, { l: "Delivered", v: stats.delivered, i: Check }].map((s) => (
                  <div key={s.l} className="rounded-2xl bg-white border border-stone-200 p-4"><div className="flex items-center justify-between"><p className="text-[11px] uppercase tracking-wider text-stone-500">{s.l}</p><s.i className={cn("h-4 w-4", s.warn ? "text-amber-500" : "text-stone-400")} /></div><p className="mt-2 text-2xl font-[560] tracking-[-0.02em]">{s.v}</p></div>
                ))}
              </div>
              <div className="grid lg:grid-cols-3 gap-4">
                <Panel title="Sales (14 days)" className="lg:col-span-2"><ResponsiveContainer width="100%" height={240}><AreaChart data={series}><defs><linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#1c1917" stopOpacity={0.25} /><stop offset="100%" stopColor="#1c1917" stopOpacity={0} /></linearGradient></defs><CartesianGrid strokeDasharray="3 3" stroke="#eee" /><XAxis dataKey="day" tick={{ fontSize: 10 }} /><YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `${Math.round(v / 1000)}k`} /><Tooltip formatter={(v) => formatINR(Number(v))} /><Area type="monotone" dataKey="sales" stroke="#1c1917" fill="url(#g1)" strokeWidth={2} /><Area type="monotone" dataKey="revenue" stroke="#14b8a6" fill="none" strokeWidth={2} /></AreaChart></ResponsiveContainer></Panel>
                <Panel title="Orders per day"><ResponsiveContainer width="100%" height={240}><BarChart data={series}><CartesianGrid strokeDasharray="3 3" stroke="#eee" /><XAxis dataKey="day" tick={{ fontSize: 10 }} interval={3} /><YAxis tick={{ fontSize: 10 }} /><Tooltip /><Bar dataKey="orders" fill="#f59e0b" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></Panel>
                <Panel title="Top categories"><ResponsiveContainer width="100%" height={240}><PieChart><Pie data={topCats} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={3}>{topCats.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /></PieChart></ResponsiveContainer><div className="flex flex-wrap gap-2 text-[11px]">{topCats.map((c, i) => <span key={c.name} className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />{c.name}</span>)}</div></Panel>
                <Panel title="Top products (units sold)" className="lg:col-span-2"><ResponsiveContainer width="100%" height={240}><BarChart data={topProducts} layout="vertical" margin={{ left: 40 }}><XAxis type="number" tick={{ fontSize: 10 }} /><YAxis type="category" dataKey="name" width={120} tick={{ fontSize: 10 }} /><Tooltip /><Bar dataKey="sold" fill="#14b8a6" radius={[0, 6, 6, 0]} /></BarChart></ResponsiveContainer></Panel>
              </div>
              <Panel title="Integration status">
                <div className="grid sm:grid-cols-2 gap-3 text-sm">
                  <Status ok={webhookConfigured} label="Owner order notification (STORE_ORDER_WEBHOOK_URL)" hint={webhookConfigured ? "Orders are POSTed to your webhook (n8n / Make / Zapier → Gmail)." : "Not configured — notifications are simulated and logged."} />
                  <Status ok={emailConfigured} label="Customer confirmation email (RESEND_API_KEY / CUSTOMER_EMAIL_WEBHOOK_URL)" hint={emailConfigured ? "Confirmation emails are sent server-side." : "Not configured — emails are prepared and logged, not sent."} />
                  <Status ok={false} label="Payment gateway" hint="Demo payments only. Connect Razorpay/Stripe server-side; never expose secret keys in the browser." />
                  <Status ok={false} label="Admin authentication" hint="This dashboard is open for demo purposes. Add auth before deploying." />
                </div>
              </Panel>
              <Panel title="Recent orders">{orders.length === 0 ? <p className="text-sm text-stone-500">No orders yet — place one from the storefront.</p> : <OrdersTable orders={orders.slice(0, 5)} onStatus={updateStatus} />}</Panel>
            </>
          )}

          {tab === "products" && (
            <Panel title={`Products (${products.length})`} action={<div className="flex gap-2"><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name / SKU" className="h-9 px-3 rounded-full border border-stone-200 text-sm w-48" /><button onClick={() => setShowNew(!showNew)} className="h-9 px-3 rounded-full bg-stone-900 text-white text-xs font-semibold inline-flex items-center gap-1"><Plus className="h-3.5 w-3.5" /> Add product</button></div>}>
              {showNew && (
                <div className="mb-5 rounded-2xl bg-stone-50 border border-stone-200 p-4 grid sm:grid-cols-3 gap-3">
                  <input className={input} placeholder="Name *" value={newP.name} onChange={(e) => setNewP({ ...newP, name: e.target.value })} />
                  <input className={input} placeholder="Brand" value={newP.brand} onChange={(e) => setNewP({ ...newP, brand: e.target.value })} />
                  <select className={input} value={newP.categoryId} onChange={(e) => setNewP({ ...newP, categoryId: e.target.value })}><option value="">Category</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.department} › {c.name}</option>)}</select>
                  <input className={input} type="number" placeholder="Price *" value={newP.price} onChange={(e) => setNewP({ ...newP, price: e.target.value })} />
                  <input className={input} type="number" placeholder="Original price" value={newP.originalPrice} onChange={(e) => setNewP({ ...newP, originalPrice: e.target.value })} />
                  <input className={input} type="number" placeholder="Stock" value={newP.stock} onChange={(e) => setNewP({ ...newP, stock: e.target.value })} />
                  <input className={cn(input, "sm:col-span-2")} placeholder="Tagline" value={newP.tagline} onChange={(e) => setNewP({ ...newP, tagline: e.target.value })} />
                  <input className={input} placeholder="Image URL" value={newP.imageMain} onChange={(e) => setNewP({ ...newP, imageMain: e.target.value })} />
                  <textarea className={cn(input, "h-20 py-2 sm:col-span-2")} placeholder="Description" value={newP.description} onChange={(e) => setNewP({ ...newP, description: e.target.value })} />
                  <textarea className={cn(input, "h-20 py-2")} placeholder={"Specs (one per line)\nRAM: 8GB"} value={newP.specs} onChange={(e) => setNewP({ ...newP, specs: e.target.value })} />
                  <input className={input} placeholder="Colors (comma separated)" value={newP.colors} onChange={(e) => setNewP({ ...newP, colors: e.target.value })} />
                  <input className={input} placeholder="Warranty" value={newP.warranty} onChange={(e) => setNewP({ ...newP, warranty: e.target.value })} />
                  <button disabled={!newP.name || !newP.price || busy} onClick={() => call("product.create", newP, "Product created").then(() => setShowNew(false))} className="h-10 rounded-xl bg-stone-900 text-white text-sm font-semibold disabled:opacity-40">Create product</button>
                </div>
              )}
              <div className="overflow-x-auto">
                <table className="w-full text-sm min-w-[820px]">
                  <thead><tr className="text-left text-[10px] uppercase tracking-wider text-stone-400 border-b border-stone-200"><th className="py-2 pr-3">Product</th><th className="py-2 pr-3">Category</th><th className="py-2 pr-3">Price</th><th className="py-2 pr-3">Stock</th><th className="py-2 pr-3">Sold</th><th className="py-2 pr-3">Flags</th><th className="py-2"></th></tr></thead>
                  <tbody className="divide-y divide-stone-100">
                    {filteredProducts.map((p) => (
                      <tr key={p.id}>
                        <td className="py-2.5 pr-3"><div className="flex items-center gap-3"><img src={p.imageMain} alt="" className="h-10 w-10 rounded-lg object-cover bg-stone-100" /><div><Link href={`/product/${p.slug}`} className="font-medium hover:underline line-clamp-1">{p.name}</Link><p className="text-[11px] text-stone-400">{p.brand} · {p.sku}</p></div></div></td>
                        <td className="py-2.5 pr-3 text-stone-600 text-xs">{p.categoryName}</td>
                        <td className="py-2.5 pr-3">{editing?.id === p.id ? <input type="number" defaultValue={p.price} onChange={(e) => setEditing({ ...editing, price: e.target.value })} className="w-24 h-8 px-2 rounded-lg border" /> : <span className="font-medium">{formatINR(p.price)}</span>}</td>
                        <td className="py-2.5 pr-3">{editing?.id === p.id ? <input type="number" defaultValue={p.stock} onChange={(e) => setEditing({ ...editing, stock: Number(e.target.value) })} className="w-20 h-8 px-2 rounded-lg border" /> : <StockPill n={p.stock} />}</td>
                        <td className="py-2.5 pr-3 text-stone-600">{p.soldCount}</td>
                        <td className="py-2.5 pr-3 text-[10px] space-x-1">{p.featured && <span className="px-1.5 py-0.5 rounded bg-stone-100">Featured</span>}{p.flashDeal && <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-700">Deal</span>}{p.newArrival && <span className="px-1.5 py-0.5 rounded bg-teal-50 text-teal-700">New</span>}</td>
                        <td className="py-2.5 text-right whitespace-nowrap">
                          {editing?.id === p.id ? (<><button onClick={() => { call("product.update", { id: p.id, price: editing.price, stock: editing.stock }, "Product updated"); setEditing(null); }} className="p-1.5 text-teal-600"><Check className="h-4 w-4" /></button><button onClick={() => setEditing(null)} className="p-1.5 text-stone-400"><X className="h-4 w-4" /></button></>) : (<><button onClick={() => setEditing(p)} className="p-1.5 text-stone-500 hover:text-stone-900"><Pencil className="h-4 w-4" /></button><button onClick={() => setConfirm({ title: `Delete “${p.name}”?`, action: () => call("product.delete", { id: p.id }, "Product deleted") })} className="p-1.5 text-stone-500 hover:text-rose-600"><Trash2 className="h-4 w-4" /></button></>)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>
          )}

          {tab === "inventory" && (
            <>
              <div className="grid grid-cols-3 gap-3">
                {[["In Stock", products.filter((p) => p.stock > 5).length, "teal"], ["Low Stock (≤5)", products.filter((p) => p.stock > 0 && p.stock <= 5).length, "amber"], ["Out of Stock", products.filter((p) => p.stock <= 0).length, "rose"]].map(([l, v, t]) => <div key={l as string} className={cn("rounded-2xl border p-4", t === "teal" ? "bg-teal-50 border-teal-200" : t === "amber" ? "bg-amber-50 border-amber-200" : "bg-rose-50 border-rose-200")}><p className="text-[11px] uppercase tracking-wider text-stone-600">{l}</p><p className="text-2xl font-[560] mt-1">{v}</p></div>)}
              </div>
              <Panel title="Needs attention">
                <div className="divide-y divide-stone-100">
                  {[...products].filter((p) => p.stock <= 5).sort((a, b) => a.stock - b.stock).map((p) => (
                    <div key={p.id} className="flex items-center gap-3 py-2.5"><img src={p.imageMain} alt="" className="h-10 w-10 rounded-lg object-cover" /><div className="flex-1 min-w-0"><p className="text-sm font-medium line-clamp-1">{p.name}</p><p className="text-[11px] text-stone-400">{p.sku}</p></div><StockPill n={p.stock} />
                      <div className="flex gap-1">{[10, 25, 50].map((n) => <button key={n} onClick={() => call("product.update", { id: p.id, stock: p.stock + n }, `Restocked +${n}`)} className="h-8 px-2.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-xs font-medium">+{n}</button>)}</div>
                    </div>
                  ))}
                </div>
                <p className="mt-3 text-xs text-stone-500">Stock is automatically decremented when an order is placed.</p>
              </Panel>
            </>
          )}

          {tab === "orders" && <Panel title={`Orders (${orders.length})`}>{orders.length === 0 ? <EmptyState icon={<ShoppingCart className="h-6 w-6" />} title="No orders yet" body="Orders placed on the storefront will appear here with status controls." /> : <OrdersTable orders={orders} onStatus={updateStatus} />}</Panel>}

          {tab === "customers" && (
            <Panel title={`Customers (${customers.length})`}>
              {customers.length === 0 ? <EmptyState icon={<Users className="h-6 w-6" />} title="No customers yet" /> : (
                <table className="w-full text-sm"><thead><tr className="text-left text-[10px] uppercase tracking-wider text-stone-400 border-b"><th className="py-2">Name</th><th className="py-2">Email</th><th className="py-2">Phone</th><th className="py-2">Orders</th><th className="py-2">Spent</th><th className="py-2">Since</th></tr></thead><tbody className="divide-y divide-stone-100">{customers.map((c) => <tr key={c.id}><td className="py-2.5 font-medium">{c.name}</td><td className="py-2.5 text-stone-600">{c.email}</td><td className="py-2.5 text-stone-600">{c.phone}</td><td className="py-2.5">{c.totalOrders}</td><td className="py-2.5 font-medium">{formatINR(c.totalSpent)}</td><td className="py-2.5 text-stone-500">{fmtDate(c.createdAt)}</td></tr>)}</tbody></table>
              )}
            </Panel>
          )}

          {tab === "categories" && (
            <Panel title={`Categories (${categories.length})`} action={<div className="flex gap-2"><input className="h-9 px-3 rounded-full border border-stone-200 text-sm" placeholder="New category" value={newCat.name} onChange={(e) => setNewCat({ ...newCat, name: e.target.value })} /><select className="h-9 px-3 rounded-full border border-stone-200 text-sm" value={newCat.department} onChange={(e) => setNewCat({ ...newCat, department: e.target.value })}>{Array.from(new Set(categories.map((c) => c.department))).map((d) => <option key={d}>{d}</option>)}</select><button disabled={!newCat.name} onClick={() => call("category.create", newCat, "Category created")} className="h-9 px-3 rounded-full bg-stone-900 text-white text-xs font-semibold disabled:opacity-40">Add</button></div>}>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">{categories.map((c) => <div key={c.id} className="flex items-center justify-between rounded-xl border border-stone-200 px-3 py-2 text-sm"><span>{c.name}<span className="block text-[11px] text-stone-400">{c.department}</span></span><span className="text-xs text-stone-500">{products.filter((p) => p.categorySlug === c.slug).length} items</span></div>)}</div>
            </Panel>
          )}

          {tab === "coupons" && (
            <Panel title="Coupons" action={<DemoTag>Demo coupons</DemoTag>}>
              <div className="mb-5 rounded-2xl bg-stone-50 border border-stone-200 p-4 grid sm:grid-cols-6 gap-2">
                <input className={input} placeholder="CODE" value={newC.code} onChange={(e) => setNewC({ ...newC, code: e.target.value.toUpperCase() })} />
                <select className={input} value={newC.type} onChange={(e) => setNewC({ ...newC, type: e.target.value })}><option value="percent">Percent</option><option value="flat">Flat ₹</option><option value="freeship">Free shipping</option></select>
                <input className={input} type="number" placeholder="Value" value={newC.value} onChange={(e) => setNewC({ ...newC, value: e.target.value })} />
                <input className={input} type="number" placeholder="Min order" value={newC.minOrder} onChange={(e) => setNewC({ ...newC, minOrder: e.target.value })} />
                <input className={input} placeholder="Description" value={newC.description} onChange={(e) => setNewC({ ...newC, description: e.target.value })} />
                <button disabled={!newC.code} onClick={() => call("coupon.create", newC, "Coupon created")} className="h-10 rounded-xl bg-stone-900 text-white text-sm font-semibold disabled:opacity-40">Create</button>
              </div>
              <div className="divide-y divide-stone-100">{coupons.map((c) => <div key={c.id} className="flex items-center gap-4 py-3"><span className="font-mono font-bold w-28">{c.code}</span><span className="flex-1 text-sm text-stone-600">{c.description} <span className="text-stone-400">· {c.type} {c.type !== "freeship" && (c.type === "percent" ? `${num(c.value)}%` : formatINR(c.value))} · min {formatINR(c.minOrder)}</span></span><button onClick={() => call("coupon.toggle", { id: c.id, active: !c.active }, c.active ? "Coupon disabled" : "Coupon enabled")} className={cn("text-xs px-2.5 py-1 rounded-full font-medium", c.active ? "bg-teal-50 text-teal-700" : "bg-stone-100 text-stone-500")}>{c.active ? "Active" : "Inactive"}</button><button onClick={() => setConfirm({ title: `Delete ${c.code}?`, action: () => call("coupon.delete", { id: c.id }, "Coupon deleted") })} className="p-1.5 text-stone-400 hover:text-rose-600"><Trash2 className="h-4 w-4" /></button></div>)}</div>
            </Panel>
          )}

          {tab === "reviews" && (
            <Panel title="Recent reviews">
              <div className="divide-y divide-stone-100">{reviews.map((r) => <div key={r.id} className="py-3"><div className="flex items-center gap-2 text-sm"><span className="font-medium">{r.author}</span><span className="text-amber-500">{"★".repeat(r.rating)}</span><span className="text-stone-400">on</span>{r.productSlug ? <Link href={`/product/${r.productSlug}`} className="underline">{r.productName}</Link> : <span>{r.productName}</span>}</div><p className="text-sm font-medium mt-1">{r.title}</p><p className="text-sm text-stone-600">{r.comment}</p></div>)}</div>
            </Panel>
          )}

          {tab === "logs" && (
            <Panel title="Notification logs" action={<span className="text-xs text-stone-500">{logs.length} entries</span>}>
              {logs.length === 0 ? <EmptyState icon={<Bell className="h-6 w-6" />} title="No notifications yet" body="Every order writes an owner-webhook and customer-email log entry (sent / simulated / failed)." /> : (
                <div className="divide-y divide-stone-100">{logs.map((l) => <div key={l.id} className="py-3 flex items-start gap-3"><span className={cn("mt-0.5 text-[10px] font-bold uppercase px-1.5 py-0.5 rounded", l.status === "sent" ? "bg-teal-50 text-teal-700" : l.status === "failed" ? "bg-rose-50 text-rose-700" : "bg-amber-50 text-amber-700")}>{l.status}</span><div className="flex-1 min-w-0"><p className="text-sm font-medium">{l.subject}</p><p className="text-xs text-stone-500">{l.channel} → {l.recipient} · <Link href={`/orders/${l.orderId}`} className="underline">{l.orderId}</Link> · {fmtDate(l.createdAt, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</p><p className="text-xs text-stone-500 mt-1">{l.detail}</p></div></div>)}</div>
              )}
            </Panel>
          )}
        </main>
      </div>
      <ConfirmDialog open={!!confirm} title={confirm?.title || ""} confirmLabel="Delete" danger onConfirm={() => { confirm?.action(); setConfirm(null); }} onCancel={() => setConfirm(null)} />
    </div>
  );
}

function Panel({ title, children, action, className }: { title: string; children: React.ReactNode; action?: React.ReactNode; className?: string }) {
  return <section className={cn("rounded-2xl bg-white border border-stone-200 p-5", className)}><div className="flex items-center justify-between gap-3 mb-4 flex-wrap"><h2 className="text-sm font-[550]">{title}</h2>{action}</div>{children}</section>;
}
function Status({ ok, label, hint }: { ok: boolean; label: string; hint: string }) {
  return <div className={cn("rounded-xl border p-3", ok ? "border-teal-200 bg-teal-50" : "border-amber-200 bg-amber-50")}><p className="text-sm font-medium flex items-center gap-2">{ok ? <Check className="h-4 w-4 text-teal-600" /> : <AlertTriangle className="h-4 w-4 text-amber-600" />}{label}<span className="ml-auto text-[10px] uppercase font-bold">{ok ? "Live" : "Demo"}</span></p><p className="text-xs text-stone-600 mt-1">{hint}</p></div>;
}
function StockPill({ n }: { n: number }) {
  return <span className={cn("text-[11px] font-semibold px-2 py-0.5 rounded-full", n <= 0 ? "bg-rose-50 text-rose-700" : n <= 5 ? "bg-amber-50 text-amber-700" : "bg-teal-50 text-teal-700")}>{n <= 0 ? "Out of stock" : n <= 5 ? `Low · ${n}` : `In stock · ${n}`}</span>;
}
function OrdersTable({ orders, onStatus }: { orders: Order[]; onStatus: (id: string, s: string) => void }) {
  return (
    <div className="overflow-x-auto"><table className="w-full text-sm min-w-[760px]"><thead><tr className="text-left text-[10px] uppercase tracking-wider text-stone-400 border-b border-stone-200"><th className="py-2 pr-3">Order</th><th className="py-2 pr-3">Customer</th><th className="py-2 pr-3">Items</th><th className="py-2 pr-3">Total</th><th className="py-2 pr-3">Payment</th><th className="py-2 pr-3">Status</th></tr></thead>
      <tbody className="divide-y divide-stone-100">{orders.map((o) => (
        <tr key={o.id}><td className="py-2.5 pr-3"><Link href={`/orders/${o.orderId}`} className="font-mono text-xs font-semibold hover:underline">{o.orderId}</Link><p className="text-[11px] text-stone-400">{fmtDate(o.createdAt, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</p></td><td className="py-2.5 pr-3"><p className="font-medium">{o.customerName}</p><p className="text-[11px] text-stone-400">{o.customerEmail}</p></td><td className="py-2.5 pr-3 text-stone-600">{o.items.reduce((s, i) => s + i.qty, 0)}</td><td className="py-2.5 pr-3 font-medium">{formatINR(o.total)}</td><td className="py-2.5 pr-3 text-xs text-stone-600">{o.paymentMethod} <span className="text-[10px] uppercase text-amber-700">({o.paymentMode})</span></td>
          <td className="py-2.5 pr-3"><select value={o.status} onChange={(e) => onStatus(o.orderId, e.target.value)} className={cn("h-8 px-2 rounded-lg border text-xs font-medium", o.status === "Delivered" ? "border-teal-200 bg-teal-50 text-teal-700" : "border-stone-200 bg-white")}>{ORDER_STATUSES.map((s) => <option key={s}>{s}</option>)}</select></td></tr>
      ))}</tbody></table></div>
  );
}
