import Link from "next/link";
import { getAllCategories, getAllProducts } from "@/lib/queries";
import { DEPARTMENTS } from "@/db/catalog";
import { Breadcrumbs } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function CategoriesPage() {
  const [cats, products] = await Promise.all([getAllCategories(), getAllProducts()]);
  const counts = new Map<string, number>();
  products.forEach((p) => counts.set(p.categorySlug, (counts.get(p.categorySlug) || 0) + 1));
  return (
    <main className="mx-auto max-w-7xl px-4 lg:px-8 py-8">
      <Breadcrumbs items={[{ label: "Categories" }]} />
      <h1 className="text-3xl font-[480] tracking-[-0.03em]">All Categories</h1>
      <p className="text-sm text-stone-500 mt-1">{cats.length} categories across {DEPARTMENTS.length} departments.</p>
      <div className="mt-8 space-y-10">
        {DEPARTMENTS.map((d) => (
          <section key={d.slug}>
            <div className="flex items-end justify-between mb-4">
              <h2 className="text-xl font-[520] tracking-[-0.02em]">{d.name}</h2>
              <Link href={`/products?dept=${d.slug}`} className="text-sm text-stone-600 hover:text-stone-900">View department →</Link>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {cats.filter((c) => c.departmentSlug === d.slug).map((c) => (
                <Link key={c.id} href={`/products?cat=${c.slug}`} className="group relative overflow-hidden rounded-2xl bg-stone-200 aspect-[5/3] ring-1 ring-stone-200/60">
                  {c.image && <img src={c.image} alt="" className="absolute inset-0 h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />}
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent" />
                  <div className="absolute bottom-3 left-3 right-3 text-white">
                    <p className="text-sm font-medium leading-tight">{c.name}</p>
                    <p className="text-[11px] text-stone-300">{counts.get(c.slug) || 0} products</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </main>
  );
}
