"use client";

import Link from "next/link";
import { Heart, ShoppingBag, Trash2 } from "lucide-react";
import { useStore } from "@/lib/store-context";
import { formatINR } from "@/lib/utils";
import { EmptyState, Breadcrumbs, Stars } from "@/components/ui";

export default function WishlistPage() {
  const { wishlist, toggleWishlist, addToCart, toast, hydrated } = useStore();
  const moveAll = () => { wishlist.filter((p) => p.stock > 0).forEach((p) => addToCart({ productId: p.id, slug: p.slug, name: p.name, price: p.price, image: p.image, color: "", size: "", stock: p.stock }, { silent: true })); toast({ title: "Moved to cart", body: `${wishlist.length} item(s)`, tone: "success" }); };
  return (
    <main className="mx-auto max-w-7xl px-4 lg:px-8 py-8">
      <Breadcrumbs items={[{ label: "Wishlist" }]} />
      <div className="flex items-end justify-between mb-6">
        <div><h1 className="text-3xl font-[480] tracking-[-0.03em]">Wishlist</h1><p className="text-sm text-stone-500 mt-1">{wishlist.length} saved item{wishlist.length === 1 ? "" : "s"} · stored on this device</p></div>
        {wishlist.length > 0 && <button onClick={moveAll} className="px-4 py-2.5 rounded-full bg-stone-900 text-white text-sm font-medium">Move all to cart</button>}
      </div>
      {hydrated && wishlist.length === 0 ? (
        <EmptyState icon={<Heart className="h-7 w-7" />} title="Your wishlist is empty" body="Tap the heart on any product to save it for later." action={<Link href="/products" className="px-5 py-2.5 rounded-full bg-stone-900 text-white text-sm font-medium">Discover products</Link>} />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {wishlist.map((p) => (
            <div key={p.id} className="group rounded-2xl bg-white border border-stone-200/70 overflow-hidden flex flex-col">
              <Link href={`/product/${p.slug}`} className="relative aspect-[4/5] bg-stone-100"><img src={p.image} alt={p.name} className="h-full w-full object-cover group-hover:scale-[1.03] transition-transform duration-500" /></Link>
              <div className="p-3 flex-1 flex flex-col">
                <p className="text-[11px] uppercase tracking-wider text-stone-400">{p.brand}</p>
                <Link href={`/product/${p.slug}`} className="text-sm font-medium line-clamp-2 mt-0.5">{p.name}</Link>
                <div className="mt-1"><Stars rating={p.rating} size="h-3 w-3" /></div>
                <p className="mt-1.5 text-sm font-semibold">{formatINR(p.price)} {p.originalPrice && <span className="text-xs text-stone-400 line-through font-normal">{formatINR(p.originalPrice)}</span>}</p>
                <div className="mt-auto pt-3 flex gap-2">
                  <button disabled={p.stock <= 0} onClick={() => { addToCart({ productId: p.id, slug: p.slug, name: p.name, price: p.price, image: p.image, color: "", size: "", stock: p.stock }); }} className="flex-1 h-9 rounded-full bg-stone-900 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 disabled:opacity-40"><ShoppingBag className="h-3.5 w-3.5" /> {p.stock <= 0 ? "Out of stock" : "Add to cart"}</button>
                  <button onClick={() => toggleWishlist(p)} className="h-9 w-9 rounded-full border border-stone-200 flex items-center justify-center text-stone-500 hover:text-rose-500 hover:border-rose-200"><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
