import Link from "next/link";
import { getOrderByOrderId } from "@/lib/queries";
import OrderTracking from "@/components/OrderTracking";
import { Breadcrumbs } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function OrderPage({ params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;
  const order = await getOrderByOrderId(orderId.toUpperCase());
  return (
    <main className="mx-auto max-w-6xl px-4 lg:px-8 py-8">
      <Breadcrumbs items={[{ label: "Track Order", href: "/track" }, { label: orderId.toUpperCase() }]} />
      {order ? (
        <OrderTracking order={order} />
      ) : (
        <div className="text-center py-24">
          <h1 className="text-2xl font-[500]">Order not found</h1>
          <p className="text-stone-500 mt-2">We couldn't find an order with ID <span className="font-mono">{orderId}</span>.</p>
          <Link href="/track" className="mt-6 inline-block px-6 py-3 rounded-full bg-stone-900 text-white text-sm font-semibold">Try another ID</Link>
        </div>
      )}
    </main>
  );
}
