import { getAllProducts } from "@/lib/queries";
import { Hero, FlashDeals, PopularCategories, TopBrands, Collections, RecentlyViewed, RecommendedForYou } from "@/components/HomeSections";
import ProductCarousel from "@/components/ProductCarousel";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const all = await getAllProducts();
  const featured = all.filter((p) => p.featured);
  const deals = all.filter((p) => p.flashDeal && p.stock > 0).slice(0, 12);
  const trending = all.filter((p) => p.trending).slice(0, 12);
  const newArrivals = all.filter((p) => p.newArrival).slice(0, 12);
  const bestSellers = all.filter((p) => p.bestSeller).slice(0, 12);
  const limited = all.filter((p) => p.stock > 0 && p.stock <= 8).slice(0, 12);
  const brands = Array.from(new Set(all.map((p) => p.brand))).slice(0, 18);
  const byTag = (t: string) => all.filter((p) => (p.tags || []).includes(t)).slice(0, 10);

  return (
    <main className="min-h-screen">
      <Hero featured={featured} />
      <FlashDeals products={deals} />
      <PopularCategories />
      <ProductCarousel products={trending} eyebrow="Hot right now" title="Trending Now" subtitle="What everyone's adding to cart this week." href="/products?sort=popular" />
      <ProductCarousel products={newArrivals} eyebrow="Just in" title="New Arrivals" subtitle="Fresh from the coast." href="/products?sort=newest" />
      <RecommendedForYou all={all} />
      <ProductCarousel products={bestSellers} eyebrow="Customer favourites" title="Best Sellers" subtitle="Loved by thousands of shoppers." href="/products?sort=popular" dark />
      <RecentlyViewed all={all} />
      <TopBrands brands={brands} />
      <ProductCarousel products={limited} eyebrow="Almost gone" title="Limited Time Offers" subtitle="Low stock — grab them before they sell out." href="/products?stock=low" />
      <Collections />
      <ProductCarousel products={byTag("students")} title="Student Essentials" subtitle="Budget-friendly picks for campus life." href="/products?q=students" />
      <ProductCarousel products={byTag("work from home")} title="Work From Home Collection" subtitle="Build a desk you'll love working at." href="/products?q=work%20from%20home" />
      <ProductCarousel products={byTag("gaming")} title="Gaming Zone" subtitle="High refresh, low latency." href="/products?q=gaming" />
      <ProductCarousel products={byTag("smart home")} title="Smart Home Collection" subtitle="Voice-controlled convenience." href="/products?q=smart%20home" />
      <ProductCarousel products={byTag("travel")} title="Travel Essentials" subtitle="Pack smarter for the next trip." href="/products?q=travel" />

      <section className="mx-auto max-w-7xl px-4 lg:px-8 py-16">
        <div className="relative overflow-hidden rounded-3xl bg-stone-950 text-white p-8 md:p-14 text-center">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(251,191,36,0.18),transparent_60%)]" />
          <p className="relative text-xs uppercase tracking-[0.2em] text-amber-200/80">Solara Coast</p>
          <h2 className="relative mt-3 text-3xl md:text-5xl font-[460] tracking-[-0.04em]">Everything You Need. One Coast.</h2>
          <p className="relative mt-4 text-stone-400 max-w-xl mx-auto">Use code <span className="font-semibold text-white">WELCOME10</span> at checkout for 10% off your first order. Demo coupon — no payment is processed.</p>
          <Link href="/products" className="relative mt-8 inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-white text-stone-950 text-sm font-semibold hover:bg-stone-100">Start shopping <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </section>
    </main>
  );
}
