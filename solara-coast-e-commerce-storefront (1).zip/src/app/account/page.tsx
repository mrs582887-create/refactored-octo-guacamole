import { Suspense } from "react";
import AccountClient from "./AccountClient";
import { getAllCoupons } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const coupons = await getAllCoupons();
  return (
    <Suspense fallback={<div className="mx-auto max-w-7xl px-4 py-16 text-sm text-stone-500">Loading account…</div>}>
      <AccountClient coupons={coupons.filter((c) => c.active)} />
    </Suspense>
  );
}
