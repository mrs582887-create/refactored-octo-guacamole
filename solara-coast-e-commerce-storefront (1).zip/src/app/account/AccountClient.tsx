"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { User, Package, PackageSearch, Heart, MapPin, CreditCard, Ticket, Clock, Star, Bell, Settings, Trash2, Plus, Copy, ArrowRight, Loader2 } from "lucide-react";
import type { Coupon, Order } from "@/db/schema";
import { useStore } from "@/lib/store-context";
import { formatINR, fmtDate, cn } from "@/lib/utils";
import { EmptyState, DemoTag, ConfirmDialog, Breadcrumbs } from "@/components/ui";

const TABS = [
  { id: "profile", label: "Profile", icon: User }, { id: "orders", label: "My Orders", icon: Package }, { id: "track", label: "Track Orders", icon: PackageSearch }, { id: "wishlist", label: "Wishlist", icon: Heart },
  { id: "addresses", label: "Saved Addresses", icon: MapPin }, { id: "payments", label: "Payment Methods", icon: CreditCard }, { id: "coupons", label: "Coupons", icon: Ticket }, { id: "recent", label: "Recently Viewed", icon: Clock },
  { id: "reviews", label: "Product Reviews", icon: Star }, { id: "notifications", label: "Notifications", icon: Bell }, { id: "settings", label: "Settings", icon: Settings },
];

export default function AccountClient({ coupons }: { coupons: Coupon[] }) {
  const sp = useSearchParams();
  const router = useRouter();
  const tab = sp.get("tab") || "profile";
  const { profile, setProfile, addAddress, removeAddress, wishlist, recent, notifications, markAllRead, clearNotifications, toast, hydrated } = useStore();
  const [form, setForm] = useState({ name: "", email: "", phone: "" });
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [addrForm, setAddrForm] = useState({ label: "Home", fullName: "", phone: "", line1: "", line2: "", city: "", state: "", pincode: "", country: "India", isDefault: false });
  const [showAddr, setShowAddr] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  useEffect(() => { setForm({ name: profile.name, email: profile.email, phone: profile.phone }); }, [profile]);
  useEffect(() => {
    if (tab === "notifications") markAllRead();
  }, [tab, markAllRead]);
  useEffect(() => {
    if ((tab === "orders" || tab === "track") && profile.email && orders === null) {
      setLoadingOrders(true);
      fetch(`/api/orders?email=${encodeURIComponent(profile.email)}`).then((r) => r.json()).then((d) => setOrders(d.orders || [])).catch(() => setOrders([])).finally(() => setLoadingOrders(false));
    }
  }, [tab, profile.email, orders]);

  const go = (t: string) => router.push(`/account?tab=${t}`);
  const input = "w-full h-11 px-3.5 rounded-xl bg-stone-50 border border-stone-200 text-sm outline-none focus:border-stone-400 focus:bg-white";
  const Card = ({ children, title, action }: { children: React.ReactNode; title: string; action?: React.ReactNode }) => (
    <div className="rounded-3xl bg-white border border-stone-200 p-6 md:p-8"><div className="flex items-center justify-between mb-5"><h2 className="text-lg font-[520] tracking-[-0.02em]">{title}</h2>{action}</div>{children}</div>
  );

  return (
    <main className="mx-auto max-w-7xl px-4 lg:px-8 py-8">
      <Breadcrumbs items={[{ label: "My Account" }]} />
      <div className="flex items-center gap-4 mb-8">
        <div className="h-14 w-14 rounded-full bg-gradient-to-br from-amber-400 via-rose-400 to-teal-400 flex items-center justify-center text-white text-xl font-semibold">{(profile.name || "S")[0].toUpperCase()}</div>
        <div><h1 className="text-2xl font-[500] tracking-[-0.02em]">{profile.name ? `Hi, ${profile.name.split(" ")[0]}` : "My Account"}</h1><p className="text-sm text-stone-500">{profile.email || "Complete your profile to sync orders."} <DemoTag>Local demo account</DemoTag></p></div>
      </div>

      <div className="grid lg:grid-cols-[240px_1fr] gap-6">
        <nav className="flex lg:flex-col gap-1 overflow-x-auto pb-2 lg:pb-0 [scrollbar-width:none]">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => go(t.id)} className={cn("shrink-0 inline-flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-sm text-left transition", tab === t.id ? "bg-stone-900 text-white" : "text-stone-600 hover:bg-white")}>
              <t.icon className="h-4 w-4" /> {t.label}
              {t.id === "notifications" && notifications.filter((n) => !n.read).length > 0 && <span className="ml-auto h-5 min-w-5 px-1 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center">{notifications.filter((n) => !n.read).length}</span>}
            </button>
          ))}
        </nav>

        <div>
          {tab === "profile" && (
            <Card title="Profile">
              <div className="grid sm:grid-cols-2 gap-3">
                <input className={input} placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                <input className={input} placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                <input className={cn(input, "sm:col-span-2")} placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <button onClick={() => { setProfile(form); setOrders(null); toast({ title: "Profile saved", tone: "success" }); }} className="mt-4 px-5 py-2.5 rounded-full bg-stone-900 text-white text-sm font-semibold">Save profile</button>
              <p className="mt-3 text-xs text-stone-500">Your orders are looked up by email. Profile data is stored locally in this browser (demo) — connect an auth provider to make it persistent.</p>
            </Card>
          )}

          {(tab === "orders" || tab === "track") && (
            <Card title={tab === "orders" ? "My Orders" : "Track Orders"} action={<Link href="/track" className="text-sm underline text-stone-600">Track by ID</Link>}>
              {!profile.email ? <EmptyState icon={<User className="h-6 w-6" />} title="Add your email first" body="Save your email on the Profile tab and we'll load your orders." action={<button onClick={() => go("profile")} className="px-5 py-2.5 rounded-full bg-stone-900 text-white text-sm">Go to profile</button>} />
              : loadingOrders ? <div className="py-12 flex items-center justify-center gap-2 text-stone-500 text-sm"><Loader2 className="h-4 w-4 animate-spin" /> Loading orders…</div>
              : !orders || orders.length === 0 ? <EmptyState icon={<Package className="h-6 w-6" />} title="No orders yet" body="Orders placed with this email will appear here." action={<Link href="/products" className="px-5 py-2.5 rounded-full bg-stone-900 text-white text-sm">Start shopping</Link>} />
              : (
                <div className="space-y-3">
                  {orders.map((o) => (
                    <Link key={o.id} href={`/orders/${o.orderId}`} className="flex items-center gap-4 rounded-2xl border border-stone-200 p-4 hover:border-stone-400 transition">
                      <div className="flex -space-x-3">{o.items.slice(0, 3).map((i, k) => <img key={k} src={i.image} alt="" className="h-12 w-12 rounded-xl object-cover ring-2 ring-white bg-stone-100" />)}</div>
                      <div className="flex-1 min-w-0"><p className="font-mono text-sm font-semibold">{o.orderId}</p><p className="text-xs text-stone-500">{fmtDate(o.createdAt, { day: "numeric", month: "short", year: "numeric" })} · {o.items.reduce((s, i) => s + i.qty, 0)} items · {formatINR(o.total)}</p></div>
                      <span className={cn("text-[11px] font-semibold px-2.5 py-1 rounded-full", o.status === "Delivered" ? "bg-teal-50 text-teal-700" : "bg-amber-50 text-amber-700")}>{o.status}</span>
                      <ArrowRight className="h-4 w-4 text-stone-400" />
                    </Link>
                  ))}
                </div>
              )}
            </Card>
          )}

          {tab === "wishlist" && (
            <Card title="Wishlist" action={<Link href="/wishlist" className="text-sm underline text-stone-600">Open full page</Link>}>
              {wishlist.length === 0 ? <EmptyState icon={<Heart className="h-6 w-6" />} title="Nothing saved yet" /> : <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">{wishlist.map((p) => <Link key={p.id} href={`/product/${p.slug}`} className="rounded-2xl border border-stone-200 p-2"><img src={p.image} alt="" className="aspect-square rounded-xl object-cover" /><p className="text-xs font-medium mt-2 line-clamp-1">{p.name}</p><p className="text-xs text-stone-500">{formatINR(p.price)}</p></Link>)}</div>}
            </Card>
          )}

          {tab === "addresses" && (
            <Card title="Saved Addresses" action={<button onClick={() => setShowAddr(!showAddr)} className="inline-flex items-center gap-1 text-sm font-medium"><Plus className="h-4 w-4" /> Add</button>}>
              {showAddr && (
                <div className="mb-6 rounded-2xl bg-stone-50 border border-stone-200 p-4 grid sm:grid-cols-2 gap-3">
                  <input className={input} placeholder="Label (Home / Office)" value={addrForm.label} onChange={(e) => setAddrForm({ ...addrForm, label: e.target.value })} />
                  <input className={input} placeholder="Recipient name" value={addrForm.fullName} onChange={(e) => setAddrForm({ ...addrForm, fullName: e.target.value })} />
                  <input className={cn(input, "sm:col-span-2")} placeholder="Street address" value={addrForm.line1} onChange={(e) => setAddrForm({ ...addrForm, line1: e.target.value })} />
                  <input className={input} placeholder="City" value={addrForm.city} onChange={(e) => setAddrForm({ ...addrForm, city: e.target.value })} />
                  <input className={input} placeholder="State" value={addrForm.state} onChange={(e) => setAddrForm({ ...addrForm, state: e.target.value })} />
                  <input className={input} placeholder="Pincode" value={addrForm.pincode} onChange={(e) => setAddrForm({ ...addrForm, pincode: e.target.value })} />
                  <input className={input} placeholder="Phone" value={addrForm.phone} onChange={(e) => setAddrForm({ ...addrForm, phone: e.target.value })} />
                  <label className="text-sm flex items-center gap-2"><input type="checkbox" checked={addrForm.isDefault} onChange={(e) => setAddrForm({ ...addrForm, isDefault: e.target.checked })} /> Set as default</label>
                  <button onClick={() => { if (!addrForm.line1 || !addrForm.pincode) return; addAddress(addrForm); setShowAddr(false); toast({ title: "Address saved", tone: "success" }); }} className="h-11 rounded-xl bg-stone-900 text-white text-sm font-semibold">Save address</button>
                </div>
              )}
              {profile.addresses.length === 0 ? <EmptyState icon={<MapPin className="h-6 w-6" />} title="No saved addresses" body="Addresses you use at checkout are saved here." /> : (
                <div className="grid sm:grid-cols-2 gap-3">{profile.addresses.map((a) => <div key={a.id} className="rounded-2xl border border-stone-200 p-4 relative"><p className="text-sm font-semibold">{a.label} {a.isDefault && <span className="ml-1 text-[10px] uppercase text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded">Default</span>}</p><p className="text-sm text-stone-600 mt-1">{a.fullName}<br />{a.line1}{a.line2 ? `, ${a.line2}` : ""}<br />{a.city}, {a.state} {a.pincode}</p><button onClick={() => removeAddress(a.id)} className="absolute top-3 right-3 p-1.5 text-stone-400 hover:text-rose-500"><Trash2 className="h-4 w-4" /></button></div>)}</div>
              )}
            </Card>
          )}

          {tab === "payments" && (
            <Card title="Saved Payment Methods" action={<DemoTag>UI only</DemoTag>}>
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="rounded-2xl bg-gradient-to-br from-stone-900 to-stone-700 text-white p-5 aspect-[1.7]"><p className="text-[10px] uppercase tracking-widest text-stone-400">Demo Card</p><p className="font-mono text-lg mt-6">•••• •••• •••• 1111</p><div className="flex justify-between text-xs mt-4"><span>{profile.name || "SOLARA SHOPPER"}</span><span>12/28</span></div></div>
                <div className="rounded-2xl border border-stone-200 p-5 flex flex-col justify-between"><div><p className="text-sm font-medium">UPI</p><p className="text-sm text-stone-500 font-mono mt-1">shopper@upi</p></div><p className="text-[11px] text-stone-500">No real payment credentials are stored. Tokenised cards would be managed by your payment gateway.</p></div>
              </div>
            </Card>
          )}

          {tab === "coupons" && (
            <Card title="Coupons" action={<DemoTag>Demo coupons</DemoTag>}>
              <div className="grid sm:grid-cols-2 gap-3">
                {coupons.map((c) => (
                  <div key={c.id} className="rounded-2xl border-2 border-dashed border-amber-300 bg-amber-50/50 p-4 flex items-center justify-between gap-3">
                    <div><p className="font-mono font-bold text-lg tracking-wide">{c.code}</p><p className="text-xs text-stone-600">{c.description}</p>{parseFloat(c.minOrder) > 0 && <p className="text-[11px] text-stone-400">Min. order {formatINR(c.minOrder)}</p>}</div>
                    <button onClick={() => { navigator.clipboard.writeText(c.code); toast({ title: `${c.code} copied`, tone: "success" }); }} className="h-9 w-9 rounded-full bg-white border border-amber-200 flex items-center justify-center text-amber-700"><Copy className="h-4 w-4" /></button>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {tab === "recent" && (
            <Card title="Recently Viewed">
              {recent.length === 0 ? <EmptyState icon={<Clock className="h-6 w-6" />} title="No history yet" /> : <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">{recent.map((p) => <Link key={p.id} href={`/product/${p.slug}`} className="rounded-2xl border border-stone-200 p-2"><img src={p.image} alt="" className="aspect-square rounded-xl object-cover" /><p className="text-xs font-medium mt-2 line-clamp-1">{p.name}</p><p className="text-xs text-stone-500">{formatINR(p.price)}</p></Link>)}</div>}
            </Card>
          )}

          {tab === "reviews" && (
            <Card title="Product Reviews">
              <EmptyState icon={<Star className="h-6 w-6" />} title="You haven't reviewed anything yet" body="After an order is delivered you can rate the products you bought. (Demo — review submission is simulated.)" action={<button onClick={() => go("orders")} className="px-5 py-2.5 rounded-full bg-stone-900 text-white text-sm">See my orders</button>} />
            </Card>
          )}

          {tab === "notifications" && (
            <Card title="Notifications" action={notifications.length > 0 && <button onClick={() => setConfirmClear(true)} className="text-sm text-stone-500 hover:text-rose-600">Clear all</button>}>
              {notifications.length === 0 ? <EmptyState icon={<Bell className="h-6 w-6" />} title="You're all caught up" /> : (
                <div className="space-y-2">
                  {notifications.map((n) => (
                    <div key={n.id} className="flex items-start gap-3 rounded-2xl border border-stone-200 p-4">
                      <span className={cn("mt-1 h-2 w-2 rounded-full shrink-0", n.kind === "order" ? "bg-teal-500" : n.kind === "deal" ? "bg-amber-500" : n.kind === "wishlist" ? "bg-rose-500" : "bg-stone-400")} />
                      <div className="flex-1 min-w-0"><p className="text-sm font-medium">{n.title}</p><p className="text-sm text-stone-600">{n.body}</p><p className="text-[11px] text-stone-400 mt-1">{fmtDate(n.at, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</p></div>
                      {n.href && <Link href={n.href} className="text-xs font-medium underline shrink-0">Open</Link>}
                    </div>
                  ))}
                </div>
              )}
              <ConfirmDialog open={confirmClear} title="Clear all notifications?" body="This can't be undone." confirmLabel="Clear" danger onConfirm={() => { clearNotifications(); setConfirmClear(false); }} onCancel={() => setConfirmClear(false)} />
            </Card>
          )}

          {tab === "settings" && (
            <Card title="Settings">
              <div className="space-y-4">
                {["Order updates via email", "Deal alerts", "Wishlist price-drop alerts", "SMS notifications"].map((s, i) => (
                  <label key={s} className="flex items-center justify-between rounded-2xl border border-stone-200 p-4"><span className="text-sm">{s}</span><input type="checkbox" defaultChecked={i < 3} className="h-4 w-4 accent-stone-900" /></label>
                ))}
                <button onClick={() => { if (confirm("Clear all local data (cart, wishlist, profile)?")) { localStorage.clear(); location.href = "/"; } }} className="px-4 py-2.5 rounded-full border border-rose-200 text-rose-600 text-sm font-medium hover:bg-rose-50">Clear local data</button>
              </div>
            </Card>
          )}
          {!hydrated && null}
        </div>
      </div>
    </main>
  );
}
