"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { PackageSearch, ArrowRight } from "lucide-react";
import { useStore } from "@/lib/store-context";

export default function TrackPage() {
  const router = useRouter();
  const { profile } = useStore();
  const [id, setId] = useState("");
  return (
    <main className="mx-auto max-w-xl px-4 py-16">
      <div className="rounded-3xl bg-white border border-stone-200 p-8 text-center">
        <div className="h-14 w-14 mx-auto rounded-2xl bg-stone-100 flex items-center justify-center"><PackageSearch className="h-7 w-7 text-stone-700" /></div>
        <h1 className="mt-4 text-2xl font-[500] tracking-[-0.02em]">Track your order</h1>
        <p className="text-sm text-stone-500 mt-1">Enter your order ID, e.g. SOLARA-20260918-48291</p>
        <form onSubmit={(e) => { e.preventDefault(); if (id.trim()) router.push(`/orders/${id.trim().toUpperCase()}`); }} className="mt-6 flex gap-2">
          <input value={id} onChange={(e) => setId(e.target.value)} placeholder="SOLARA-XXXXXXXX-XXXXX" className="flex-1 h-12 px-4 rounded-full bg-stone-50 border border-stone-200 text-sm font-mono uppercase outline-none focus:border-stone-400" />
          <button className="h-12 px-5 rounded-full bg-stone-900 text-white text-sm font-semibold inline-flex items-center gap-2">Track <ArrowRight className="h-4 w-4" /></button>
        </form>
        {profile.orderIds.length > 0 && (
          <div className="mt-6 text-left">
            <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-stone-400 mb-2">Your recent orders</p>
            <div className="space-y-1">{profile.orderIds.slice(0, 5).map((o) => <Link key={o} href={`/orders/${o}`} className="block px-3 py-2 rounded-xl bg-stone-50 hover:bg-stone-100 text-sm font-mono">{o}</Link>)}</div>
          </div>
        )}
      </div>
    </main>
  );
}
