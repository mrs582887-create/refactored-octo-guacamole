"use client";

import Link from "next/link";
import { GitCompareArrows, X, ShoppingBag } from "lucide-react";
import { useStore } from "@/lib/store-context";
import { formatINR } from "@/lib/utils";
import { EmptyState, Breadcrumbs, Stars } from "@/components/ui";

const ROWS = ["Processor", "RAM", "Storage", "Battery", "Display", "Camera", "Material", "Capacity", "Weight"];

function specValue(specs: string[] | null | undefined, key: string) {
  const hit = (specs || []).find((s) => s.toLowerCase().startsWith(key.toLowerCase()));
  return hit ? hit.split(":").slice(1).join(":").trim() || hit : "—";
}

export default function ComparePage() {
  const { compare, toggleCompare, clearCompare, addToCart, hydrated } = useStore();
  return (
    <main className="mx-auto max-w-7xl px-4 lg:px-8 py-8">
      <Breadcrumbs items={[{ label: "Compare" }]} />
      <div className="flex items-end justify-between mb-6">
        <div><h1 className="text-3xl font-[480] tracking-[-0.03em]">Compare Products</h1><p className="text-sm text-stone-500 mt-1">{compare.length} of 4 selected</p></div>
        {compare.length > 0 && <button onClick={clearCompare} className="text-sm text-stone-600 underline">Clear all</button>}
      </div>
      {hydrated && compare.length === 0 ? (
        <EmptyState icon={<GitCompareArrows className="h-7 w-7" />} title="Nothing to compare yet" body="Use the compare icon on product cards to add up to 4 products." action={<Link href="/products" className="px-5 py-2.5 rounded-full bg-stone-900 text-white text-sm font-medium">Browse products</Link>} />
      ) : (
        <div className="overflow-x-auto rounded-3xl border border-stone-200 bg-white">
          <table className="w-full text-sm min-w-[720px]">
            <thead>
              <tr className="align-top">
                <th className="w-40 p-4 text-left text-[10px] font-bold uppercase tracking-[0.12em] text-stone-400">Product</th>
                {compare.map((p) => (
                  <th key={p.id} className="p-4 text-left font-normal">
                    <div className="relative">
                      <button onClick={() => toggleCompare(p)} className="absolute -top-2 -right-2 h-7 w-7 rounded-full bg-white border border-stone-200 flex items-center justify-center hover:bg-stone-100"><X className="h-3.5 w-3.5" /></button>
                      <Link href={`/product/${p.slug}`}><img src={p.image} alt="" className="w-full aspect-[4/3] rounded-2xl object-cover bg-stone-100" /></Link>
                      <p className="mt-3 text-[11px] uppercase tracking-wider text-stone-400">{p.brand}</p>
                      <Link href={`/product/${p.slug}`} className="block font-medium leading-snug hover:underline">{p.name}</Link>
                    </div>
                  </th>
                ))}
                {Array.from({ length: 4 - compare.length }).map((_, i) => <th key={i} className="p-4"><Link href="/products" className="flex items-center justify-center aspect-[4/3] rounded-2xl border-2 border-dashed border-stone-200 text-xs text-stone-400 hover:border-stone-400 hover:text-stone-700">+ Add product</Link></th>)}
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              <Row label="Price">{compare.map((p) => <td key={p.id} className="p-4 font-semibold text-base">{formatINR(p.price)}{p.originalPrice && <span className="ml-1 text-xs text-stone-400 line-through font-normal">{formatINR(p.originalPrice)}</span>}</td>)}</Row>
              <Row label="Rating">{compare.map((p) => <td key={p.id} className="p-4"><Stars rating={p.rating} size="h-3.5 w-3.5" /> <span className="text-xs text-stone-500 ml-1">{p.rating}</span></td>)}</Row>
              {ROWS.map((r) => <Row key={r} label={r}>{compare.map((p) => <td key={p.id} className="p-4 text-stone-700">{specValue(p.specs, r)}</td>)}</Row>)}
              <Row label="Warranty">{compare.map((p) => <td key={p.id} className="p-4 text-stone-700">{p.warranty || "—"}</td>)}</Row>
              <Row label="Delivery">{compare.map((p) => <td key={p.id} className="p-4 text-stone-700">{p.deliveryDays ? `${p.deliveryDays} day${p.deliveryDays > 1 ? "s" : ""}` : "—"}</td>)}</Row>
              <Row label="Availability">{compare.map((p) => <td key={p.id} className={`p-4 font-medium ${p.stock > 0 ? "text-teal-700" : "text-rose-600"}`}>{p.stock > 0 ? (p.stock <= 5 ? `Only ${p.stock} left` : "In stock") : "Out of stock"}</td>)}</Row>
              <Row label="Features">{compare.map((p) => <td key={p.id} className="p-4"><ul className="text-xs text-stone-600 space-y-1 list-disc pl-4">{(p.specs || []).slice(0, 5).map((s) => <li key={s}>{s}</li>)}</ul></td>)}</Row>
              <Row label="">{compare.map((p) => <td key={p.id} className="p-4"><button disabled={p.stock <= 0} onClick={() => addToCart({ productId: p.id, slug: p.slug, name: p.name, price: p.price, image: p.image, color: "", size: "", stock: p.stock })} className="w-full h-10 rounded-full bg-stone-900 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 disabled:opacity-40"><ShoppingBag className="h-3.5 w-3.5" /> Add to cart</button></td>)}</Row>
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return <tr><td className="p-4 text-[10px] font-bold uppercase tracking-[0.12em] text-stone-400 align-top">{label}</td>{children}</tr>;
}
