import { Suspense } from "react";
import { getAllProducts, getAllCategories } from "@/lib/queries";
import ProductGrid from "@/components/ProductGrid";
import { ProductSkeletonGrid } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function ProductsPage() {
  const [products, categories] = await Promise.all([getAllProducts(), getAllCategories()]);
  return (
    <main className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 lg:px-8 py-8">
        <Suspense fallback={<ProductSkeletonGrid count={12} />}>
          <ProductGrid products={products} categories={categories} />
        </Suspense>
      </div>
    </main>
  );
}
