import type { Metadata } from "next";
import type { ReactNode } from "react";
import { StoreProvider } from "@/lib/store-context";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import { MobileBottomNav, BackToTop, Toaster, AIAssistant } from "@/components/Widgets";
import "./globals.css";

export const metadata: Metadata = {
  title: "Solara Coast — Everything You Need. One Coast.",
  description: "Solara Coast is a premium multi-category marketplace: electronics, fashion, home, beauty, grocery, books, sports, automotive, travel, pets and daily essentials.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-stone-50 text-stone-900 antialiased font-sans selection:bg-rose-200/60 selection:text-rose-900 pb-16 lg:pb-0">
        <StoreProvider>
          <Header />
          <div className="page-enter">{children}</div>
          <Footer />
          <CartDrawer />
          <MobileBottomNav />
          <BackToTop />
          <AIAssistant />
          <Toaster />
        </StoreProvider>
      </body>
    </html>
  );
}
