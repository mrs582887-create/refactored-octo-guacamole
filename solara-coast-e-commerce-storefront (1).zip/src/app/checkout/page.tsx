"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, ArrowRight, Check, CheckCircle2, CreditCard, Landmark, Smartphone, Banknote, Truck, Zap, Lock, Mail, ShieldCheck, Loader2 } from "lucide-react";
import { useStore } from "@/lib/store-context";
import { computeTotals, formatINR, PAYMENT_METHODS, DELIVERY_METHODS, deliveryDate, fmtDate, cn, type CouponLike } from "@/lib/utils";
import { DemoTag } from "@/components/ui";

const STEPS = ["Customer", "Address", "Delivery", "Payment", "Review", "Confirmation"];

export default function CheckoutPage() {
  const router = useRouter();
  const { cart, cartSubtotal, couponCode, clearCart, profile, setProfile, addAddress, rememberOrder, notify, hydrated } = useStore();
  const [step, setStep] = useState(0);
  const [cust, setCust] = useState({ name: "", email: "", phone: "" });
  const [addr, setAddr] = useState({ fullName: "", line1: "", line2: "", city: "", state: "", pincode: "", country: "India" });
  const [saveAddr, setSaveAddr] = useState(true);
  const [delivery, setDelivery] = useState<string>("standard");
  const [payment, setPayment] = useState<string>("upi");
  const [payDetail, setPayDetail] = useState({ upi: "", card: "", expiry: "", cvv: "", bank: "" });
  const [coupon, setCoupon] = useState<CouponLike | null>(null);
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ orderId: string; expectedDelivery: string; total: string; notifications: { owner: string; customer: string } } | null>(null);

  useEffect(() => {
    if (profile.name || profile.email) setCust({ name: profile.name, email: profile.email, phone: profile.phone });
    const def = profile.addresses.find((a) => a.isDefault) || profile.addresses[0];
    if (def) setAddr({ fullName: def.fullName, line1: def.line1, line2: def.line2 || "", city: def.city, state: def.state, pincode: def.pincode, country: def.country });
  }, [profile]);

  useEffect(() => {
    if (!couponCode) { setCoupon(null); return; }
    fetch("/api/coupons/validate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: couponCode, subtotal: cartSubtotal }) })
      .then((r) => r.json()).then((d) => setCoupon(d.ok ? d.coupon : null)).catch(() => setCoupon(null));
  }, [couponCode, cartSubtotal]);

  const totals = useMemo(() => computeTotals({ subtotal: cartSubtotal, coupon, deliveryMethod: delivery }), [cartSubtotal, coupon, delivery]);
  const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cust.email);
  const canNext = [
    cust.name.trim().length > 1 && validEmail && cust.phone.replace(/\D/g, "").length >= 10,
    addr.fullName && addr.line1 && addr.city && addr.state && /^\d{6}$/.test(addr.pincode),
    true,
    payment === "cod" ? totals.total <= 50000 : payment === "upi" ? /.+@.+/.test(payDetail.upi) : payment === "net_banking" ? !!payDetail.bank : payDetail.card.replace(/\s/g, "").length >= 12 && payDetail.expiry && payDetail.cvv.length >= 3,
    true,
  ];

  const placeOrder = async () => {
    setPlacing(true); setError(null);
    try {
      const res = await fetch("/api/orders", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customer: cust, address: addr, items: cart.map((i) => ({ productId: i.productId, qty: i.qty, color: i.color, size: i.size })), couponCode, paymentMethod: payment, deliveryMethod: delivery }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not place order");
      setProfile({ name: cust.name, email: cust.email, phone: cust.phone });
      if (saveAddr && !profile.addresses.some((a) => a.line1 === addr.line1 && a.pincode === addr.pincode)) addAddress({ label: "Home", phone: cust.phone, isDefault: profile.addresses.length === 0, ...addr });
      rememberOrder(data.order.orderId);
      notify({ title: "Order placed", body: `${data.order.orderId} · ${formatINR(data.order.total)}`, kind: "order", href: `/orders/${data.order.orderId}` });
      setResult({ orderId: data.order.orderId, expectedDelivery: data.order.expectedDelivery, total: data.order.total, notifications: data.notifications });
      clearCart();
      setStep(5);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally { setPlacing(false); }
  };

  if (hydrated && cart.length === 0 && step < 5) {
    return (
      <main className="mx-auto max-w-lg px-6 py-24 text-center">
        <h1 className="text-2xl font-[500]">Your cart is empty</h1>
        <p className="text-stone-500 mt-2">Add a few things before checking out.</p>
        <Link href="/products" className="mt-6 inline-block px-6 py-3 rounded-full bg-stone-900 text-white text-sm font-semibold">Browse products</Link>
      </main>
    );
  }

  const input = "w-full h-11 px-3.5 rounded-xl bg-stone-50 border border-stone-200 text-sm outline-none focus:border-stone-400 focus:bg-white transition";
  const payIcon: Record<string, React.ReactNode> = { upi: <Smartphone className="h-4 w-4" />, credit_card: <CreditCard className="h-4 w-4" />, debit_card: <CreditCard className="h-4 w-4" />, net_banking: <Landmark className="h-4 w-4" />, cod: <Banknote className="h-4 w-4" /> };

  return (
    <main className="min-h-screen">
      <div className="mx-auto max-w-6xl px-4 lg:px-8 py-8">
        {step < 5 && <Link href="/products" className="inline-flex items-center gap-2 text-sm text-stone-500 hover:text-stone-900 mb-6"><ArrowLeft className="h-4 w-4" /> Continue shopping</Link>}

        {/* Stepper */}
        <ol className="flex items-center gap-1 sm:gap-2 mb-8 overflow-x-auto pb-1">
          {STEPS.map((s, i) => (
            <li key={s} className="flex items-center gap-1 sm:gap-2 shrink-0">
              <span className={cn("h-7 w-7 rounded-full text-[11px] font-bold flex items-center justify-center", i < step ? "bg-teal-500 text-white" : i === step ? "bg-stone-900 text-white" : "bg-stone-200 text-stone-500")}>{i < step ? <Check className="h-3.5 w-3.5" /> : i + 1}</span>
              <span className={cn("text-xs font-medium hidden sm:inline", i === step ? "text-stone-900" : "text-stone-400")}>{s}</span>
              {i < STEPS.length - 1 && <span className={cn("w-4 sm:w-8 h-px", i < step ? "bg-teal-500" : "bg-stone-200")} />}
            </li>
          ))}
        </ol>

        <div className={cn("grid gap-8", step < 5 && "lg:grid-cols-[1fr_380px]")}>
          <div>
            <AnimatePresence mode="wait">
              <motion.div key={step} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.2 }} className="rounded-3xl bg-white border border-stone-200 p-6 md:p-8">
                {step === 0 && (
                  <>
                    <h2 className="text-xl font-[520] tracking-[-0.02em]">Customer information</h2>
                    <p className="text-sm text-stone-500 mt-1">We'll use this to send order updates.</p>
                    <div className="mt-6 grid sm:grid-cols-2 gap-3">
                      <input className={input} placeholder="Full name" value={cust.name} onChange={(e) => setCust({ ...cust, name: e.target.value })} />
                      <input className={input} placeholder="Phone (10 digits)" value={cust.phone} onChange={(e) => setCust({ ...cust, phone: e.target.value })} />
                      <input className={cn(input, "sm:col-span-2")} type="email" placeholder="Email address" value={cust.email} onChange={(e) => setCust({ ...cust, email: e.target.value })} />
                    </div>
                  </>
                )}
                {step === 1 && (
                  <>
                    <h2 className="text-xl font-[520] tracking-[-0.02em]">Delivery address</h2>
                    {profile.addresses.length > 0 && (
                      <div className="mt-4 flex gap-2 flex-wrap">{profile.addresses.map((a) => <button key={a.id} onClick={() => setAddr({ fullName: a.fullName, line1: a.line1, line2: a.line2 || "", city: a.city, state: a.state, pincode: a.pincode, country: a.country })} className={cn("text-left rounded-xl border px-3 py-2 text-xs max-w-[240px]", addr.line1 === a.line1 && addr.pincode === a.pincode ? "border-stone-900 bg-stone-900 text-white" : "border-stone-200 hover:border-stone-400")}><span className="font-semibold">{a.label}</span> · {a.line1}, {a.city} {a.pincode}</button>)}</div>
                    )}
                    <div className="mt-5 grid sm:grid-cols-2 gap-3">
                      <input className={cn(input, "sm:col-span-2")} placeholder="Recipient full name" value={addr.fullName} onChange={(e) => setAddr({ ...addr, fullName: e.target.value })} />
                      <input className={cn(input, "sm:col-span-2")} placeholder="Flat / House no., Building, Street" value={addr.line1} onChange={(e) => setAddr({ ...addr, line1: e.target.value })} />
                      <input className={cn(input, "sm:col-span-2")} placeholder="Area, Landmark (optional)" value={addr.line2} onChange={(e) => setAddr({ ...addr, line2: e.target.value })} />
                      <input className={input} placeholder="City" value={addr.city} onChange={(e) => setAddr({ ...addr, city: e.target.value })} />
                      <input className={input} placeholder="State" value={addr.state} onChange={(e) => setAddr({ ...addr, state: e.target.value })} />
                      <input className={input} placeholder="Pincode (6 digits)" value={addr.pincode} onChange={(e) => setAddr({ ...addr, pincode: e.target.value.replace(/\D/g, "").slice(0, 6) })} />
                      <input className={input} placeholder="Country" value={addr.country} onChange={(e) => setAddr({ ...addr, country: e.target.value })} />
                    </div>
                    <label className="mt-4 flex items-center gap-2 text-sm text-stone-600"><input type="checkbox" checked={saveAddr} onChange={(e) => setSaveAddr(e.target.checked)} className="accent-stone-900" /> Save this address to my account</label>
                  </>
                )}
                {step === 2 && (
                  <>
                    <h2 className="text-xl font-[520] tracking-[-0.02em]">Delivery method</h2>
                    <div className="mt-6 space-y-3">
                      {DELIVERY_METHODS.map((d) => (
                        <button key={d.id} onClick={() => setDelivery(d.id)} className={cn("w-full flex items-center gap-4 rounded-2xl border p-4 text-left transition", delivery === d.id ? "border-stone-900 ring-2 ring-stone-900/10" : "border-stone-200 hover:border-stone-400")}>
                          <span className="h-10 w-10 rounded-xl bg-stone-100 flex items-center justify-center">{d.id === "express" ? <Zap className="h-5 w-5 text-amber-500" /> : <Truck className="h-5 w-5 text-stone-700" />}</span>
                          <span className="flex-1"><span className="block text-sm font-medium">{d.label}</span><span className="block text-xs text-stone-500">Arrives by {fmtDate(deliveryDate(d.days), { weekday: "long", day: "numeric", month: "short" })} · {d.hint}</span></span>
                          <span className="text-sm font-semibold">{d.id === "standard" && (cartSubtotal >= 999 || totals.freeShip) ? "FREE" : formatINR(d.price)}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
                {step === 3 && (
                  <>
                    <div className="flex items-center justify-between"><h2 className="text-xl font-[520] tracking-[-0.02em]">Payment method</h2><DemoTag>Test / Demo payments</DemoTag></div>
                    <p className="text-sm text-stone-500 mt-1">No real payment is processed. Card / UPI details are never sent to our server.</p>
                    <div className="mt-6 grid sm:grid-cols-2 gap-2">
                      {PAYMENT_METHODS.map((p) => (
                        <button key={p.id} onClick={() => setPayment(p.id)} className={cn("flex items-center gap-3 rounded-2xl border p-3.5 text-left transition", payment === p.id ? "border-stone-900 ring-2 ring-stone-900/10" : "border-stone-200 hover:border-stone-400")}>
                          <span className="h-9 w-9 rounded-xl bg-stone-100 flex items-center justify-center">{payIcon[p.id]}</span>
                          <span><span className="block text-sm font-medium">{p.label}</span><span className="block text-[11px] text-stone-500">{p.hint}</span></span>
                        </button>
                      ))}
                    </div>
                    <div className="mt-5 rounded-2xl bg-stone-50 border border-stone-200 p-4">
                      {payment === "upi" && <input className={input} placeholder="UPI ID e.g. name@upi" value={payDetail.upi} onChange={(e) => setPayDetail({ ...payDetail, upi: e.target.value })} />}
                      {(payment === "credit_card" || payment === "debit_card") && (
                        <div className="grid grid-cols-2 gap-3">
                          <input className={cn(input, "col-span-2")} placeholder="Card number (use 4111 1111 1111 1111)" value={payDetail.card} onChange={(e) => setPayDetail({ ...payDetail, card: e.target.value })} />
                          <input className={input} placeholder="MM/YY" value={payDetail.expiry} onChange={(e) => setPayDetail({ ...payDetail, expiry: e.target.value })} />
                          <input className={input} placeholder="CVV" type="password" value={payDetail.cvv} onChange={(e) => setPayDetail({ ...payDetail, cvv: e.target.value })} />
                        </div>
                      )}
                      {payment === "net_banking" && (
                        <select className={input} value={payDetail.bank} onChange={(e) => setPayDetail({ ...payDetail, bank: e.target.value })}><option value="">Select bank</option>{["HDFC Bank", "ICICI Bank", "State Bank of India", "Axis Bank", "Kotak Mahindra"].map((b) => <option key={b}>{b}</option>)}</select>
                      )}
                      {payment === "cod" && <p className="text-sm text-stone-600">{totals.total <= 50000 ? `Pay ${formatINR(totals.total)} in cash or UPI when your order arrives.` : "Cash on Delivery is available for orders up to ₹50,000. Please choose another method."}</p>}
                      <p className="mt-3 text-[11px] text-stone-500 flex items-center gap-1.5"><Lock className="h-3 w-3" /> Demo mode: details stay in your browser and are discarded. Connect a payment gateway (Razorpay/Stripe) server-side to go live.</p>
                    </div>
                  </>
                )}
                {step === 4 && (
                  <>
                    <h2 className="text-xl font-[520] tracking-[-0.02em]">Review your order</h2>
                    <div className="mt-6 grid sm:grid-cols-3 gap-3 text-sm">
                      <ReviewBox title="Customer" onEdit={() => setStep(0)}>{cust.name}<br />{cust.email}<br />{cust.phone}</ReviewBox>
                      <ReviewBox title="Deliver to" onEdit={() => setStep(1)}>{addr.fullName}<br />{addr.line1}{addr.line2 ? `, ${addr.line2}` : ""}<br />{addr.city}, {addr.state} {addr.pincode}</ReviewBox>
                      <ReviewBox title="Delivery & Payment" onEdit={() => setStep(3)}>{DELIVERY_METHODS.find((d) => d.id === delivery)?.label}<br />{PAYMENT_METHODS.find((p) => p.id === payment)?.label}<br /><span className="text-stone-500">by {fmtDate(deliveryDate(totals.deliveryDays), { weekday: "short", day: "numeric", month: "short" })}</span></ReviewBox>
                    </div>
                    <div className="mt-6 divide-y divide-stone-100 border-y border-stone-100">
                      {cart.map((i) => <div key={`${i.productId}-${i.color}-${i.size}`} className="flex items-center gap-3 py-3"><img src={i.image} alt="" className="h-14 w-14 rounded-xl object-cover" /><div className="flex-1 min-w-0"><p className="text-sm font-medium truncate">{i.name}</p><p className="text-xs text-stone-500">{[i.color, i.size].filter(Boolean).join(" · ")} × {i.qty}</p></div><span className="text-sm font-semibold">{formatINR(parseFloat(i.price) * i.qty)}</span></div>)}
                    </div>
                    {error && <p className="mt-4 text-sm text-rose-600 bg-rose-50 rounded-xl px-4 py-3">{error}</p>}
                    <p className="mt-4 text-[11px] text-stone-500 flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> Totals are recalculated on the server from catalog prices before the order is saved.</p>
                  </>
                )}
                {step === 5 && result && (
                  <div className="text-center py-6">
                    <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 200, damping: 12 }} className="h-20 w-20 mx-auto rounded-full bg-teal-50 flex items-center justify-center"><CheckCircle2 className="h-10 w-10 text-teal-600" /></motion.div>
                    <h2 className="mt-5 text-2xl md:text-3xl font-[500] tracking-[-0.03em]">Order confirmed!</h2>
                    <p className="text-stone-500 mt-2">Thanks, {cust.name.split(" ")[0]}. Your order has been placed.</p>
                    <div className="mt-6 inline-flex flex-col items-center rounded-2xl bg-stone-950 text-white px-8 py-5">
                      <span className="text-[10px] uppercase tracking-[0.2em] text-stone-400">Order ID</span>
                      <span className="text-xl font-mono font-semibold mt-1">{result.orderId}</span>
                      <span className="text-xs text-stone-400 mt-2">Total {formatINR(result.total)} · Expected by {fmtDate(result.expectedDelivery, { weekday: "long", day: "numeric", month: "long" })}</span>
                    </div>
                    <div className="mt-6 grid sm:grid-cols-2 gap-3 max-w-xl mx-auto text-left">
                      <NotifCard title="Store owner notification" status={result.notifications.owner} icon={<Mail className="h-4 w-4" />} detail={result.notifications.owner === "sent" ? "Webhook delivered to STORE_ORDER_WEBHOOK_URL." : result.notifications.owner === "failed" ? "Webhook call failed — see admin logs." : "Order notification simulated successfully. Set STORE_ORDER_WEBHOOK_URL to send it to the owner's Gmail via n8n / Make / Zapier."} />
                      <NotifCard title={`Customer email → ${cust.email}`} status={result.notifications.customer} icon={<Mail className="h-4 w-4" />} detail={result.notifications.customer === "sent" ? "Confirmation email sent." : result.notifications.customer === "failed" ? "Email provider returned an error." : "Confirmation email prepared but NOT sent (demo mode). Configure RESEND_API_KEY or CUSTOMER_EMAIL_WEBHOOK_URL to enable."} />
                    </div>
                    <div className="mt-8 flex flex-wrap justify-center gap-3">
                      <Link href={`/orders/${result.orderId}`} className="px-6 py-3 rounded-full bg-stone-900 text-white text-sm font-semibold inline-flex items-center gap-2">Track order <ArrowRight className="h-4 w-4" /></Link>
                      <Link href="/products" className="px-6 py-3 rounded-full border border-stone-300 text-sm font-medium">Continue shopping</Link>
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            {step < 5 && (
              <div className="mt-5 flex items-center justify-between">
                <button onClick={() => setStep(Math.max(0, step - 1))} disabled={step === 0} className="px-5 py-2.5 rounded-full text-sm font-medium text-stone-600 hover:bg-stone-100 disabled:opacity-30">Back</button>
                {step < 4 ? (
                  <button onClick={() => setStep(step + 1)} disabled={!canNext[step]} className="px-6 py-3 rounded-full bg-stone-900 text-white text-sm font-semibold disabled:opacity-40 inline-flex items-center gap-2">Continue <ArrowRight className="h-4 w-4" /></button>
                ) : (
                  <button onClick={placeOrder} disabled={placing} className="px-7 py-3 rounded-full bg-amber-400 text-amber-950 text-sm font-semibold hover:bg-amber-300 disabled:opacity-60 inline-flex items-center gap-2">{placing ? <><Loader2 className="h-4 w-4 animate-spin" /> Placing order…</> : <>Place order · {formatINR(totals.total)}</>}</button>
                )}
              </div>
            )}
          </div>

          {step < 5 && (
            <aside className="lg:sticky lg:top-32 self-start rounded-3xl bg-white border border-stone-200 p-6">
              <h3 className="text-base font-[550]">Order summary</h3>
              <div className="mt-4 space-y-3 max-h-64 overflow-y-auto pr-1">
                {cart.map((i) => <div key={`${i.productId}-${i.color}-${i.size}`} className="flex items-center gap-3"><img src={i.image} alt="" className="h-12 w-12 rounded-lg object-cover" /><div className="flex-1 min-w-0"><p className="text-xs font-medium truncate">{i.name}</p><p className="text-[11px] text-stone-500">× {i.qty}</p></div><span className="text-xs font-semibold">{formatINR(parseFloat(i.price) * i.qty)}</span></div>)}
              </div>
              <div className="mt-5 pt-4 border-t border-stone-100 space-y-1.5 text-sm text-stone-600">
                <div className="flex justify-between"><span>Subtotal</span><span>{formatINR(totals.subtotal)}</span></div>
                {totals.discount > 0 && <div className="flex justify-between text-teal-700"><span>Discount ({coupon?.code})</span><span>- {formatINR(totals.discount)}</span></div>}
                <div className="flex justify-between"><span>Shipping</span><span>{totals.shipping === 0 ? "FREE" : formatINR(totals.shipping)}</span></div>
                <div className="flex justify-between"><span>Tax (GST 5%)</span><span>{formatINR(totals.tax)}</span></div>
                <div className="flex justify-between pt-2 border-t border-stone-100 text-stone-900 text-base font-semibold"><span>Total</span><span>{formatINR(totals.total)}</span></div>
              </div>
              {!couponCode && <p className="mt-3 text-[11px] text-stone-500">Have a coupon? Apply it from the cart drawer.</p>}
            </aside>
          )}
        </div>
      </div>
    </main>
  );
}

function ReviewBox({ title, children, onEdit }: { title: string; children: React.ReactNode; onEdit: () => void }) {
  return (
    <div className="rounded-2xl bg-stone-50 border border-stone-200 p-4">
      <div className="flex items-center justify-between mb-2"><p className="text-[10px] font-bold uppercase tracking-[0.12em] text-stone-400">{title}</p><button onClick={onEdit} className="text-[11px] text-stone-600 underline">Edit</button></div>
      <p className="text-sm text-stone-800 leading-relaxed">{children}</p>
    </div>
  );
}

function NotifCard({ title, status, detail, icon }: { title: string; status: string; detail: string; icon: React.ReactNode }) {
  const tone = status === "sent" ? "bg-teal-50 border-teal-200 text-teal-800" : status === "failed" ? "bg-rose-50 border-rose-200 text-rose-800" : "bg-amber-50 border-amber-200 text-amber-900";
  return (
    <div className={cn("rounded-2xl border p-4", tone)}>
      <div className="flex items-center gap-2 text-sm font-medium">{icon}<span className="truncate">{title}</span><span className="ml-auto text-[10px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded bg-white/70">{status}</span></div>
      <p className="mt-1.5 text-xs opacity-90 leading-relaxed">{detail}</p>
    </div>
  );
}
