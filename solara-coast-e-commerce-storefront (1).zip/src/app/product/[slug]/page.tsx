import { notFound } from "next/navigation";
import { getProductBySlug, getReviewsForProduct, getQuestionsForProduct, getAllProducts } from "@/lib/queries";
import ProductDetailClient from "./ProductDetailClient";
import ProductCarousel from "@/components/ProductCarousel";

export const dynamic = "force-dynamic";

export default async function ProductDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();
  const [reviews, questions, all] = await Promise.all([getReviewsForProduct(product.id), getQuestionsForProduct(product.id), getAllProducts()]);
  const similar = all.filter((p) => p.id !== product.id && p.categorySlug === product.categorySlug).slice(0, 8);
  const more = all.filter((p) => p.id !== product.id && p.departmentSlug === product.departmentSlug && p.categorySlug !== product.categorySlug);
  const fbt = [...more.filter((p) => (p.tags || []).some((t) => (product.tags || []).includes(t))), ...more].filter((p, i, a) => a.indexOf(p) === i).slice(0, 2);
  const fromDept = more.slice(0, 8);

  return (
    <main className="min-h-screen bg-white">
      <ProductDetailClient product={product} reviews={reviews} questions={questions} fbt={fbt} />
      <ProductCarousel products={similar.length ? similar : fromDept} eyebrow="You may also like" title="Similar Products" subtitle={`More in ${product.categoryName}`} href={`/products?cat=${product.categorySlug}`} />
      {similar.length > 0 && <ProductCarousel products={fromDept} title={`More from ${product.department}`} href={`/products?dept=${product.departmentSlug}`} />}
    </main>
  );
}
