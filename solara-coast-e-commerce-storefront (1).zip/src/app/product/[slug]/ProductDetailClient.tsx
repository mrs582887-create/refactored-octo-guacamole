"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Heart, GitCompareArrows, Share2, Minus, Plus, ShieldCheck, Truck, RotateCcw, Play, MapPin, Eye, Flame, ZoomIn, MessageCircleQuestion, ShoppingBag, Zap, Check } from "lucide-react";
import type { Product, Review, Question } from "@/db/schema";
import { useStore, toMini } from "@/lib/store-context";
import { formatINR, discountPct, stockStatus, deliveryDate, fmtDate, cn } from "@/lib/utils";
import { Stars, Breadcrumbs, DemoTag, Badge } from "@/components/ui";
import { useRouter } from "next/navigation";

export default function ProductDetailClient({ product, reviews, questions, fbt }: { product: Product; reviews: Review[]; questions: Question[]; fbt: Product[] }) {
  const router = useRouter();
  const { addToCart, toggleWishlist, inWishlist, toggleCompare, inCompare, addRecent, toast } = useStore();
  const images = product.images && product.images.length ? product.images : [product.imageMain];
  const [img, setImg] = useState(0);
  const [zoom, setZoom] = useState<{ x: number; y: number } | null>(null);
  const [qty, setQty] = useState(1);
  const [color, setColor] = useState(product.colors?.[0] || "");
  const [size, setSize] = useState(product.sizes?.[0] || "");
  const [pin, setPin] = useState("");
  const [pinResult, setPinResult] = useState<string | null>(null);
  const [tab, setTab] = useState<"specs" | "reviews" | "qa">("specs");
  const [fbtSel, setFbtSel] = useState<number[]>(fbt.map((p) => p.id));
  const [viewers] = useState(() => 6 + (product.id % 14));

  useEffect(() => { addRecent(toMini(product)); }, [product, addRecent]);

  const pct = discountPct(product);
  const stock = stockStatus(product.stock);
  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : parseFloat(product.rating);
  const dist = [5, 4, 3, 2, 1].map((s) => ({ s, n: reviews.filter((r) => r.rating === s).length }));
  const wished = inWishlist(product.id);
  const compared = inCompare(product.id);
  const fbtTotal = useMemo(() => parseFloat(product.price) + fbt.filter((p) => fbtSel.includes(p.id)).reduce((s, p) => s + parseFloat(p.price), 0), [fbt, fbtSel, product.price]);

  const add = (silent = false) => {
    if (product.stock <= 0) return;
    addToCart({ productId: product.id, slug: product.slug, name: product.name, price: product.price, image: product.imageMain, color, size, stock: product.stock, qty }, { silent });
  };
  const buyNow = () => { add(true); router.push("/checkout"); };
  const addBundle = () => {
    add(true);
    fbt.filter((p) => fbtSel.includes(p.id) && p.stock > 0).forEach((p) => addToCart({ productId: p.id, slug: p.slug, name: p.name, price: p.price, image: p.imageMain, color: p.colors?.[0] || "", size: p.sizes?.[0] || "", stock: p.stock }, { silent: true }));
    toast({ title: "Bundle added to cart", tone: "success" });
  };
  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: product.name, url });
      else { await navigator.clipboard.writeText(url); toast({ title: "Link copied", tone: "success" }); }
    } catch {}
  };
  const checkPin = () => {
    if (!/^\d{6}$/.test(pin)) { setPinResult("Enter a valid 6-digit pincode."); return; }
    const express = /^(1|4|5|56|60|70)/.test(pin);
    setPinResult(`Deliverable to ${pin}. ${express ? "Express (next-day) available. " : ""}Standard delivery by ${fmtDate(deliveryDate(product.deliveryDays), { weekday: "long", day: "numeric", month: "short" })}. Cash on Delivery ${parseFloat(product.price) <= 50000 ? "available" : "not available"}.`);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 lg:px-8 pt-6 pb-8">
      <Breadcrumbs items={[{ label: product.department, href: `/products?dept=${product.departmentSlug}` }, { label: product.categoryName, href: `/products?cat=${product.categorySlug}` }, { label: product.name }]} />

      <div className="grid lg:grid-cols-[1.05fr_1fr] gap-10 lg:gap-16">
        {/* Gallery */}
        <div className="lg:sticky lg:top-32 self-start">
          <div className="flex gap-3">
            <div className="hidden sm:flex flex-col gap-2 w-16 shrink-0">
              {images.map((src, i) => <button key={i} onClick={() => setImg(i)} className={cn("aspect-square rounded-xl overflow-hidden ring-2 transition", img === i ? "ring-stone-900" : "ring-transparent opacity-60 hover:opacity-100")}><img src={src} alt="" className="h-full w-full object-cover" /></button>)}
              <button className="aspect-square rounded-xl bg-stone-950 text-white flex flex-col items-center justify-center gap-0.5 text-[9px] font-semibold uppercase tracking-wide"><Play className="h-4 w-4" />Video</button>
            </div>
            <div className="flex-1">
              <motion.div
                key={img}
                initial={{ opacity: 0.6 }}
                animate={{ opacity: 1 }}
                onMouseMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); setZoom({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 }); }}
                onMouseLeave={() => setZoom(null)}
                className="relative aspect-[4/5] rounded-3xl overflow-hidden bg-stone-100 ring-1 ring-stone-200/60 cursor-zoom-in"
              >
                <img src={images[img]} alt={product.name} className="absolute inset-0 h-full w-full object-cover transition-transform duration-200" style={zoom ? { transform: "scale(2)", transformOrigin: `${zoom.x}% ${zoom.y}%` } : undefined} />
                <div className="absolute top-3 left-3 flex gap-1.5">{pct > 0 && <Badge tone="rose">-{pct}%</Badge>}{product.flashDeal && <Badge tone="amber">Deal</Badge>}</div>
                {!zoom && <span className="absolute bottom-3 right-3 h-8 w-8 rounded-full bg-white/90 flex items-center justify-center text-stone-600"><ZoomIn className="h-4 w-4" /></span>}
              </motion.div>
              <div className="sm:hidden mt-3 flex gap-2 overflow-x-auto">{images.map((src, i) => <button key={i} onClick={() => setImg(i)} className={cn("h-16 w-16 shrink-0 rounded-xl overflow-hidden ring-2", img === i ? "ring-stone-900" : "ring-transparent opacity-60")}><img src={src} alt="" className="h-full w-full object-cover" /></button>)}</div>
              <div className="mt-3 rounded-2xl bg-stone-950 text-white p-4 flex items-center gap-3">
                <span className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center"><Play className="h-4 w-4" /></span>
                <div className="flex-1"><p className="text-sm font-medium">Product video</p><p className="text-[11px] text-stone-400">Video preview placeholder — connect a media host to enable.</p></div>
                <DemoTag>Placeholder</DemoTag>
              </div>
            </div>
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <Link href={`/products?brand=${encodeURIComponent(product.brand)}`} className="text-[11px] font-bold uppercase tracking-[0.14em] text-amber-600 hover:underline">{product.brand}</Link>
            <span className="text-stone-300">·</span>
            <span className="text-[11px] text-stone-500">SKU {product.sku}</span>
            {product.newArrival && <Badge tone="teal">New</Badge>}{product.bestSeller && <Badge tone="violet">Best Seller</Badge>}
          </div>
          <h1 className="mt-2 text-3xl md:text-4xl font-[480] tracking-[-0.03em] leading-[1.08] text-stone-950">{product.name}</h1>
          <p className="mt-2 text-lg text-stone-500 font-light">{product.tagline}</p>
          <div className="mt-3 flex items-center gap-3">
            <Stars rating={avg} /><span className="text-sm font-semibold">{avg.toFixed(1)}</span>
            <button onClick={() => setTab("reviews")} className="text-sm text-stone-500 hover:underline">{product.reviewCount.toLocaleString("en-IN")} ratings · {reviews.length} reviews</button>
          </div>

          <div className="mt-5 flex items-end gap-3 flex-wrap">
            <span className="text-3xl md:text-4xl font-[600] tracking-[-0.02em]">{formatINR(product.price)}</span>
            {pct > 0 && product.originalPrice && <><span className="text-lg text-stone-400 line-through">{formatINR(product.originalPrice)}</span><span className="text-sm font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-full">Save {formatINR(parseFloat(product.originalPrice) - parseFloat(product.price))} ({pct}%)</span></>}
          </div>
          <p className="text-[11px] text-stone-500 mt-1">Inclusive of all taxes · EMI from {formatINR(parseFloat(product.price) / 12)}/mo (demo)</p>

          {/* Demo urgency indicators */}
          <div className="mt-4 flex flex-wrap gap-2 text-xs">
            <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full font-medium", stock.key === "in" ? "bg-teal-50 text-teal-700" : stock.key === "low" ? "bg-amber-50 text-amber-700" : "bg-rose-50 text-rose-700")}><span className={cn("h-1.5 w-1.5 rounded-full", stock.key === "in" ? "bg-teal-500" : stock.key === "low" ? "bg-amber-500" : "bg-rose-500")} />{stock.label}</span>
            {product.soldCount > 500 && product.stock > 0 && <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 font-medium"><Flame className="h-3 w-3" /> Selling fast</span>}
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-stone-100 text-stone-600"><Eye className="h-3 w-3" /> {viewers} people are viewing this</span>
            <DemoTag>Sample indicators</DemoTag>
          </div>

          {product.colors && product.colors.length > 0 && (
            <div className="mt-6">
              <p className="text-xs font-bold uppercase tracking-[0.1em] text-stone-400 mb-2">Color — <span className="text-stone-800 normal-case font-medium">{color}</span></p>
              <div className="flex flex-wrap gap-2">{product.colors.map((c) => <button key={c} onClick={() => setColor(c)} className={cn("px-3.5 py-2 rounded-xl text-sm border transition", color === c ? "border-stone-900 bg-stone-900 text-white" : "border-stone-200 hover:border-stone-400")}>{c}</button>)}</div>
            </div>
          )}
          {product.sizes && product.sizes.length > 0 && (
            <div className="mt-5">
              <p className="text-xs font-bold uppercase tracking-[0.1em] text-stone-400 mb-2">Size — <span className="text-stone-800 normal-case font-medium">{size}</span></p>
              <div className="flex flex-wrap gap-2">{product.sizes.map((s) => <button key={s} onClick={() => setSize(s)} className={cn("min-w-[52px] px-3 py-2 rounded-xl text-sm border transition", size === s ? "border-stone-900 bg-stone-900 text-white" : "border-stone-200 hover:border-stone-400")}>{s}</button>)}</div>
            </div>
          )}

          <div className="mt-7 flex flex-wrap items-center gap-3">
            <div className="flex items-center bg-stone-100 rounded-full p-1">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="h-9 w-9 rounded-full hover:bg-white flex items-center justify-center"><Minus className="h-4 w-4" /></button>
              <span className="w-8 text-center text-sm font-semibold tabular-nums">{qty}</span>
              <button onClick={() => setQty(Math.min(Math.max(1, product.stock), qty + 1))} className="h-9 w-9 rounded-full hover:bg-white flex items-center justify-center"><Plus className="h-4 w-4" /></button>
            </div>
            <button onClick={() => add()} disabled={product.stock <= 0} className="flex-1 min-w-[160px] h-12 rounded-full bg-stone-900 text-white text-sm font-semibold hover:bg-stone-800 disabled:opacity-40 shadow-xl shadow-stone-900/15 inline-flex items-center justify-center gap-2"><ShoppingBag className="h-4 w-4" /> Add to Cart</button>
            <button onClick={buyNow} disabled={product.stock <= 0} className="flex-1 min-w-[140px] h-12 rounded-full bg-amber-400 text-amber-950 text-sm font-semibold hover:bg-amber-300 disabled:opacity-40 inline-flex items-center justify-center gap-2"><Zap className="h-4 w-4" /> Buy Now</button>
          </div>
          <div className="mt-3 flex gap-2">
            <button onClick={() => toggleWishlist(toMini(product))} className={cn("inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border text-xs font-medium", wished ? "border-rose-200 bg-rose-50 text-rose-600" : "border-stone-200 hover:border-stone-400")}><Heart className={cn("h-3.5 w-3.5", wished && "fill-current")} /> {wished ? "Wishlisted" : "Wishlist"}</button>
            <button onClick={() => toggleCompare(toMini(product))} className={cn("inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border text-xs font-medium", compared ? "border-violet-200 bg-violet-50 text-violet-700" : "border-stone-200 hover:border-stone-400")}><GitCompareArrows className="h-3.5 w-3.5" /> {compared ? "In compare" : "Compare"}</button>
            <button onClick={share} className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border border-stone-200 hover:border-stone-400 text-xs font-medium"><Share2 className="h-3.5 w-3.5" /> Share</button>
          </div>

          {/* Delivery checker */}
          <div className="mt-6 rounded-2xl border border-stone-200 p-4">
            <div className="flex items-center gap-2 text-sm font-medium"><MapPin className="h-4 w-4 text-stone-500" /> Check delivery</div>
            <div className="mt-2 flex gap-2">
              <input value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="Enter 6-digit pincode" className="flex-1 h-10 px-3 rounded-xl bg-stone-50 border border-stone-200 text-sm outline-none focus:border-stone-400" />
              <button onClick={checkPin} className="h-10 px-4 rounded-xl bg-stone-900 text-white text-xs font-semibold">Check</button>
            </div>
            {pinResult && <p className="mt-2 text-xs text-stone-600">{pinResult}</p>}
            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-xl bg-stone-50 p-2.5"><Truck className="h-4 w-4 mx-auto text-stone-700" /><p className="mt-1 text-[10px] font-semibold text-stone-800">Delivery</p><p className="text-[10px] text-stone-500">by {fmtDate(deliveryDate(product.deliveryDays))}</p></div>
              <div className="rounded-xl bg-stone-50 p-2.5"><RotateCcw className="h-4 w-4 mx-auto text-stone-700" /><p className="mt-1 text-[10px] font-semibold text-stone-800">Returns</p><p className="text-[10px] text-stone-500">{product.returnDays > 0 ? `${product.returnDays}-day returns` : "Non-returnable"}</p></div>
              <div className="rounded-xl bg-stone-50 p-2.5"><ShieldCheck className="h-4 w-4 mx-auto text-stone-700" /><p className="mt-1 text-[10px] font-semibold text-stone-800">Warranty</p><p className="text-[10px] text-stone-500 line-clamp-2">{product.warranty}</p></div>
            </div>
          </div>

          <p className="mt-6 text-sm text-stone-600 leading-relaxed">{product.description}</p>

          {/* Frequently bought together */}
          {fbt.length > 0 && (
            <div className="mt-8 rounded-2xl bg-stone-50 border border-stone-200 p-4">
              <p className="text-sm font-[550] mb-3">Frequently bought together</p>
              <div className="flex items-center gap-2 flex-wrap">
                <img src={product.imageMain} alt="" className="h-16 w-16 rounded-xl object-cover ring-2 ring-stone-900" />
                {fbt.map((p) => (
                  <div key={p.id} className="flex items-center gap-2"><span className="text-stone-400">+</span>
                    <button onClick={() => setFbtSel((s) => (s.includes(p.id) ? s.filter((x) => x !== p.id) : [...s, p.id]))} className={cn("relative h-16 w-16 rounded-xl overflow-hidden ring-2 transition", fbtSel.includes(p.id) ? "ring-stone-900" : "ring-transparent opacity-50")}><img src={p.imageMain} alt="" className="h-full w-full object-cover" />{fbtSel.includes(p.id) && <span className="absolute top-1 right-1 h-4 w-4 rounded-full bg-stone-900 text-white flex items-center justify-center"><Check className="h-2.5 w-2.5" /></span>}</button>
                  </div>
                ))}
              </div>
              <ul className="mt-3 space-y-1 text-xs text-stone-600">
                <li className="flex justify-between"><span className="truncate pr-3">This item: {product.name}</span><span className="font-medium">{formatINR(product.price)}</span></li>
                {fbt.map((p) => <li key={p.id} className={cn("flex justify-between", !fbtSel.includes(p.id) && "opacity-40 line-through")}><Link href={`/product/${p.slug}`} className="truncate pr-3 hover:underline">{p.name}</Link><span className="font-medium">{formatINR(p.price)}</span></li>)}
              </ul>
              <div className="mt-3 flex items-center justify-between"><p className="text-sm">Total: <span className="font-semibold">{formatINR(fbtTotal)}</span></p><button onClick={addBundle} className="px-4 py-2 rounded-full bg-stone-900 text-white text-xs font-semibold">Add {1 + fbtSel.length} items to cart</button></div>
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-16">
        <div className="flex gap-1 border-b border-stone-200">
          {([["specs", "Specifications"], ["reviews", `Reviews (${reviews.length})`], ["qa", `Q&A (${questions.length})`]] as const).map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} className={cn("px-4 py-3 text-sm font-medium -mb-px border-b-2 transition", tab === k ? "border-stone-900 text-stone-900" : "border-transparent text-stone-500 hover:text-stone-800")}>{l}</button>
          ))}
        </div>
        <div className="py-8">
          {tab === "specs" && (
            <div className="grid md:grid-cols-2 gap-x-10">
              {(product.specs || []).map((s) => { const [k, ...v] = s.split(":"); return <div key={s} className="flex justify-between gap-4 py-3 border-b border-stone-100 text-sm"><span className="text-stone-500">{v.length ? k : "Feature"}</span><span className="font-medium text-stone-900 text-right">{v.length ? v.join(":").trim() : k}</span></div>; })}
              <div className="flex justify-between gap-4 py-3 border-b border-stone-100 text-sm"><span className="text-stone-500">Warranty</span><span className="font-medium">{product.warranty}</span></div>
              <div className="flex justify-between gap-4 py-3 border-b border-stone-100 text-sm"><span className="text-stone-500">Return policy</span><span className="font-medium">{product.returnDays > 0 ? `${product.returnDays} days` : "Non-returnable"}</span></div>
              <div className="flex justify-between gap-4 py-3 border-b border-stone-100 text-sm"><span className="text-stone-500">Delivery estimate</span><span className="font-medium">{product.deliveryDays} day{product.deliveryDays > 1 ? "s" : ""}</span></div>
              <div className="flex justify-between gap-4 py-3 border-b border-stone-100 text-sm"><span className="text-stone-500">SKU</span><span className="font-medium">{product.sku}</span></div>
            </div>
          )}
          {tab === "reviews" && (
            <div className="grid lg:grid-cols-[280px_1fr] gap-10">
              <div>
                <p className="text-5xl font-[560] tracking-[-0.03em]">{avg.toFixed(1)}</p>
                <Stars rating={avg} size="h-4 w-4" />
                <p className="text-sm text-stone-500 mt-1">{product.reviewCount.toLocaleString("en-IN")} ratings</p>
                <div className="mt-4 space-y-1.5">{dist.map((d) => <div key={d.s} className="flex items-center gap-2 text-xs"><span className="w-6">{d.s}★</span><div className="flex-1 h-2 rounded-full bg-stone-100 overflow-hidden"><div className="h-full bg-amber-400" style={{ width: `${reviews.length ? (d.n / reviews.length) * 100 : 0}%` }} /></div><span className="w-6 text-stone-500">{d.n}</span></div>)}</div>
                <button onClick={() => toast({ title: "Thanks!", body: "Review submission is a demo — connect a backend to persist.", tone: "info" })} className="mt-5 w-full py-2.5 rounded-full border border-stone-900 text-sm font-medium hover:bg-stone-900 hover:text-white transition">Write a review</button>
              </div>
              <div className="space-y-4">
                {reviews.map((r) => (
                  <div key={r.id} className="rounded-2xl border border-stone-200 p-5">
                    <div className="flex items-center gap-3"><img src={r.avatar || ""} alt="" className="h-9 w-9 rounded-full object-cover" /><div><p className="text-sm font-medium">{r.author} <span className="ml-1 text-[10px] font-semibold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded">Verified buyer</span></p><Stars rating={r.rating} size="h-3 w-3" /></div><span className="ml-auto text-xs text-stone-400">{fmtDate(r.createdAt)}</span></div>
                    <p className="mt-3 text-sm font-[550]">{r.title}</p>
                    <p className="text-sm text-stone-600 mt-1 leading-relaxed">{r.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          {tab === "qa" && (
            <div className="max-w-3xl space-y-4">
              {questions.map((qa) => (
                <div key={qa.id} className="rounded-2xl border border-stone-200 p-5">
                  <p className="text-sm font-medium flex items-start gap-2"><MessageCircleQuestion className="h-4 w-4 text-stone-400 mt-0.5 shrink-0" />{qa.question}</p>
                  <p className="text-xs text-stone-400 mt-1 ml-6">Asked by {qa.author}</p>
                  {qa.answer && <p className="mt-3 ml-6 text-sm text-stone-700 bg-stone-50 rounded-xl p-3"><span className="font-semibold text-stone-900">Solara Coast:</span> {qa.answer}</p>}
                </div>
              ))}
              <form onSubmit={(e) => { e.preventDefault(); toast({ title: "Question submitted", body: "Demo — our team would reply within 24 hours.", tone: "success" }); }} className="flex gap-2"><input required placeholder="Have a question? Ask here…" className="flex-1 h-11 px-4 rounded-full bg-stone-50 border border-stone-200 text-sm outline-none focus:border-stone-400" /><button className="h-11 px-5 rounded-full bg-stone-900 text-white text-sm font-semibold">Ask</button></form>
            </div>
          )}
        </div>
      </div>

      {/* Sticky mobile bar */}
      <div className="lg:hidden fixed bottom-16 inset-x-0 z-40 bg-white/95 backdrop-blur border-t border-stone-200 p-3 flex items-center gap-3">
        <div className="flex-1 min-w-0"><p className="text-xs text-stone-500 truncate">{product.name}</p><p className="text-base font-semibold">{formatINR(parseFloat(product.price) * qty)}</p></div>
        <button onClick={() => add()} disabled={product.stock <= 0} className="h-11 px-5 rounded-full bg-stone-900 text-white text-sm font-semibold disabled:opacity-40">Add to cart</button>
      </div>
    </div>
  );
}
