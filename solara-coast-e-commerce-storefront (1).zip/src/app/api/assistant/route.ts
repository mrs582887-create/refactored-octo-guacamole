import { NextResponse } from "next/server";
import { getAllProducts } from "@/lib/queries";
import { searchProducts, parseSearchQuery, formatINR, num } from "@/lib/utils";

export const dynamic = "force-dynamic";

const INTENTS: { match: RegExp; boost: string[]; reply: string }[] = [
  { match: /camera|photo|selfie/i, boost: ["camera", "photography", "vlog"], reply: "For photography, I'd prioritise sensor quality and OIS. Here are the strongest camera picks in your budget:" },
  { match: /program|coding|developer|software|code/i, boost: ["programming", "keyboard", "monitor"], reply: "For programming you want 16GB RAM, a fast SSD and a comfortable keyboard. These fit the bill:" },
  { match: /gaming|game|fps|esports/i, boost: ["gaming"], reply: "Gaming picks with high refresh rates and dedicated GPUs:" },
  { match: /student|college|school|study/i, boost: ["students", "study"], reply: "Student-friendly essentials — great value and built to last a semester or four:" },
  { match: /gift|present|birthday|anniversary/i, boost: ["gift"], reply: "Here are gift ideas that consistently get 5-star reviews:" },
  { match: /work from home|wfh|office|desk/i, boost: ["work from home", "office"], reply: "Upgrade your home office with these:" },
  { match: /travel|trip|flight|vacation/i, boost: ["travel"], reply: "Travel-ready picks:" },
  { match: /fitness|gym|workout|yoga|running/i, boost: ["fitness", "running", "yoga"], reply: "Let's get moving — here's fitness gear our customers love:" },
  { match: /skin|glow|acne|face/i, boost: ["skincare"], reply: "Dermatologist-tested skincare picks:" },
  { match: /pet|dog|cat|puppy|kitten/i, boost: ["dog", "cat"], reply: "For your furry friend:" },
];

export async function POST(req: Request) {
  const { message } = await req.json();
  const q = String(message || "").trim();
  if (!q) return NextResponse.json({ reply: "Tell me what you're looking for — e.g. “a phone under ₹30,000 with a good camera”.", products: [], mode: "demo" });

  const all = await getAllProducts();
  const parsed = parseSearchQuery(q);
  const intent = INTENTS.find((i) => i.match.test(q));
  const query = intent ? `${parsed.text} ${intent.boost.join(" ")}` : q;
  let results = searchProducts(all, query);
  if (parsed.maxPrice) results = results.filter((p) => num(p.price) <= parsed.maxPrice!);
  if (parsed.minPrice) results = results.filter((p) => num(p.price) >= parsed.minPrice!);
  // searchProducts already returns relevance-ordered results; keep that order and only drop out-of-stock items.
  results = results.filter((p) => p.stock > 0).slice(0, 4);

  if (results.length === 0) {
    results = all.filter((p) => p.bestSeller && p.stock > 0).slice(0, 4);
  }

  // Optional real AI provider (server-side key only). Falls back to demo engine automatically.
  let reply = intent?.reply || (parsed.maxPrice ? `Here's what I found under ${formatINR(parsed.maxPrice)}:` : "Here's what I'd recommend:");
  let mode: "demo" | "ai" = "demo";
  if (process.env.OPENAI_API_KEY) {
    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || "gpt-4o-mini",
          max_tokens: 160,
          messages: [
            { role: "system", content: "You are Solara Coast's friendly shopping assistant. Reply in 2 short sentences, recommending from the provided products only. Prices are in INR." },
            { role: "user", content: `Customer: ${q}\nProducts: ${results.map((p) => `${p.name} (${formatINR(p.price)}, rating ${p.rating}, ${p.tagline})`).join("; ")}` },
          ],
        }),
        signal: AbortSignal.timeout(10000),
      });
      if (res.ok) {
        const data = await res.json();
        const text = data?.choices?.[0]?.message?.content;
        if (text) { reply = text; mode = "ai"; }
      }
    } catch {}
  }

  return NextResponse.json({
    reply,
    mode,
    products: results.map((p) => ({ id: p.id, slug: p.slug, name: p.name, price: p.price, originalPrice: p.originalPrice, image: p.imageMain, brand: p.brand, rating: p.rating, stock: p.stock, tagline: p.tagline })),
  });
}
