import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getOrderByOrderId } from "@/lib/queries";
import { ORDER_STATUSES } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;
  const order = await getOrderByOrderId(orderId.toUpperCase());
  if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
  return NextResponse.json({ order });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;
  const { status, note } = await req.json();
  if (!ORDER_STATUSES.includes(status)) return NextResponse.json({ error: "Invalid status" }, { status: 400 });
  const order = await getOrderByOrderId(orderId);
  if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
  const history = [...(order.statusHistory || []), { status, at: new Date().toISOString(), note: note || undefined }];
  const [updated] = await db.update(orders).set({ status, statusHistory: history }).where(eq(orders.orderId, orderId)).returning();
  return NextResponse.json({ order: updated });
}
