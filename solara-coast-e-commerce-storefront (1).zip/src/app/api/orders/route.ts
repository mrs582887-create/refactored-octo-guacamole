import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, orders, notificationLogs, customers, type OrderItem, type OrderAddress } from "@/db/schema";
import { eq, inArray, sql } from "drizzle-orm";
import { computeTotals, generateOrderId, deliveryDate, formatINR, PAYMENT_METHODS, DELIVERY_METHODS } from "@/lib/utils";
import { getCouponByCode, getOrdersByEmail } from "@/lib/queries";

export const dynamic = "force-dynamic";

type Body = {
  customer: { name: string; email: string; phone: string };
  address: OrderAddress;
  items: { productId: number; qty: number; color?: string; size?: string }[];
  couponCode?: string | null;
  paymentMethod: string;
  deliveryMethod: string;
};

export async function GET(req: Request) {
  const email = new URL(req.url).searchParams.get("email");
  if (!email) return NextResponse.json({ error: "email required" }, { status: 400 });
  const list = await getOrdersByEmail(email);
  return NextResponse.json({ orders: list });
}

export async function POST(req: Request) {
  let body: Body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { customer, address, items, couponCode, paymentMethod, deliveryMethod } = body;
  if (!customer?.name || !customer?.email || !address?.line1 || !address?.pincode || !address?.city) {
    return NextResponse.json({ error: "Missing customer or address details" }, { status: 400 });
  }
  if (!Array.isArray(items) || items.length === 0) return NextResponse.json({ error: "Cart is empty" }, { status: 400 });
  if (!PAYMENT_METHODS.some((p) => p.id === paymentMethod)) return NextResponse.json({ error: "Invalid payment method" }, { status: 400 });
  if (!DELIVERY_METHODS.some((d) => d.id === deliveryMethod)) return NextResponse.json({ error: "Invalid delivery method" }, { status: 400 });

  // --- Server-side recalculation: never trust client prices ---
  const ids = Array.from(new Set(items.map((i) => Number(i.productId)).filter(Boolean)));
  const rows = await db.select().from(products).where(inArray(products.id, ids));
  const byId = new Map(rows.map((r) => [r.id, r]));
  const orderItems: OrderItem[] = [];
  for (const it of items) {
    const p = byId.get(Number(it.productId));
    const qty = Math.max(1, Math.min(10, Math.floor(Number(it.qty) || 1)));
    if (!p) return NextResponse.json({ error: `Product ${it.productId} not found` }, { status: 400 });
    if (p.stock < qty) return NextResponse.json({ error: `${p.name} has only ${p.stock} left in stock` }, { status: 409 });
    orderItems.push({ productId: p.id, name: p.name, slug: p.slug, image: p.imageMain, price: parseFloat(p.price), qty, color: it.color, size: it.size });
  }
  const subtotal = orderItems.reduce((s, i) => s + i.price * i.qty, 0);
  const coupon = couponCode ? await getCouponByCode(couponCode) : null;
  const totals = computeTotals({ subtotal, coupon: coupon && coupon.active ? coupon : null, deliveryMethod });
  if (paymentMethod === "cod" && totals.total > 50000) return NextResponse.json({ error: "Cash on Delivery is available for orders up to ₹50,000" }, { status: 400 });

  const maxDelivery = Math.max(...orderItems.map((i) => byId.get(i.productId)?.deliveryDays ?? 3));
  const expected = deliveryDate(deliveryMethod === "express" ? 1 : maxDelivery);
  const now = new Date();
  const orderId = generateOrderId(now);
  const paymentConfirmed = paymentMethod !== "cod";
  const history = [{ status: "Order Placed", at: now.toISOString(), note: "We have received your order." }];
  if (paymentConfirmed) history.push({ status: "Payment Confirmed", at: new Date(now.getTime() + 1000).toISOString(), note: "Demo payment recorded (no real charge)." });

  const [created] = await db.transaction(async (tx) => {
    for (const it of orderItems) {
      await tx.update(products).set({ stock: sql`${products.stock} - ${it.qty}`, soldCount: sql`${products.soldCount} + ${it.qty}` }).where(eq(products.id, it.productId));
    }
    const email = customer.email.toLowerCase().trim();
    await tx
      .insert(customers)
      .values({ name: customer.name, email, phone: customer.phone || "", totalOrders: 1, totalSpent: totals.total.toFixed(2) })
      .onConflictDoUpdate({ target: customers.email, set: { name: customer.name, phone: customer.phone || "", totalOrders: sql`${customers.totalOrders} + 1`, totalSpent: sql`${customers.totalSpent} + ${totals.total}` } });
    return tx
      .insert(orders)
      .values({
        orderId,
        customerName: customer.name,
        customerEmail: email,
        customerPhone: customer.phone || "",
        items: orderItems,
        subtotal: subtotal.toFixed(2),
        discount: totals.discount.toFixed(2),
        shipping: totals.shipping.toFixed(2),
        tax: totals.tax.toFixed(2),
        total: totals.total.toFixed(2),
        couponCode: coupon?.code || null,
        paymentMethod,
        paymentMode: "demo",
        deliveryMethod,
        address,
        status: paymentConfirmed ? "Payment Confirmed" : "Order Placed",
        statusHistory: history,
        expectedDelivery: expected,
      })
      .returning();
  });

  // --- Notifications (owner webhook + customer email), secure & demo-aware ---
  const origin = new URL(req.url).origin;
  const viewUrl = `${process.env.NEXT_PUBLIC_SITE_URL || origin}/orders/${orderId}`;
  const productLines = orderItems.map((i) => `${i.name}${i.color ? ` (${i.color}${i.size ? `, ${i.size}` : ""})` : ""} × ${i.qty} — ${formatINR(i.price * i.qty)}`);
  const addressLine = `${address.fullName}, ${address.line1}${address.line2 ? ", " + address.line2 : ""}, ${address.city}, ${address.state} ${address.pincode}, ${address.country}`;
  const subject = `New Solara Coast Order — Order #${orderId}`;
  const emailBody = [
    "New Order Received", "",
    `Order ID: ${orderId}`,
    `Customer Name: ${customer.name}`,
    `Customer Email: ${customer.email}`,
    `Phone: ${customer.phone || "-"}`,
    `Products:\n  ${productLines.join("\n  ")}`,
    `Quantity: ${orderItems.reduce((s, i) => s + i.qty, 0)} item(s)`,
    `Subtotal: ${formatINR(subtotal)}`,
    `Discount: ${formatINR(totals.discount)}${coupon ? ` (${coupon.code})` : ""}`,
    `Shipping: ${formatINR(totals.shipping)}`,
    `Tax: ${formatINR(totals.tax)}`,
    `Total: ${formatINR(totals.total)}`,
    `Payment Method: ${PAYMENT_METHODS.find((p) => p.id === paymentMethod)?.label} (DEMO — no real charge)`,
    `Delivery Address: ${addressLine}`,
    `Order Date: ${now.toLocaleString("en-IN")}`,
    `Expected Delivery: ${expected.toDateString()}`, "",
    `Order Status: ${created.status.toUpperCase()}`, "",
    `View Order: ${viewUrl}`,
  ].join("\n");

  const payload = {
    event: "order.created",
    subject,
    text: emailBody,
    viewUrl,
    order: { ...created, items: orderItems },
  };

  const notifications: { owner: string; customer: string } = { owner: "simulated", customer: "simulated" };

  const webhook = process.env.STORE_ORDER_WEBHOOK_URL;
  if (webhook) {
    try {
      const res = await fetch(webhook, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), signal: AbortSignal.timeout(8000) });
      notifications.owner = res.ok ? "sent" : "failed";
      await db.insert(notificationLogs).values({ orderId, channel: "owner_webhook", recipient: "STORE_ORDER_WEBHOOK_URL", status: notifications.owner, subject, detail: res.ok ? `Webhook responded ${res.status}` : `Webhook responded ${res.status}`, payload });
    } catch (e) {
      notifications.owner = "failed";
      await db.insert(notificationLogs).values({ orderId, channel: "owner_webhook", recipient: "STORE_ORDER_WEBHOOK_URL", status: "failed", subject, detail: String(e), payload });
    }
  } else {
    await db.insert(notificationLogs).values({ orderId, channel: "owner_webhook", recipient: "store owner (not configured)", status: "simulated", subject, detail: "DEMO MODE: STORE_ORDER_WEBHOOK_URL is not set. Notification was simulated, not sent.", payload });
  }

  const customerSubject = `Your Solara Coast order ${orderId} is confirmed`;
  const customerText = `Thank you for shopping with Solara Coast, ${customer.name}!\n\nOrder ID: ${orderId}\n\nItems:\n  ${productLines.join("\n  ")}\n\nTotal: ${formatINR(totals.total)}\nDelivery Address: ${addressLine}\nExpected Delivery: ${expected.toDateString()}\n\nTrack your order: ${viewUrl}`;
  const emailWebhook = process.env.CUSTOMER_EMAIL_WEBHOOK_URL;
  const resendKey = process.env.RESEND_API_KEY;
  if (emailWebhook) {
    try {
      const res = await fetch(emailWebhook, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ event: "order.confirmation", to: customer.email, subject: customerSubject, text: customerText, viewUrl, order: payload.order }), signal: AbortSignal.timeout(8000) });
      notifications.customer = res.ok ? "sent" : "failed";
      await db.insert(notificationLogs).values({ orderId, channel: "customer_email", recipient: customer.email, status: notifications.customer, subject: customerSubject, detail: `Email webhook responded ${res.status}` });
    } catch (e) {
      notifications.customer = "failed";
      await db.insert(notificationLogs).values({ orderId, channel: "customer_email", recipient: customer.email, status: "failed", subject: customerSubject, detail: String(e) });
    }
  } else if (resendKey) {
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from: process.env.EMAIL_FROM || "Solara Coast <onboarding@resend.dev>", to: [customer.email], subject: customerSubject, text: customerText }),
        signal: AbortSignal.timeout(8000),
      });
      notifications.customer = res.ok ? "sent" : "failed";
      await db.insert(notificationLogs).values({ orderId, channel: "customer_email", recipient: customer.email, status: notifications.customer, subject: customerSubject, detail: `Resend responded ${res.status}` });
    } catch (e) {
      notifications.customer = "failed";
      await db.insert(notificationLogs).values({ orderId, channel: "customer_email", recipient: customer.email, status: "failed", subject: customerSubject, detail: String(e) });
    }
  } else {
    await db.insert(notificationLogs).values({ orderId, channel: "customer_email", recipient: customer.email, status: "simulated", subject: customerSubject, detail: "DEMO MODE: No email provider configured (CUSTOMER_EMAIL_WEBHOOK_URL / RESEND_API_KEY). Email prepared but not sent." });
  }

  return NextResponse.json({ order: created, notifications, demo: !webhook });
}
