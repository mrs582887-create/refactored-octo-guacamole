import { NextResponse } from "next/server";
import { getCouponByCode } from "@/lib/queries";
import { validateCoupon } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { code, subtotal } = await req.json();
  if (!code) return NextResponse.json({ ok: false, message: "Enter a coupon code." }, { status: 400 });
  const coupon = await getCouponByCode(String(code));
  const result = validateCoupon(coupon, Number(subtotal) || 0);
  return NextResponse.json({ ...result, coupon: result.ok ? coupon : null, demo: coupon?.isDemo ?? true });
}
