import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, coupons, categories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { slugify } from "@/db/catalog";

export const dynamic = "force-dynamic";

// Demo admin API (no auth) — wire real auth before production use.
export async function POST(req: Request) {
  const { action, data } = await req.json();
  try {
    switch (action) {
      case "product.create": {
        const cat = data.categoryId ? (await db.select().from(categories).where(eq(categories.id, Number(data.categoryId))))[0] : null;
        const [row] = await db.insert(products).values({
          name: data.name, slug: slugify(data.name) + "-" + Date.now().toString(36), brand: data.brand || "Solara Coast", sku: data.sku || `SC-NEW-${Date.now().toString().slice(-5)}`,
          tagline: data.tagline || "", description: data.description || "", price: String(Number(data.price) || 0), originalPrice: data.originalPrice ? String(Number(data.originalPrice)) : null,
          categoryId: cat?.id ?? null, categorySlug: cat?.slug ?? "", categoryName: cat?.name ?? "", department: cat?.department ?? "Electronics", departmentSlug: cat?.departmentSlug ?? "electronics",
          imageMain: data.imageMain || "https://images.pexels.com/photos/7989740/pexels-photo-7989740.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=720&fit=crop", images: [data.imageMain].filter(Boolean),
          specs: (data.specs || "").split("\n").filter(Boolean), colors: (data.colors || "").split(",").map((s: string) => s.trim()).filter(Boolean), sizes: [], tags: [],
          stock: Number(data.stock) || 0, rating: "4.5", reviewCount: 0, newArrival: true, warranty: data.warranty || "No warranty",
        }).returning();
        return NextResponse.json({ ok: true, product: row });
      }
      case "product.update": {
        const patch: Partial<typeof products.$inferInsert> = {};
        if (data.name !== undefined) patch.name = data.name;
        if (data.brand !== undefined) patch.brand = data.brand;
        if (data.price !== undefined) patch.price = String(Number(data.price));
        if (data.originalPrice !== undefined) patch.originalPrice = data.originalPrice ? String(Number(data.originalPrice)) : null;
        if (data.stock !== undefined) patch.stock = Number(data.stock);
        if (data.tagline !== undefined) patch.tagline = data.tagline;
        if (data.featured !== undefined) patch.featured = !!data.featured;
        if (data.flashDeal !== undefined) patch.flashDeal = !!data.flashDeal;
        const [row] = await db.update(products).set(patch).where(eq(products.id, Number(data.id))).returning();
        return NextResponse.json({ ok: true, product: row });
      }
      case "product.delete": {
        await db.delete(products).where(eq(products.id, Number(data.id)));
        return NextResponse.json({ ok: true });
      }
      case "coupon.create": {
        const [row] = await db.insert(coupons).values({ code: String(data.code).toUpperCase().trim(), type: data.type, value: String(Number(data.value) || 0), minOrder: String(Number(data.minOrder) || 0), maxDiscount: data.maxDiscount ? String(Number(data.maxDiscount)) : null, description: data.description || "", active: true, isDemo: true }).returning();
        return NextResponse.json({ ok: true, coupon: row });
      }
      case "coupon.toggle": {
        const [row] = await db.update(coupons).set({ active: !!data.active }).where(eq(coupons.id, Number(data.id))).returning();
        return NextResponse.json({ ok: true, coupon: row });
      }
      case "coupon.delete": {
        await db.delete(coupons).where(eq(coupons.id, Number(data.id)));
        return NextResponse.json({ ok: true });
      }
      case "category.create": {
        const [row] = await db.insert(categories).values({ name: data.name, slug: slugify(data.name), department: data.department || "Daily Essentials", departmentSlug: slugify(data.department || "essentials") }).returning();
        return NextResponse.json({ ok: true, category: row });
      }
      default:
        return NextResponse.json({ error: "Unknown action" }, { status: 400 });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
