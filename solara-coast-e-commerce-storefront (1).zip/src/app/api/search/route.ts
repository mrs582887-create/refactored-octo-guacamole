import { NextResponse } from "next/server";
import { getAllProducts, getAllCategories } from "@/lib/queries";
import { searchProducts, parseSearchQuery } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const q = (new URL(req.url).searchParams.get("q") || "").trim();
  const [all, cats] = await Promise.all([getAllProducts(), getAllCategories()]);
  const parsed = parseSearchQuery(q);
  const matches = q ? searchProducts(all, q) : [];
  const lower = q.toLowerCase();
  const brands = Array.from(new Set(all.map((p) => p.brand))).filter((b) => b.toLowerCase().includes(lower)).slice(0, 4);
  const categories = cats.filter((c) => c.name.toLowerCase().includes(lower) || parsed.keywords.some((k) => c.name.toLowerCase().includes(k))).slice(0, 5);
  return NextResponse.json({
    products: matches.slice(0, 6).map((p) => ({ id: p.id, name: p.name, slug: p.slug, image: p.imageMain, price: p.price, brand: p.brand, categoryName: p.categoryName })),
    total: matches.length,
    brands,
    categories: categories.map((c) => ({ name: c.name, slug: c.slug })),
    parsed,
  });
}
