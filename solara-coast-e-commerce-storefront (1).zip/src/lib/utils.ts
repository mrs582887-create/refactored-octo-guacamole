import type { Product } from "@/db/schema";

export const BRAND = { name: "Solara Coast", tagline: "Everything You Need. One Coast." };

export const FREE_SHIPPING_THRESHOLD = 999;
export const STANDARD_SHIPPING = 49;
export const EXPRESS_SHIPPING = 149;
export const TAX_RATE = 0.05; // demo GST line item (5%)

export function formatINR(value: number | string) {
  const n = typeof value === "string" ? parseFloat(value) : value;
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

export function num(v: string | number | null | undefined) {
  if (v === null || v === undefined) return 0;
  return typeof v === "string" ? parseFloat(v) : v;
}

export function discountPct(p: { price: string | number; originalPrice?: string | number | null }) {
  const o = num(p.originalPrice);
  const pr = num(p.price);
  if (!o || o <= pr) return 0;
  return Math.round(((o - pr) / o) * 100);
}

export function stockStatus(stock: number) {
  if (stock <= 0) return { label: "Out of Stock", tone: "rose" as const, key: "out" as const };
  if (stock <= 5) return { label: `Only ${stock} left`, tone: "amber" as const, key: "low" as const };
  return { label: "In Stock", tone: "teal" as const, key: "in" as const };
}

export function deliveryDate(days: number, from = new Date()) {
  const d = new Date(from);
  d.setDate(d.getDate() + days);
  return d;
}

export function fmtDate(d: Date | string | null | undefined, opts: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" }) {
  if (!d) return "";
  return new Date(d).toLocaleDateString("en-IN", opts);
}

export const ORDER_STATUSES = ["Order Placed", "Payment Confirmed", "Processing", "Packed", "Shipped", "Out for Delivery", "Delivered"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const PAYMENT_METHODS = [
  { id: "upi", label: "UPI", hint: "GPay, PhonePe, Paytm" },
  { id: "credit_card", label: "Credit Card", hint: "Visa, Mastercard, RuPay" },
  { id: "debit_card", label: "Debit Card", hint: "All major banks" },
  { id: "net_banking", label: "Net Banking", hint: "50+ banks supported" },
  { id: "cod", label: "Cash on Delivery", hint: "Pay when it arrives" },
] as const;

export const DELIVERY_METHODS = [
  { id: "standard", label: "Standard Delivery", days: 3, price: STANDARD_SHIPPING, hint: "Free above ₹999" },
  { id: "express", label: "Express Delivery", days: 1, price: EXPRESS_SHIPPING, hint: "Next-day in metro cities" },
] as const;

export type CouponLike = { code: string; type: string; value: string | number; minOrder: string | number; maxDiscount?: string | number | null; active?: boolean };

export function computeTotals(opts: { subtotal: number; coupon?: CouponLike | null; deliveryMethod?: string }) {
  const { subtotal, coupon, deliveryMethod = "standard" } = opts;
  let discount = 0;
  let freeShip = false;
  if (coupon && coupon.active !== false && subtotal >= num(coupon.minOrder)) {
    if (coupon.type === "percent") {
      discount = (subtotal * num(coupon.value)) / 100;
      if (coupon.maxDiscount) discount = Math.min(discount, num(coupon.maxDiscount));
    } else if (coupon.type === "flat") {
      discount = Math.min(num(coupon.value), subtotal);
    } else if (coupon.type === "freeship") {
      freeShip = true;
    }
  }
  const method = DELIVERY_METHODS.find((m) => m.id === deliveryMethod) || DELIVERY_METHODS[0];
  let shipping: number = method.price;
  if (method.id === "standard" && (subtotal >= FREE_SHIPPING_THRESHOLD || freeShip)) shipping = 0;
  if (method.id === "express" && freeShip) shipping = Math.max(0, shipping - STANDARD_SHIPPING);
  if (subtotal === 0) shipping = 0;
  const taxable = Math.max(0, subtotal - discount);
  const tax = Math.round(taxable * TAX_RATE);
  const total = Math.max(0, Math.round(taxable + shipping + tax));
  return { subtotal, discount: Math.round(discount), shipping, tax, total, freeShip, deliveryDays: method.days };
}

export function validateCoupon(coupon: CouponLike | null | undefined, subtotal: number): { ok: boolean; message: string } {
  if (!coupon) return { ok: false, message: "Coupon not found. Try WELCOME10, SAVE500, STUDENT15 or FREESHIP (demo)." };
  if (coupon.active === false) return { ok: false, message: "This coupon is no longer active." };
  if (subtotal < num(coupon.minOrder)) return { ok: false, message: `Add ${formatINR(num(coupon.minOrder) - subtotal)} more to use ${coupon.code}.` };
  return { ok: true, message: `${coupon.code} applied.` };
}

// ---------- Smart search ----------
export type ParsedQuery = { text: string; keywords: string[]; minPrice?: number; maxPrice?: number };

function parseAmount(raw: string) {
  let s = raw.toLowerCase().replace(/[₹,rs.\s]/g, "");
  let mult = 1;
  if (s.endsWith("k")) { mult = 1000; s = s.slice(0, -1); }
  if (s.endsWith("l") || s.endsWith("lakh")) { mult = 100000; s = s.replace(/l(akh)?$/, ""); }
  const n = parseFloat(s);
  return isNaN(n) ? undefined : n * mult;
}

export function parseSearchQuery(q: string): ParsedQuery {
  let text = q.trim();
  const out: ParsedQuery = { text, keywords: [] };
  const amount = "(?:₹|rs\\.?\\s*)?([0-9][0-9,]*(?:\\.[0-9]+)?\\s*(?:k|l|lakh)?)";
  const between = new RegExp(`(?:between|from)\\s*${amount}\\s*(?:and|to|-)\\s*${amount}`, "i");
  const under = new RegExp(`(?:under|below|less than|upto|up to|within|max|<)\\s*${amount}`, "i");
  const above = new RegExp(`(?:above|over|more than|min|>|starting)\\s*${amount}`, "i");
  let m = text.match(between);
  if (m) { out.minPrice = parseAmount(m[1]); out.maxPrice = parseAmount(m[2]); text = text.replace(m[0], " "); }
  m = text.match(under);
  if (m) { out.maxPrice = parseAmount(m[1]); text = text.replace(m[0], " "); }
  m = text.match(above);
  if (m) { out.minPrice = parseAmount(m[1]); text = text.replace(m[0], " "); }
  const stop = new Set(["a", "an", "the", "for", "with", "and", "good", "best", "i", "need", "want", "me", "show", "find", "buy", "in", "of", "to", "some", "cheap", "budget", "please", "looking", "is", "are", "my", "on"]);
  out.keywords = text.toLowerCase().replace(/[^a-z0-9\s+'"-]/g, " ").split(/\s+/).filter((w) => w && !stop.has(w));
  out.text = text.trim();
  return out;
}

const SYNONYMS: Record<string, string[]> = {
  phone: ["smartphone", "mobile"], mobile: ["smartphone", "phone"], phones: ["smartphone"], smartphone: ["phone", "mobile"],
  laptop: ["laptops"], laptops: ["laptop"], earphones: ["earbuds"], airpods: ["earbuds"], buds: ["earbuds"],
  headphone: ["headphones"], watch: ["watches", "smart watches"], shoes: ["sneakers", "sandals", "sports shoes"], footwear: ["shoes", "sneakers", "sandals"],
  programming: ["laptop", "keyboard", "monitor", "mouse", "chair", "clean code"], coding: ["programming"], gaming: ["console", "mouse", "monitor", "laptop"],
  camera: ["cameras", "smartphones"], sofa: ["sofas"], chair: ["chairs"], table: ["tables"], bed: ["beds"], perfume: ["perfumes"], fragrance: ["perfumes"],
  bag: ["bags", "backpacks"], backpack: ["backpacks"], suitcase: ["suitcases", "luggage"], luggage: ["suitcases"], dog: ["pet"], cat: ["pet"], pet: ["pets"],
  kids: ["kids clothing"], study: ["students"], student: ["students"], wfh: ["work from home"], office: ["work from home"], fitness: ["gym", "yoga", "running"],
  coffee: ["coffee", "espresso"], tea: ["tea"], skincare: ["serum", "moisturizer", "sunscreen"], makeup: ["lipstick", "foundation"],
};

export function expandKeywords(words: string[]) {
  const set = new Set<string>();
  for (const w of words) {
    set.add(w);
    (SYNONYMS[w] || []).forEach((s) => set.add(s));
  }
  return Array.from(set);
}

export function productSearchScore(p: Product, keywords: string[]) {
  if (keywords.length === 0) return 1;
  const hay = {
    name: p.name.toLowerCase(),
    brand: p.brand.toLowerCase(),
    cat: `${p.categoryName} ${p.department}`.toLowerCase(),
    tags: (p.tags || []).join(" ").toLowerCase(),
    text: `${p.tagline || ""} ${(p.specs || []).join(" ")} ${p.description || ""}`.toLowerCase(),
  };
  let score = 0;
  let matchedAny = false;
  for (const k of keywords) {
    let s = 0;
    if (hay.name.includes(k)) s += 10;
    if (hay.brand.includes(k)) s += 8;
    if (hay.cat.includes(k)) s += 7;
    if (hay.tags.includes(k)) s += 6;
    if (hay.text.includes(k)) s += 2;
    if (s > 0) matchedAny = true;
    score += s;
  }
  return matchedAny ? score : 0;
}

export function searchProducts(list: Product[], query: string) {
  const parsed = parseSearchQuery(query);
  const keys = expandKeywords(parsed.keywords);
  return list
    .map((p) => ({ p, score: productSearchScore(p, keys) }))
    .filter(({ p, score }) => {
      if (parsed.keywords.length > 0 && score === 0) return false;
      const price = num(p.price);
      if (parsed.maxPrice !== undefined && price > parsed.maxPrice) return false;
      if (parsed.minPrice !== undefined && price < parsed.minPrice) return false;
      return true;
    })
    .sort((a, b) => b.score - a.score)
    .map(({ p }) => p);
}

export const POPULAR_SEARCHES = ["laptop under ₹50000", "phone under ₹30000 good camera", "wireless earbuds", "running shoes", "office chair", "air fryer", "perfume gift", "suitcase"];

export function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

export function generateOrderId(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  const rand = Math.floor(10000 + Math.random() * 90000);
  return `SOLARA-${y}${m}${d}-${rand}`;
}
