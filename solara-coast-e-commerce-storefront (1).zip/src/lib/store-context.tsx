"use client";

import { createContext, useContext, useState, useEffect, useCallback, useMemo, type ReactNode } from "react";

export type CartItem = {
  productId: number;
  slug: string;
  name: string;
  price: string;
  image: string;
  qty: number;
  color: string;
  size: string;
  stock: number;
};

export type MiniProduct = {
  id: number;
  slug: string;
  name: string;
  price: string;
  originalPrice: string | null;
  image: string;
  brand: string;
  rating: string;
  stock: number;
  specs?: string[] | null;
  categoryName?: string;
  warranty?: string | null;
  deliveryDays?: number;
};

export type Notification = { id: string; title: string; body: string; at: string; read: boolean; href?: string; kind: "order" | "deal" | "wishlist" | "system" };
export type Toast = { id: string; title: string; body?: string; tone?: "success" | "error" | "info" };
export type Address = { id: string; label: string; fullName: string; phone: string; line1: string; line2?: string; city: string; state: string; pincode: string; country: string; isDefault?: boolean };
export type Profile = { name: string; email: string; phone: string; addresses: Address[]; orderIds: string[] };

type Store = {
  hydrated: boolean;
  cart: CartItem[];
  saved: CartItem[];
  couponCode: string | null;
  wishlist: MiniProduct[];
  compare: MiniProduct[];
  recent: MiniProduct[];
  notifications: Notification[];
  toasts: Toast[];
  profile: Profile;
  cartOpen: boolean;
  assistantOpen: boolean;
  searchOpen: boolean;
  recentSearches: string[];
  addToCart: (item: Omit<CartItem, "qty"> & { qty?: number }, opts?: { silent?: boolean }) => void;
  removeFromCart: (productId: number, color: string, size: string) => void;
  updateQty: (productId: number, color: string, size: string, qty: number) => void;
  saveForLater: (productId: number, color: string, size: string) => void;
  moveToCart: (productId: number, color: string, size: string) => void;
  removeSaved: (productId: number, color: string, size: string) => void;
  clearCart: () => void;
  setCouponCode: (c: string | null) => void;
  toggleWishlist: (p: MiniProduct) => void;
  inWishlist: (id: number) => boolean;
  toggleCompare: (p: MiniProduct) => boolean;
  inCompare: (id: number) => boolean;
  clearCompare: () => void;
  addRecent: (p: MiniProduct) => void;
  notify: (n: Omit<Notification, "id" | "at" | "read">) => void;
  markAllRead: () => void;
  clearNotifications: () => void;
  toast: (t: Omit<Toast, "id">) => void;
  dismissToast: (id: string) => void;
  setProfile: (p: Partial<Profile>) => void;
  addAddress: (a: Omit<Address, "id">) => void;
  removeAddress: (id: string) => void;
  rememberOrder: (orderId: string) => void;
  setCartOpen: (v: boolean) => void;
  setAssistantOpen: (v: boolean) => void;
  setSearchOpen: (v: boolean) => void;
  addRecentSearch: (q: string) => void;
  cartCount: number;
  cartSubtotal: number;
};

const StoreContext = createContext<Store | undefined>(undefined);
const KEY = "solara-store-v2";
const uid = () => Math.random().toString(36).slice(2, 10);
const same = (a: { productId: number; color: string; size: string }, b: { productId: number; color: string; size: string }) => a.productId === b.productId && a.color === b.color && a.size === b.size;

const emptyProfile: Profile = { name: "", email: "", phone: "", addresses: [], orderIds: [] };

export function StoreProvider({ children }: { children: ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [saved, setSaved] = useState<CartItem[]>([]);
  const [couponCode, setCouponCode] = useState<string | null>(null);
  const [wishlist, setWishlist] = useState<MiniProduct[]>([]);
  const [compare, setCompare] = useState<MiniProduct[]>([]);
  const [recent, setRecent] = useState<MiniProduct[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [profile, setProfileState] = useState<Profile>(emptyProfile);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const s = JSON.parse(raw);
        setCart(s.cart || []);
        setSaved(s.saved || []);
        setCouponCode(s.couponCode || null);
        setWishlist(s.wishlist || []);
        setCompare(s.compare || []);
        setRecent(s.recent || []);
        setNotifications(s.notifications || []);
        setProfileState({ ...emptyProfile, ...(s.profile || {}) });
        setRecentSearches(s.recentSearches || []);
      } else {
        // legacy cart migration
        const legacy = localStorage.getItem("solara-cart");
        if (legacy) {
          try {
            const items = JSON.parse(legacy) as { productId: number; name: string; price: string; image: string; qty: number; color: string }[];
            setCart(items.map((i) => ({ ...i, slug: "", size: "", stock: 99 })));
          } catch {}
        }
        setNotifications([{ id: uid(), title: "Welcome to Solara Coast", body: "Use code WELCOME10 for 10% off your first order (demo coupon).", at: new Date().toISOString(), read: false, kind: "deal", href: "/products" }]);
      }
    } catch {}
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(KEY, JSON.stringify({ cart, saved, couponCode, wishlist, compare, recent, notifications: notifications.slice(0, 50), profile, recentSearches }));
  }, [hydrated, cart, saved, couponCode, wishlist, compare, recent, notifications, profile, recentSearches]);

  const toast = useCallback((t: Omit<Toast, "id">) => {
    const id = uid();
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 3500);
  }, []);
  const dismissToast = useCallback((id: string) => setToasts((prev) => prev.filter((x) => x.id !== id)), []);

  const addToCart: Store["addToCart"] = useCallback((item, opts) => {
    const qty = item.qty ?? 1;
    setCart((prev) => {
      const ex = prev.find((i) => same(i, item));
      if (ex) return prev.map((i) => (same(i, item) ? { ...i, qty: Math.min(i.qty + qty, Math.max(1, item.stock)) } : i));
      return [...prev, { ...item, qty }];
    });
    if (!opts?.silent) {
      setCartOpen(true);
    }
  }, []);

  const removeFromCart = useCallback((productId: number, color: string, size: string) => setCart((prev) => prev.filter((i) => !same(i, { productId, color, size }))), []);
  const updateQty = useCallback((productId: number, color: string, size: string, qty: number) => {
    setCart((prev) => (qty <= 0 ? prev.filter((i) => !same(i, { productId, color, size })) : prev.map((i) => (same(i, { productId, color, size }) ? { ...i, qty: Math.min(qty, Math.max(1, i.stock)) } : i))));
  }, []);
  const saveForLater = useCallback((productId: number, color: string, size: string) => {
    setCart((prev) => {
      const item = prev.find((i) => same(i, { productId, color, size }));
      if (item) setSaved((s) => (s.find((x) => same(x, item)) ? s : [...s, item]));
      return prev.filter((i) => !same(i, { productId, color, size }));
    });
  }, []);
  const moveToCart = useCallback((productId: number, color: string, size: string) => {
    setSaved((prev) => {
      const item = prev.find((i) => same(i, { productId, color, size }));
      if (item) setCart((c) => (c.find((x) => same(x, item)) ? c.map((x) => (same(x, item) ? { ...x, qty: x.qty + item.qty } : x)) : [...c, item]));
      return prev.filter((i) => !same(i, { productId, color, size }));
    });
  }, []);
  const removeSaved = useCallback((productId: number, color: string, size: string) => setSaved((prev) => prev.filter((i) => !same(i, { productId, color, size }))), []);
  const clearCart = useCallback(() => { setCart([]); setCouponCode(null); }, []);

  const toggleWishlist = useCallback((p: MiniProduct) => {
    setWishlist((prev) => {
      const exists = prev.some((x) => x.id === p.id);
      toast(exists ? { title: "Removed from wishlist", tone: "info" } : { title: "Saved to wishlist", body: p.name, tone: "success" });
      return exists ? prev.filter((x) => x.id !== p.id) : [p, ...prev];
    });
  }, [toast]);
  const inWishlist = useCallback((id: number) => wishlist.some((x) => x.id === id), [wishlist]);

  const toggleCompare = useCallback((p: MiniProduct) => {
    let ok = true;
    setCompare((prev) => {
      if (prev.some((x) => x.id === p.id)) return prev.filter((x) => x.id !== p.id);
      if (prev.length >= 4) { ok = false; return prev; }
      return [...prev, p];
    });
    if (!ok) toast({ title: "Compare list is full", body: "You can compare up to 4 products.", tone: "error" });
    return ok;
  }, [toast]);
  const inCompare = useCallback((id: number) => compare.some((x) => x.id === id), [compare]);
  const clearCompare = useCallback(() => setCompare([]), []);

  const addRecent = useCallback((p: MiniProduct) => setRecent((prev) => [p, ...prev.filter((x) => x.id !== p.id)].slice(0, 12)), []);

  const notify: Store["notify"] = useCallback((n) => {
    setNotifications((prev) => [{ ...n, id: uid(), at: new Date().toISOString(), read: false }, ...prev].slice(0, 50));
    toast({ title: n.title, body: n.body, tone: "info" });
  }, [toast]);
  const markAllRead = useCallback(() => setNotifications((prev) => prev.map((n) => ({ ...n, read: true }))), []);
  const clearNotifications = useCallback(() => setNotifications([]), []);

  const setProfile = useCallback((p: Partial<Profile>) => setProfileState((prev) => ({ ...prev, ...p })), []);
  const addAddress = useCallback((a: Omit<Address, "id">) => setProfileState((prev) => ({ ...prev, addresses: [...prev.addresses.map((x) => (a.isDefault ? { ...x, isDefault: false } : x)), { ...a, id: uid() }] })), []);
  const removeAddress = useCallback((id: string) => setProfileState((prev) => ({ ...prev, addresses: prev.addresses.filter((a) => a.id !== id) })), []);
  const rememberOrder = useCallback((orderId: string) => setProfileState((prev) => ({ ...prev, orderIds: [orderId, ...prev.orderIds.filter((x) => x !== orderId)] })), []);
  const addRecentSearch = useCallback((q: string) => { if (q.trim()) setRecentSearches((prev) => [q.trim(), ...prev.filter((x) => x !== q.trim())].slice(0, 8)); }, []);

  const cartCount = useMemo(() => cart.reduce((s, i) => s + i.qty, 0), [cart]);
  const cartSubtotal = useMemo(() => cart.reduce((s, i) => s + parseFloat(i.price) * i.qty, 0), [cart]);

  const value: Store = {
    hydrated, cart, saved, couponCode, wishlist, compare, recent, notifications, toasts, profile, cartOpen, assistantOpen, searchOpen, recentSearches,
    addToCart, removeFromCart, updateQty, saveForLater, moveToCart, removeSaved, clearCart, setCouponCode,
    toggleWishlist, inWishlist, toggleCompare, inCompare, clearCompare, addRecent, notify, markAllRead, clearNotifications, toast, dismissToast,
    setProfile, addAddress, removeAddress, rememberOrder, setCartOpen, setAssistantOpen, setSearchOpen, addRecentSearch, cartCount, cartSubtotal,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}

export function toMini(p: { id: number; slug: string; name: string; price: string; originalPrice: string | null; imageMain: string; brand: string; rating: string; stock: number; specs?: string[] | null; categoryName?: string; warranty?: string | null; deliveryDays?: number }): MiniProduct {
  return { id: p.id, slug: p.slug, name: p.name, price: p.price, originalPrice: p.originalPrice, image: p.imageMain, brand: p.brand, rating: p.rating, stock: p.stock, specs: p.specs, categoryName: p.categoryName, warranty: p.warranty, deliveryDays: p.deliveryDays };
}

// Backwards-compatible hook used by the original components.
export function useCart() {
  const s = useStore();
  return {
    items: s.cart,
    isOpen: s.cartOpen,
    openCart: () => s.setCartOpen(true),
    closeCart: () => s.setCartOpen(false),
    count: () => s.cartCount,
    total: () => s.cartSubtotal,
    clearCart: s.clearCart,
  };
}
