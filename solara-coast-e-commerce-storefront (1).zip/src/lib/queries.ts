import { db } from "@/db";
import { categories, products, reviews, questions, orders, coupons, notificationLogs, customers } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const getAllProducts = () => db.select().from(products).orderBy(products.id);
export const getAllCategories = () => db.select().from(categories).orderBy(categories.id);

export async function getProductBySlug(slug: string) {
  const [p] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return p || null;
}
export const getReviewsForProduct = (productId: number) => db.select().from(reviews).where(eq(reviews.productId, productId)).orderBy(desc(reviews.createdAt));
export const getQuestionsForProduct = (productId: number) => db.select().from(questions).where(eq(questions.productId, productId)).orderBy(desc(questions.createdAt));

export async function getOrderByOrderId(orderId: string) {
  const [o] = await db.select().from(orders).where(eq(orders.orderId, orderId)).limit(1);
  return o || null;
}
export const getOrdersByEmail = (email: string) => db.select().from(orders).where(eq(orders.customerEmail, email.toLowerCase())).orderBy(desc(orders.createdAt));
export const getAllOrders = () => db.select().from(orders).orderBy(desc(orders.createdAt));
export const getAllCoupons = () => db.select().from(coupons).orderBy(coupons.id);
export async function getCouponByCode(code: string) {
  const [c] = await db.select().from(coupons).where(eq(coupons.code, code.toUpperCase().trim())).limit(1);
  return c || null;
}
export const getNotificationLogs = () => db.select().from(notificationLogs).orderBy(desc(notificationLogs.createdAt)).limit(100);
export const getAllCustomers = () => db.select().from(customers).orderBy(desc(customers.createdAt));
export const getAllReviews = () =>
  db.select({ id: reviews.id, author: reviews.author, rating: reviews.rating, title: reviews.title, comment: reviews.comment, createdAt: reviews.createdAt, productName: products.name, productSlug: products.slug })
    .from(reviews).leftJoin(products, eq(reviews.productId, products.id)).orderBy(desc(reviews.id)).limit(100);

export async function getAdminStats() {
  const [{ count: productCount }] = await db.select({ count: sql<number>`count(*)::int` }).from(products);
  const [{ count: lowStock }] = await db.select({ count: sql<number>`count(*)::int` }).from(products).where(sql`${products.stock} <= 5`);
  const [{ count: orderCount, revenue }] = await db.select({ count: sql<number>`count(*)::int`, revenue: sql<string>`coalesce(sum(${orders.total}),0)` }).from(orders);
  const [{ count: pending }] = await db.select({ count: sql<number>`count(*)::int` }).from(orders).where(sql`${orders.status} <> 'Delivered'`);
  const [{ count: delivered }] = await db.select({ count: sql<number>`count(*)::int` }).from(orders).where(eq(orders.status, "Delivered"));
  const [{ count: customerCount }] = await db.select({ count: sql<number>`count(*)::int` }).from(customers);
  return { productCount, lowStock, orderCount, revenue: parseFloat(revenue), pending, delivered, customerCount };
}
