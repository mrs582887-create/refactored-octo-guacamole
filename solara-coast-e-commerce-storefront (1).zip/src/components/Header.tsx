"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { ShoppingBag, Heart, User, Menu, X, Search, GitCompareArrows, Bell, LayoutDashboard, ChevronDown } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { useStore } from "@/lib/store-context";
import { Logo } from "./ui";
import SearchBar from "./SearchBar";
import { DEPARTMENTS, slugify } from "@/db/catalog";
import { cn } from "@/lib/utils";

export default function Header() {
  const { cartCount, wishlist, compare, notifications, setCartOpen, searchOpen, setSearchOpen } = useStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [deptOpen, setDeptOpen] = useState<string | null>(null);
  const pathname = usePathname();
  const unread = notifications.filter((n) => !n.read).length;
  if (pathname?.startsWith("/admin")) return null;

  return (
    <header className="sticky top-0 z-50 bg-white/85 backdrop-blur-xl border-b border-stone-200/60">
      <div className="bg-stone-950 text-stone-300 text-[11px] tracking-wide">
        <div className="mx-auto max-w-7xl px-4 lg:px-8 h-8 flex items-center justify-between">
          <p className="truncate"><span className="text-amber-300 font-semibold">Solara Coast</span> — Everything You Need. One Coast. · Free delivery above ₹999</p>
          <div className="hidden md:flex items-center gap-4">
            <Link href="/track" className="hover:text-white">Track Order</Link>
            <Link href="/admin" className="hover:text-white inline-flex items-center gap-1"><LayoutDashboard className="h-3 w-3" /> Admin</Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="flex h-16 items-center gap-3 lg:gap-6">
          <button onClick={() => setMobileOpen(true)} className="lg:hidden p-2 -ml-2 rounded-full hover:bg-stone-100" aria-label="Menu"><Menu className="h-5 w-5 text-stone-700" /></button>
          <Link href="/" className="shrink-0"><Logo /></Link>

          <div className="hidden md:block flex-1 max-w-2xl mx-auto"><SearchBar /></div>

          <div className="ml-auto flex items-center gap-0.5 sm:gap-1">
            <button onClick={() => setSearchOpen(true)} className="md:hidden p-2.5 rounded-full hover:bg-stone-100" aria-label="Search"><Search className="h-5 w-5 text-stone-700" /></button>
            <Link href="/compare" className="hidden sm:flex relative p-2.5 rounded-full hover:bg-stone-100" aria-label="Compare">
              <GitCompareArrows className="h-5 w-5 text-stone-700" />
              {compare.length > 0 && <Count n={compare.length} tone="bg-violet-500" />}
            </Link>
            <Link href="/account?tab=notifications" className="hidden sm:flex relative p-2.5 rounded-full hover:bg-stone-100" aria-label="Notifications">
              <Bell className="h-5 w-5 text-stone-700" />
              {unread > 0 && <Count n={unread} tone="bg-amber-500" />}
            </Link>
            <Link href="/wishlist" className="relative p-2.5 rounded-full hover:bg-stone-100" aria-label="Wishlist">
              <Heart className="h-5 w-5 text-stone-700" />
              {wishlist.length > 0 && <Count n={wishlist.length} tone="bg-rose-500" />}
            </Link>
            <Link href="/account" className="hidden sm:flex p-2.5 rounded-full hover:bg-stone-100" aria-label="Account"><User className="h-5 w-5 text-stone-700" /></Link>
            <button onClick={() => setCartOpen(true)} className="relative p-2.5 rounded-full hover:bg-stone-100" aria-label="Cart">
              <ShoppingBag className="h-5 w-5 text-stone-700" />
              {cartCount > 0 && <Count n={cartCount} tone="bg-stone-900" />}
            </button>
          </div>
        </div>

        {/* Department nav */}
        <nav className="hidden lg:flex items-center gap-1 h-11 -mx-2" onMouseLeave={() => setDeptOpen(null)}>
          <Link href="/products" className="px-3 py-1.5 rounded-full text-[13px] font-medium text-stone-900 hover:bg-stone-100">All Products</Link>
          {DEPARTMENTS.map((d) => (
            <div key={d.slug} className="relative" onMouseEnter={() => setDeptOpen(d.slug)}>
              <Link href={`/products?dept=${d.slug}`} className={cn("inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-[13px] text-stone-600 hover:text-stone-900 hover:bg-stone-100", deptOpen === d.slug && "bg-stone-100 text-stone-900")}>
                {d.name} <ChevronDown className="h-3 w-3" />
              </Link>
              <AnimatePresence>
                {deptOpen === d.slug && (
                  <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }} transition={{ duration: 0.15 }} className="absolute left-0 top-full pt-2 z-50">
                    <div className="w-[520px] rounded-2xl bg-white border border-stone-200 shadow-2xl shadow-stone-900/10 p-5 grid grid-cols-3 gap-x-6 gap-y-1.5">
                      <p className="col-span-3 text-[10px] font-bold uppercase tracking-[0.14em] text-amber-600 mb-1">{d.name}</p>
                      {d.categories.map((c) => (
                        <Link key={c} href={`/products?cat=${slugify(c)}`} className="text-[13px] text-stone-600 hover:text-stone-950 py-0.5">{c}</Link>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </nav>
      </div>

      {/* Mobile search overlay */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[80] bg-white p-4">
            <div className="flex items-center gap-2">
              <div className="flex-1"><SearchBar autoFocus onClose={() => setSearchOpen(false)} /></div>
              <button onClick={() => setSearchOpen(false)} className="p-2 rounded-full hover:bg-stone-100"><X className="h-5 w-5" /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMobileOpen(false)} className="fixed inset-0 z-[80] bg-stone-900/30 backdrop-blur-sm" />
            <motion.div initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }} transition={{ type: "spring", damping: 30, stiffness: 300 }} className="fixed left-0 top-0 bottom-0 z-[90] w-[85%] max-w-sm bg-white shadow-2xl overflow-y-auto">
              <div className="flex items-center justify-between p-4 border-b border-stone-100">
                <Logo />
                <button onClick={() => setMobileOpen(false)} className="p-2 rounded-full hover:bg-stone-100"><X className="h-5 w-5" /></button>
              </div>
              <div className="p-4 space-y-1">
                <Link href="/products" onClick={() => setMobileOpen(false)} className="block px-3 py-2.5 rounded-xl font-medium text-stone-900 hover:bg-stone-50">All Products</Link>
                {DEPARTMENTS.map((d) => (
                  <details key={d.slug} className="group">
                    <summary className="flex items-center justify-between px-3 py-2.5 rounded-xl text-stone-800 cursor-pointer hover:bg-stone-50 list-none">{d.name}<ChevronDown className="h-4 w-4 text-stone-400 group-open:rotate-180 transition-transform" /></summary>
                    <div className="pl-5 pb-2 grid grid-cols-2 gap-x-3">
                      {d.categories.map((c) => <Link key={c} href={`/products?cat=${slugify(c)}`} onClick={() => setMobileOpen(false)} className="block py-1.5 text-[13px] text-stone-500">{c}</Link>)}
                    </div>
                  </details>
                ))}
                <div className="pt-3 mt-3 border-t border-stone-100 grid grid-cols-2 gap-2 text-sm">
                  <Link href="/account" onClick={() => setMobileOpen(false)} className="px-3 py-2.5 rounded-xl bg-stone-50 text-stone-800">My Account</Link>
                  <Link href="/track" onClick={() => setMobileOpen(false)} className="px-3 py-2.5 rounded-xl bg-stone-50 text-stone-800">Track Order</Link>
                  <Link href="/compare" onClick={() => setMobileOpen(false)} className="px-3 py-2.5 rounded-xl bg-stone-50 text-stone-800">Compare</Link>
                  <Link href="/admin" onClick={() => setMobileOpen(false)} className="px-3 py-2.5 rounded-xl bg-stone-50 text-stone-800">Admin</Link>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}

function Count({ n, tone }: { n: number; tone: string }) {
  return <span className={cn("absolute top-0.5 right-0.5 min-w-[18px] h-[18px] px-1 flex items-center justify-center rounded-full text-[10px] font-bold text-white ring-2 ring-white", tone)}>{n > 99 ? "99+" : n}</span>;
}
