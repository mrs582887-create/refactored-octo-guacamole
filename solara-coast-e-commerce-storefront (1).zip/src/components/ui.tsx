"use client";

import Link from "next/link";
import { Star, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export function Logo({ dark = false, size = "md" }: { dark?: boolean; size?: "sm" | "md" | "lg" }) {
  const dim = size === "lg" ? "h-11 w-11" : size === "sm" ? "h-7 w-7" : "h-8 w-8";
  const text = size === "lg" ? "text-2xl" : size === "sm" ? "text-base" : "text-xl";
  return (
    <span className="flex items-center gap-2.5 select-none">
      <span className={cn("relative shrink-0", dim)}>
        <motion.span
          className="absolute inset-0 rounded-full bg-[conic-gradient(from_180deg,#f59e0b,#f43f5e,#14b8a6,#f59e0b)]"
          animate={{ rotate: 360 }}
          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
        />
        <span className={cn("absolute inset-[2.5px] rounded-full", dark ? "bg-stone-950" : "bg-white")} />
        <motion.span
          className="absolute left-1/2 top-1/2 h-[38%] w-[38%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-tr from-amber-400 to-rose-400"
          animate={{ scale: [1, 1.15, 1], opacity: [0.9, 1, 0.9] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        />
        <span className={cn("absolute left-[18%] right-[18%] bottom-[22%] h-[2px] rounded-full", dark ? "bg-teal-300/80" : "bg-teal-500/70")} />
      </span>
      <span className="leading-none">
        <span className={cn("block font-[560] tracking-[-0.035em]", text, dark ? "text-white" : "text-stone-900")}>solara<span className="text-stone-400 font-[400]">coast</span></span>
      </span>
    </span>
  );
}

export function Stars({ rating, size = "h-3.5 w-3.5" }: { rating: number | string; size?: string }) {
  const r = typeof rating === "string" ? parseFloat(rating) : rating;
  return (
    <span className="inline-flex items-center gap-0.5 text-amber-400">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} className={cn(size, i <= Math.round(r) ? "fill-current" : "fill-stone-200 text-stone-200")} />
      ))}
    </span>
  );
}

export function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav className="flex items-center flex-wrap gap-1 text-xs text-stone-500 mb-6" aria-label="Breadcrumb">
      <Link href="/" className="hover:text-stone-900 transition-colors">Home</Link>
      {items.map((it, i) => (
        <span key={i} className="flex items-center gap-1">
          <ChevronRight className="h-3 w-3 text-stone-300" />
          {it.href ? <Link href={it.href} className="hover:text-stone-900 transition-colors">{it.label}</Link> : <span className="text-stone-900 font-medium truncate max-w-[220px]">{it.label}</span>}
        </span>
      ))}
    </nav>
  );
}

export function SectionHeader({ eyebrow, title, subtitle, href, hrefLabel = "View all" }: { eyebrow?: string; title: string; subtitle?: string; href?: string; hrefLabel?: string }) {
  return (
    <div className="flex items-end justify-between gap-4 mb-6 md:mb-8">
      <div>
        {eyebrow && <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-amber-600 mb-1.5">{eyebrow}</p>}
        <h2 className="text-2xl md:text-3xl font-[480] tracking-[-0.03em] text-stone-950">{title}</h2>
        {subtitle && <p className="text-sm text-stone-500 mt-1">{subtitle}</p>}
      </div>
      {href && (
        <Link href={href} className="shrink-0 inline-flex items-center gap-1.5 text-sm font-medium text-stone-900 hover:text-rose-600 transition-colors">
          {hrefLabel} <ChevronRight className="h-4 w-4" />
        </Link>
      )}
    </div>
  );
}

export function Badge({ children, tone = "stone", className }: { children: React.ReactNode; tone?: "stone" | "teal" | "amber" | "rose" | "violet"; className?: string }) {
  const tones = {
    stone: "bg-stone-100 text-stone-700",
    teal: "bg-teal-500 text-white",
    amber: "bg-amber-400 text-amber-950",
    rose: "bg-rose-500 text-white",
    violet: "bg-violet-500 text-white",
  };
  return <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide", tones[tone], className)}>{children}</span>;
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("animate-pulse rounded-xl bg-stone-200/70", className)} />;
}

export function ProductSkeletonGrid({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="space-y-3">
          <Skeleton className="aspect-[4/5]" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-3 w-1/2" />
          <Skeleton className="h-5 w-1/3" />
        </div>
      ))}
    </div>
  );
}

export function EmptyState({ icon, title, body, action }: { icon?: React.ReactNode; title: string; body?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-20 px-6">
      {icon && <div className="h-16 w-16 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mb-4">{icon}</div>}
      <h3 className="text-lg font-[500] text-stone-900">{title}</h3>
      {body && <p className="text-sm text-stone-500 mt-1 max-w-sm">{body}</p>}
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

export function DemoTag({ children = "Demo" }: { children?: React.ReactNode }) {
  return <span className="inline-flex items-center rounded-md border border-dashed border-amber-400/70 bg-amber-50 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-700">{children}</span>;
}

export function ConfirmDialog({ open, title, body, confirmLabel = "Confirm", onConfirm, onCancel, danger }: { open: boolean; title: string; body?: string; confirmLabel?: string; onConfirm: () => void; onCancel: () => void; danger?: boolean }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-stone-900/30 backdrop-blur-sm" onClick={onCancel} />
      <motion.div initial={{ opacity: 0, scale: 0.95, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} className="relative w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl">
        <h3 className="text-base font-[550] text-stone-900">{title}</h3>
        {body && <p className="text-sm text-stone-500 mt-2">{body}</p>}
        <div className="mt-6 flex gap-2 justify-end">
          <button onClick={onCancel} className="px-4 py-2 rounded-full text-sm font-medium text-stone-700 hover:bg-stone-100">Cancel</button>
          <button onClick={onConfirm} className={cn("px-4 py-2 rounded-full text-sm font-semibold text-white", danger ? "bg-rose-600 hover:bg-rose-700" : "bg-stone-900 hover:bg-stone-800")}>{confirmLabel}</button>
        </div>
      </motion.div>
    </div>
  );
}
