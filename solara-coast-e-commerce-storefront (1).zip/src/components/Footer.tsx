"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Logo } from "./ui";
import { DEPARTMENTS } from "@/db/catalog";
import { ShieldCheck, Truck, RotateCcw, Headphones } from "lucide-react";

export default function Footer() {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) return null;
  return (
    <footer className="bg-stone-950 text-stone-300 mt-16">
      <div className="mx-auto max-w-7xl px-4 lg:px-8 py-10 grid grid-cols-2 md:grid-cols-4 gap-6 border-b border-stone-900">
        {[{ i: Truck, t: "Free delivery", s: "On orders above ₹999" }, { i: RotateCcw, t: "Easy returns", s: "7–15 day return window" }, { i: ShieldCheck, t: "Secure checkout", s: "Demo payments, no real charge" }, { i: Headphones, t: "24×7 support", s: "Chat with Solara Assistant" }].map((f) => (
          <div key={f.t} className="flex items-start gap-3"><f.i className="h-5 w-5 text-amber-300 shrink-0 mt-0.5" /><div><p className="text-sm font-medium text-white">{f.t}</p><p className="text-xs text-stone-500">{f.s}</p></div></div>
        ))}
      </div>
      <div className="mx-auto max-w-7xl px-4 lg:px-8 py-14 grid grid-cols-2 md:grid-cols-6 gap-10">
        <div className="col-span-2">
          <Logo dark />
          <p className="mt-4 text-sm text-stone-400 leading-relaxed max-w-sm">Everything You Need. One Coast. A premium marketplace for electronics, fashion, home, beauty, grocery and more — designed for everyday luxury.</p>
          <p className="mt-4 text-[11px] text-stone-600">Demo storefront · Integrations run in DEMO MODE unless configured via environment variables.</p>
        </div>
        <div>
          <h4 className="text-[11px] font-bold uppercase tracking-[0.12em] text-stone-500 mb-4">Shop</h4>
          <ul className="space-y-2 text-sm">{DEPARTMENTS.slice(0, 6).map((d) => <li key={d.slug}><Link href={`/products?dept=${d.slug}`} className="hover:text-white">{d.name}</Link></li>)}</ul>
        </div>
        <div>
          <h4 className="text-[11px] font-bold uppercase tracking-[0.12em] text-stone-500 mb-4">More</h4>
          <ul className="space-y-2 text-sm">{DEPARTMENTS.slice(6).map((d) => <li key={d.slug}><Link href={`/products?dept=${d.slug}`} className="hover:text-white">{d.name}</Link></li>)}</ul>
        </div>
        <div>
          <h4 className="text-[11px] font-bold uppercase tracking-[0.12em] text-stone-500 mb-4">Account</h4>
          <ul className="space-y-2 text-sm">
            <li><Link href="/account" className="hover:text-white">My Account</Link></li>
            <li><Link href="/account?tab=orders" className="hover:text-white">My Orders</Link></li>
            <li><Link href="/track" className="hover:text-white">Track Order</Link></li>
            <li><Link href="/wishlist" className="hover:text-white">Wishlist</Link></li>
            <li><Link href="/compare" className="hover:text-white">Compare</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-[11px] font-bold uppercase tracking-[0.12em] text-stone-500 mb-4">Company</h4>
          <ul className="space-y-2 text-sm">
            <li><Link href="/admin" className="hover:text-white">Admin Dashboard</Link></li>
            <li><Link href="/categories" className="hover:text-white">All Categories</Link></li>
            <li><Link href="/products?sort=discount" className="hover:text-white">Deals</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-stone-900">
        <div className="mx-auto max-w-7xl px-4 lg:px-8 py-6 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-stone-500">
          <p>&copy; {new Date().getFullYear()} Solara Coast. All rights reserved.</p>
          <p>Product photography via Pexels · Prices in INR</p>
        </div>
      </div>
    </footer>
  );
}
