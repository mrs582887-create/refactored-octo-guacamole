"use client";

import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { Product } from "@/db/schema";
import ProductCard from "./ProductCard";
import { SectionHeader } from "./ui";

export default function ProductCarousel({ products, title, subtitle, eyebrow, href, dark }: { products: Product[]; title: string; subtitle?: string; eyebrow?: string; href?: string; dark?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  if (products.length === 0) return null;
  const scroll = (dir: number) => ref.current?.scrollBy({ left: dir * (ref.current.clientWidth * 0.8), behavior: "smooth" });
  return (
    <section className={dark ? "bg-stone-950 text-white py-14" : "py-10 md:py-14"}>
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className={dark ? "[&_h2]:text-white [&_p]:text-stone-400 [&_a]:text-white" : ""}>
          <SectionHeader eyebrow={eyebrow} title={title} subtitle={subtitle} href={href} />
        </div>
        <div className="relative group/car">
          <div ref={ref} className="flex gap-4 md:gap-5 overflow-x-auto snap-x snap-mandatory scroll-smooth pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {products.map((p, i) => (
              <div key={p.id} className={`snap-start shrink-0 w-[46%] sm:w-[31%] lg:w-[23%] ${dark ? "[&_.text-stone-900]:text-white [&_.text-stone-400]:text-stone-500" : ""}`}>
                <ProductCard product={p} index={i} />
              </div>
            ))}
          </div>
          <button onClick={() => scroll(-1)} className="hidden md:flex absolute -left-4 top-[35%] h-10 w-10 items-center justify-center rounded-full bg-white shadow-lg ring-1 ring-stone-200 text-stone-700 opacity-0 group-hover/car:opacity-100 transition hover:scale-105" aria-label="Previous"><ChevronLeft className="h-5 w-5" /></button>
          <button onClick={() => scroll(1)} className="hidden md:flex absolute -right-4 top-[35%] h-10 w-10 items-center justify-center rounded-full bg-white shadow-lg ring-1 ring-stone-200 text-stone-700 opacity-0 group-hover/car:opacity-100 transition hover:scale-105" aria-label="Next"><ChevronRight className="h-5 w-5" /></button>
        </div>
      </div>
    </section>
  );
}
