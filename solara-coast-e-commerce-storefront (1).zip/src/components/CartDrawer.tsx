"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { X, Minus, Plus, Trash2, ShoppingBag, Bookmark, Tag, Truck, CheckCircle2, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useStore } from "@/lib/store-context";
import { formatINR, computeTotals, FREE_SHIPPING_THRESHOLD, deliveryDate, fmtDate, type CouponLike } from "@/lib/utils";
import { DemoTag } from "./ui";

export default function CartDrawer() {
  const { cart, saved, cartOpen, setCartOpen, updateQty, removeFromCart, saveForLater, moveToCart, removeSaved, cartSubtotal, couponCode, setCouponCode, toast } = useStore();
  const [code, setCode] = useState("");
  const [coupon, setCoupon] = useState<CouponLike | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (couponCode && !coupon) apply(couponCode, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [couponCode]);

  async function apply(c: string, silent = false) {
    if (!c.trim()) return;
    setBusy(true);
    try {
      const res = await fetch("/api/coupons/validate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: c, subtotal: cartSubtotal }) });
      const data = await res.json();
      if (data.ok) {
        setCoupon(data.coupon);
        setCouponCode(data.coupon.code);
        if (!silent) toast({ title: "Coupon applied", body: data.coupon.description, tone: "success" });
        setMsg({ ok: true, text: data.coupon.description });
      } else {
        setCoupon(null);
        if (!silent) setMsg({ ok: false, text: data.message });
        if (silent) setCouponCode(null);
      }
    } catch {
      setMsg({ ok: false, text: "Could not validate coupon." });
    } finally {
      setBusy(false);
    }
  }

  const totals = computeTotals({ subtotal: cartSubtotal, coupon });
  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - cartSubtotal);
  const progress = Math.min(100, (cartSubtotal / FREE_SHIPPING_THRESHOLD) * 100);

  return (
    <AnimatePresence>
      {cartOpen && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} onClick={() => setCartOpen(false)} className="fixed inset-0 z-[60] bg-stone-900/25 backdrop-blur-sm" />
          <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "spring", damping: 30, stiffness: 300 }} className="fixed right-0 top-0 z-[70] h-full w-full max-w-md bg-white shadow-2xl flex flex-col">
            <div className="flex items-center justify-between px-5 h-16 border-b border-stone-100">
              <h2 className="text-lg font-[520] tracking-[-0.01em] text-stone-900 flex items-center gap-2"><ShoppingBag className="h-5 w-5" /> Cart <span className="text-sm text-stone-400 font-normal">({cart.reduce((s, i) => s + i.qty, 0)})</span></h2>
              <button onClick={() => setCartOpen(false)} className="p-2 hover:bg-stone-100 rounded-full" aria-label="Close cart"><X className="h-5 w-5 text-stone-600" /></button>
            </div>

            {/* Free shipping progress */}
            <div className="px-5 py-3 bg-gradient-to-r from-amber-50 to-teal-50 border-b border-stone-100">
              <div className="flex items-center gap-2 text-xs font-medium text-stone-700">
                <Truck className="h-4 w-4 text-teal-600" />
                {remaining > 0 ? <span>Add <span className="font-bold text-stone-900">{formatINR(remaining)}</span> more to unlock <span className="font-bold text-teal-700">FREE DELIVERY</span></span> : <span className="text-teal-700 font-semibold flex items-center gap-1"><CheckCircle2 className="h-3.5 w-3.5" /> You've unlocked FREE delivery!</span>}
              </div>
              <div className="mt-2 h-1.5 rounded-full bg-white/80 overflow-hidden"><motion.div className="h-full bg-gradient-to-r from-amber-400 to-teal-500" animate={{ width: `${progress}%` }} transition={{ type: "spring", stiffness: 80 }} /></div>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-14 text-center">
                  <div className="h-16 w-16 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mb-4"><ShoppingBag className="h-7 w-7" /></div>
                  <p className="font-medium text-stone-900">Your cart is empty</p>
                  <p className="text-sm text-stone-500 mt-1">Discover something you'll love.</p>
                  <Link href="/products" onClick={() => setCartOpen(false)} className="mt-5 px-5 py-2.5 rounded-full bg-stone-900 text-white text-sm font-medium">Start shopping</Link>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={`${item.productId}-${item.color}-${item.size}`} className="flex gap-3.5">
                    <Link href={`/product/${item.slug}`} onClick={() => setCartOpen(false)} className="h-20 w-20 shrink-0 rounded-xl overflow-hidden bg-stone-100 ring-1 ring-stone-200/60"><img src={item.image} alt={item.name} className="h-full w-full object-cover" /></Link>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <h3 className="text-sm font-medium text-stone-900 leading-snug line-clamp-2">{item.name}</h3>
                          <p className="text-[11px] text-stone-500 mt-0.5">{[item.color, item.size].filter(Boolean).join(" · ") || "Standard"}</p>
                        </div>
                        <button onClick={() => removeFromCart(item.productId, item.color, item.size)} className="p-1.5 hover:bg-rose-50 hover:text-rose-500 rounded-full text-stone-400" aria-label="Remove"><Trash2 className="h-3.5 w-3.5" /></button>
                      </div>
                      <div className="flex items-center justify-between mt-2.5">
                        <div className="flex items-center gap-1.5 bg-stone-100 rounded-full px-1 py-0.5">
                          <button onClick={() => updateQty(item.productId, item.color, item.size, item.qty - 1)} className="p-1.5 hover:bg-white rounded-full" aria-label="Decrease"><Minus className="h-3 w-3" /></button>
                          <span className="text-xs font-semibold w-5 text-center tabular-nums">{item.qty}</span>
                          <button onClick={() => updateQty(item.productId, item.color, item.size, item.qty + 1)} disabled={item.qty >= item.stock} className="p-1.5 hover:bg-white rounded-full disabled:opacity-40" aria-label="Increase"><Plus className="h-3 w-3" /></button>
                        </div>
                        <p className="text-sm font-semibold text-stone-900">{formatINR(parseFloat(item.price) * item.qty)}</p>
                      </div>
                      <button onClick={() => saveForLater(item.productId, item.color, item.size)} className="mt-1.5 text-[11px] text-stone-500 hover:text-stone-900 inline-flex items-center gap-1"><Bookmark className="h-3 w-3" /> Save for later</button>
                    </div>
                  </div>
                ))
              )}

              {saved.length > 0 && (
                <div className="pt-4 border-t border-stone-100">
                  <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-stone-400 mb-3">Saved for later ({saved.length})</p>
                  <div className="space-y-3">
                    {saved.map((item) => (
                      <div key={`s-${item.productId}-${item.color}-${item.size}`} className="flex items-center gap-3">
                        <img src={item.image} alt="" className="h-12 w-12 rounded-lg object-cover bg-stone-100" />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-stone-800 truncate">{item.name}</p>
                          <p className="text-xs font-semibold text-stone-900">{formatINR(item.price)}</p>
                        </div>
                        <button onClick={() => moveToCart(item.productId, item.color, item.size)} className="text-[11px] font-semibold text-teal-700 hover:underline">Move to cart</button>
                        <button onClick={() => removeSaved(item.productId, item.color, item.size)} className="p-1 text-stone-400 hover:text-rose-500"><X className="h-3.5 w-3.5" /></button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <div className="border-t border-stone-100 px-5 py-4 bg-stone-50/60 space-y-3">
                {/* Coupon */}
                <div>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-stone-400" />
                      <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder={coupon ? coupon.code : "Coupon code"} className="w-full h-9 pl-8 pr-3 rounded-lg bg-white border border-stone-200 text-xs uppercase tracking-wide outline-none focus:border-stone-400" />
                    </div>
                    {coupon ? (
                      <button onClick={() => { setCoupon(null); setCouponCode(null); setMsg(null); setCode(""); }} className="h-9 px-3 rounded-lg bg-stone-200 text-xs font-semibold text-stone-700">Remove</button>
                    ) : (
                      <button onClick={() => apply(code)} disabled={busy || !code} className="h-9 px-3 rounded-lg bg-stone-900 text-white text-xs font-semibold disabled:opacity-40">{busy ? "…" : "Apply"}</button>
                    )}
                  </div>
                  <div className="mt-1.5 flex items-center justify-between gap-2">
                    {msg ? <p className={`text-[11px] ${msg.ok ? "text-teal-700" : "text-rose-600"}`}>{msg.text}</p> : <p className="text-[11px] text-stone-400">Try WELCOME10 · SAVE500 · STUDENT15 · FREESHIP</p>}
                    <DemoTag>Demo coupons</DemoTag>
                  </div>
                </div>

                <div className="text-xs space-y-1 text-stone-600">
                  <Row label="Subtotal" value={formatINR(totals.subtotal)} />
                  {totals.discount > 0 && <Row label={`Discount (${coupon?.code})`} value={`- ${formatINR(totals.discount)}`} tone="text-teal-700" />}
                  <Row label="Shipping" value={totals.shipping === 0 ? "FREE" : formatINR(totals.shipping)} tone={totals.shipping === 0 ? "text-teal-700" : ""} />
                  <Row label="Tax (GST 5%)" value={formatINR(totals.tax)} />
                  <div className="flex items-center justify-between pt-2 border-t border-stone-200 text-stone-900"><span className="font-medium text-sm">Total</span><span className="text-lg font-[600]">{formatINR(totals.total)}</span></div>
                  <p className="text-[11px] text-stone-500">Estimated delivery by <span className="font-semibold text-stone-800">{fmtDate(deliveryDate(3), { weekday: "short", day: "numeric", month: "short" })}</span></p>
                </div>

                <Link href="/checkout" onClick={() => setCartOpen(false)} className="flex items-center justify-center gap-2 w-full py-3.5 bg-stone-900 text-white rounded-xl text-sm font-semibold hover:bg-stone-800 transition-colors shadow-lg shadow-stone-900/10">
                  Proceed to Checkout <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function Row({ label, value, tone = "" }: { label: string; value: string; tone?: string }) {
  return <div className="flex items-center justify-between"><span>{label}</span><span className={`font-medium ${tone}`}>{value}</span></div>;
}
