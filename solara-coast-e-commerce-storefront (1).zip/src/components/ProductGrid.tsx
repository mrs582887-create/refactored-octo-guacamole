"use client";

import { useMemo, useState, useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { SlidersHorizontal, X, ChevronDown, Search as SearchIcon } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import type { Product, Category } from "@/db/schema";
import ProductCard from "./ProductCard";
import { EmptyState, Breadcrumbs } from "./ui";
import { searchProducts, num, discountPct, cn, formatINR } from "@/lib/utils";
import { DEPARTMENTS } from "@/db/catalog";
import Link from "next/link";

const SORTS = [
  { id: "relevance", label: "Relevance" },
  { id: "price-asc", label: "Price: Low to High" },
  { id: "price-desc", label: "Price: High to Low" },
  { id: "newest", label: "Newest" },
  { id: "rating", label: "Best Rated" },
  { id: "popular", label: "Most Popular" },
  { id: "discount", label: "Biggest Discount" },
];

export default function ProductGrid({ products, categories }: { products: Product[]; categories: Category[] }) {
  const router = useRouter();
  const sp = useSearchParams();
  const [filtersOpen, setFiltersOpen] = useState(false);

  const get = (k: string) => sp.get(k) || "";
  const q = get("q"), dept = get("dept"), cat = get("cat"), brand = get("brand"), sort = get("sort") || "relevance";
  const min = num(get("min")) || 0, max = num(get("max")) || 0, rating = num(get("rating")) || 0, disc = num(get("discount")) || 0;
  const stock = get("stock"), color = get("color"), size = get("size"), delivery = num(get("delivery")) || 0;

  const setParams = useCallback((patch: Record<string, string | null>) => {
    const p = new URLSearchParams(sp.toString());
    Object.entries(patch).forEach(([k, v]) => (v ? p.set(k, v) : p.delete(k)));
    router.push(`/products?${p.toString()}`, { scroll: false });
  }, [sp, router]);

  const scoped = useMemo(() => {
    let list = products;
    if (dept) list = list.filter((p) => p.departmentSlug === dept);
    if (cat) list = list.filter((p) => p.categorySlug === cat);
    if (q) list = searchProducts(list, q);
    return list;
  }, [products, dept, cat, q]);

  const brands = useMemo(() => Array.from(new Set(scoped.map((p) => p.brand))).sort(), [scoped]);
  const colors = useMemo(() => Array.from(new Set(scoped.flatMap((p) => p.colors || []))).sort().slice(0, 24), [scoped]);
  const sizes = useMemo(() => Array.from(new Set(scoped.flatMap((p) => p.sizes || []))), [scoped]);
  const priceMax = useMemo(() => Math.max(0, ...scoped.map((p) => num(p.price))), [scoped]);

  const filtered = useMemo(() => {
    let list = scoped.filter((p) => {
      const price = num(p.price);
      if (brand && p.brand !== brand) return false;
      if (min && price < min) return false;
      if (max && price > max) return false;
      if (rating && num(p.rating) < rating) return false;
      if (disc && discountPct(p) < disc) return false;
      if (stock === "in" && p.stock <= 0) return false;
      if (stock === "low" && !(p.stock > 0 && p.stock <= 8)) return false;
      if (color && !(p.colors || []).includes(color)) return false;
      if (size && !(p.sizes || []).includes(size)) return false;
      if (delivery && p.deliveryDays > delivery) return false;
      return true;
    });
    list = [...list];
    switch (sort) {
      case "price-asc": list.sort((a, b) => num(a.price) - num(b.price)); break;
      case "price-desc": list.sort((a, b) => num(b.price) - num(a.price)); break;
      case "newest": list.sort((a, b) => Number(b.newArrival) - Number(a.newArrival) || b.id - a.id); break;
      case "rating": list.sort((a, b) => num(b.rating) - num(a.rating) || b.reviewCount - a.reviewCount); break;
      case "popular": list.sort((a, b) => b.soldCount - a.soldCount); break;
      case "discount": list.sort((a, b) => discountPct(b) - discountPct(a)); break;
      default: if (!q) list.sort((a, b) => Number(b.featured) - Number(a.featured) || Number(b.trending) - Number(a.trending) || b.soldCount - a.soldCount);
    }
    return list;
  }, [scoped, brand, min, max, rating, disc, stock, color, size, delivery, sort, q]);

  const activeChips = [
    q && { k: "q", label: `“${q}”` }, dept && { k: "dept", label: DEPARTMENTS.find((d) => d.slug === dept)?.name || dept }, cat && { k: "cat", label: categories.find((c) => c.slug === cat)?.name || cat },
    brand && { k: "brand", label: brand }, (min || max) && { k: "price", label: `${min ? formatINR(min) : "₹0"} – ${max ? formatINR(max) : "any"}` }, rating && { k: "rating", label: `${rating}★ & up` },
    disc && { k: "discount", label: `${disc}%+ off` }, stock && { k: "stock", label: stock === "in" ? "In stock" : "Low stock" }, color && { k: "color", label: color }, size && { k: "size", label: `Size ${size}` }, delivery && { k: "delivery", label: `Delivery ≤ ${delivery}d` },
  ].filter(Boolean) as { k: string; label: string }[];

  const clear = (k: string) => (k === "price" ? setParams({ min: null, max: null }) : setParams({ [k]: null }));
  const title = cat ? categories.find((c) => c.slug === cat)?.name : dept ? DEPARTMENTS.find((d) => d.slug === dept)?.name : q ? `Results for “${q}”` : "All Products";
  const deptCats = dept ? categories.filter((c) => c.departmentSlug === dept) : cat ? categories.filter((c) => c.departmentSlug === categories.find((x) => x.slug === cat)?.departmentSlug) : [];

  const Filters = (
    <div className="space-y-6">
      {deptCats.length > 0 && (
        <FilterBlock title="Category">
          <div className="space-y-1 max-h-56 overflow-y-auto pr-1">
            {deptCats.map((c) => <button key={c.slug} onClick={() => setParams({ cat: c.slug === cat ? null : c.slug, dept: null })} className={cn("block w-full text-left px-2.5 py-1.5 rounded-lg text-[13px]", cat === c.slug ? "bg-stone-900 text-white" : "text-stone-600 hover:bg-stone-100")}>{c.name}</button>)}
          </div>
        </FilterBlock>
      )}
      <FilterBlock title="Price">
        <div className="flex items-center gap-2">
          <input type="number" placeholder="Min" defaultValue={min || ""} onBlur={(e) => setParams({ min: e.target.value || null })} className="w-full h-9 px-2.5 rounded-lg border border-stone-200 text-xs" />
          <span className="text-stone-400">–</span>
          <input type="number" placeholder={`Max ${Math.round(priceMax) || ""}`} defaultValue={max || ""} onBlur={(e) => setParams({ max: e.target.value || null })} className="w-full h-9 px-2.5 rounded-lg border border-stone-200 text-xs" />
        </div>
        <div className="mt-2 flex flex-wrap gap-1.5">{[[0, 999], [1000, 4999], [5000, 19999], [20000, 49999], [50000, 0]].map(([a, b]) => <button key={a} onClick={() => setParams({ min: a ? String(a) : null, max: b ? String(b) : null })} className={cn("px-2.5 py-1 rounded-full text-[11px]", min === a && max === b ? "bg-stone-900 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200")}>{b ? `${formatINR(a)}–${formatINR(b)}` : `${formatINR(a)}+`}</button>)}</div>
      </FilterBlock>
      <FilterBlock title="Brand">
        <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
          {brands.map((b) => <button key={b} onClick={() => setParams({ brand: brand === b ? null : b })} className={cn("block w-full text-left px-2.5 py-1.5 rounded-lg text-[13px]", brand === b ? "bg-stone-900 text-white" : "text-stone-600 hover:bg-stone-100")}>{b}</button>)}
        </div>
      </FilterBlock>
      <FilterBlock title="Customer Rating">
        <div className="flex flex-wrap gap-1.5">{[4.5, 4, 3.5, 3].map((r) => <button key={r} onClick={() => setParams({ rating: rating === r ? null : String(r) })} className={cn("px-2.5 py-1 rounded-full text-[11px]", rating === r ? "bg-stone-900 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200")}>{r}★ & up</button>)}</div>
      </FilterBlock>
      <FilterBlock title="Discount">
        <div className="flex flex-wrap gap-1.5">{[10, 20, 30, 40].map((d) => <button key={d} onClick={() => setParams({ discount: disc === d ? null : String(d) })} className={cn("px-2.5 py-1 rounded-full text-[11px]", disc === d ? "bg-stone-900 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200")}>{d}% or more</button>)}</div>
      </FilterBlock>
      <FilterBlock title="Availability">
        <div className="flex flex-wrap gap-1.5">{[["in", "In stock"], ["low", "Low stock"]].map(([v, l]) => <button key={v} onClick={() => setParams({ stock: stock === v ? null : v })} className={cn("px-2.5 py-1 rounded-full text-[11px]", stock === v ? "bg-stone-900 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200")}>{l}</button>)}</div>
      </FilterBlock>
      <FilterBlock title="Delivery Speed">
        <div className="flex flex-wrap gap-1.5">{[[1, "Next day"], [2, "Within 2 days"], [3, "Within 3 days"]].map(([v, l]) => <button key={v} onClick={() => setParams({ delivery: delivery === v ? null : String(v) })} className={cn("px-2.5 py-1 rounded-full text-[11px]", delivery === v ? "bg-stone-900 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200")}>{l}</button>)}</div>
      </FilterBlock>
      {colors.length > 0 && (
        <FilterBlock title="Color">
          <div className="flex flex-wrap gap-1.5">{colors.map((c) => <button key={c} onClick={() => setParams({ color: color === c ? null : c })} className={cn("px-2.5 py-1 rounded-full text-[11px]", color === c ? "bg-stone-900 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200")}>{c}</button>)}</div>
        </FilterBlock>
      )}
      {sizes.length > 0 && (
        <FilterBlock title="Size">
          <div className="flex flex-wrap gap-1.5">{sizes.map((s) => <button key={s} onClick={() => setParams({ size: size === s ? null : s })} className={cn("px-2.5 py-1 rounded-full text-[11px]", size === s ? "bg-stone-900 text-white" : "bg-stone-100 text-stone-600 hover:bg-stone-200")}>{s}</button>)}</div>
        </FilterBlock>
      )}
    </div>
  );

  return (
    <div>
      <Breadcrumbs items={[{ label: "Products", href: "/products" }, ...(dept || cat ? [{ label: title || "" }] : [])]} />
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-[480] tracking-[-0.03em] text-stone-950">{title}</h1>
          <p className="text-sm text-stone-500 mt-1">{filtered.length} product{filtered.length === 1 ? "" : "s"}{q ? " matched" : ""}</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setFiltersOpen(true)} className="lg:hidden inline-flex items-center gap-2 h-10 px-4 bg-white border border-stone-200 rounded-full text-sm font-medium text-stone-700"><SlidersHorizontal className="h-4 w-4" /> Filters{activeChips.length > 0 && <span className="h-5 w-5 rounded-full bg-stone-900 text-white text-[10px] flex items-center justify-center">{activeChips.length}</span>}</button>
          <div className="relative">
            <select value={sort} onChange={(e) => setParams({ sort: e.target.value === "relevance" ? null : e.target.value })} className="appearance-none h-10 pl-4 pr-9 bg-white border border-stone-200 rounded-full text-sm font-medium text-stone-700 cursor-pointer outline-none focus:ring-2 focus:ring-stone-100">
              {SORTS.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-stone-400 pointer-events-none" />
          </div>
        </div>
      </div>

      {activeChips.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 mb-5">
          {activeChips.map((c) => <button key={c.k} onClick={() => clear(c.k)} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-stone-900 text-white text-xs">{c.label} <X className="h-3 w-3" /></button>)}
          <Link href="/products" className="text-xs text-stone-500 hover:text-stone-900 underline ml-1">Clear all</Link>
        </div>
      )}

      <div className="grid lg:grid-cols-[250px_1fr] gap-8">
        <aside className="hidden lg:block"><div className="sticky top-32 rounded-2xl bg-white border border-stone-200/70 p-5 max-h-[calc(100vh-9rem)] overflow-y-auto">{Filters}</div></aside>
        <div>
          {filtered.length === 0 ? (
            <EmptyState icon={<SearchIcon className="h-7 w-7" />} title="No products found" body="Try removing a filter or searching for a broader term like “laptop” or “shoes”." action={<Link href="/products" className="px-5 py-2.5 rounded-full bg-stone-900 text-white text-sm font-medium">Browse everything</Link>} />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-8 md:gap-x-6">
              {filtered.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
            </div>
          )}
        </div>
      </div>

      <AnimatePresence>
        {filtersOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setFiltersOpen(false)} className="fixed inset-0 z-[80] bg-stone-900/30 backdrop-blur-sm lg:hidden" />
            <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 30, stiffness: 300 }} className="fixed inset-x-0 bottom-0 z-[90] max-h-[85vh] rounded-t-3xl bg-white p-5 overflow-y-auto lg:hidden">
              <div className="flex items-center justify-between mb-4"><h3 className="font-[550]">Filters</h3><button onClick={() => setFiltersOpen(false)} className="p-2 rounded-full hover:bg-stone-100"><X className="h-5 w-5" /></button></div>
              {Filters}
              <button onClick={() => setFiltersOpen(false)} className="mt-6 w-full py-3 rounded-xl bg-stone-900 text-white text-sm font-semibold">Show {filtered.length} results</button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function FilterBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="text-[10px] font-bold uppercase tracking-[0.12em] text-stone-400 mb-2.5">{title}</h4>
      {children}
    </div>
  );
}
