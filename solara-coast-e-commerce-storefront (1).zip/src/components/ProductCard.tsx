"use client";

import Link from "next/link";
import { Heart, GitCompareArrows, ShoppingBag, Zap } from "lucide-react";
import { motion } from "framer-motion";
import type { Product } from "@/db/schema";
import { useStore, toMini } from "@/lib/store-context";
import { formatINR, discountPct, stockStatus, cn } from "@/lib/utils";
import { Stars, Badge } from "./ui";

export default function ProductCard({ product, index = 0, compact = false }: { product: Product; index?: number; compact?: boolean }) {
  const { addToCart, toggleWishlist, inWishlist, toggleCompare, inCompare, toast } = useStore();
  const pct = discountPct(product);
  const stock = stockStatus(product.stock);
  const wished = inWishlist(product.id);
  const compared = inCompare(product.id);

  const quickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    if (product.stock <= 0) return;
    addToCart({ productId: product.id, slug: product.slug, name: product.name, price: product.price, image: product.imageMain, color: product.colors?.[0] || "", size: product.sizes?.[0] || "", stock: product.stock }, { silent: true });
    toast({ title: "Added to cart", body: product.name, tone: "success" });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.45, delay: Math.min(index, 8) * 0.04, ease: "easeOut" }}
      className={cn("group relative flex flex-col h-full", compact && "text-sm")}
    >
      <Link href={`/product/${product.slug}`} className="block">
        <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-stone-100 mb-3 ring-1 ring-stone-200/50">
          <img src={product.imageMain} alt={product.name} loading="lazy" className={cn("h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]", product.stock <= 0 && "grayscale opacity-70")} />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-900/25 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1">
            {pct > 0 && <Badge tone="rose">-{pct}%</Badge>}
            {product.flashDeal && <Badge tone="amber"><Zap className="inline h-2.5 w-2.5 -mt-0.5" /> Deal</Badge>}
            {product.newArrival && <Badge tone="teal">New</Badge>}
            {product.bestSeller && !product.newArrival && <Badge tone="violet">Best</Badge>}
          </div>
          <div className="absolute top-2 right-2 flex flex-col gap-1.5 translate-x-0 sm:translate-x-3 sm:opacity-0 sm:group-hover:translate-x-0 sm:group-hover:opacity-100 transition-all duration-300">
            <button onClick={(e) => { e.preventDefault(); toggleWishlist(toMini(product)); }} className={cn("h-8 w-8 rounded-full bg-white/95 shadow-sm flex items-center justify-center hover:scale-105 transition", wished ? "text-rose-500" : "text-stone-600")} aria-label="Wishlist"><Heart className={cn("h-4 w-4", wished && "fill-current")} /></button>
            <button onClick={(e) => { e.preventDefault(); toggleCompare(toMini(product)); }} className={cn("h-8 w-8 rounded-full bg-white/95 shadow-sm flex items-center justify-center hover:scale-105 transition", compared ? "text-violet-600" : "text-stone-600")} aria-label="Compare"><GitCompareArrows className="h-4 w-4" /></button>
          </div>
          {product.stock <= 0 ? (
            <div className="absolute bottom-2.5 left-2.5 right-2.5 text-center py-1.5 rounded-lg bg-white/90 text-[11px] font-semibold text-rose-600">Out of stock</div>
          ) : (
            <button onClick={quickAdd} className="absolute bottom-2.5 left-2.5 right-2.5 py-2 rounded-xl bg-stone-900 text-white text-xs font-semibold flex items-center justify-center gap-1.5 translate-y-0 sm:translate-y-2 sm:opacity-0 sm:group-hover:translate-y-0 sm:group-hover:opacity-100 transition-all duration-300 hover:bg-stone-800 shadow-lg shadow-stone-900/20"><ShoppingBag className="h-3.5 w-3.5" /> Quick add</button>
          )}
        </div>
      </Link>
      <div className="flex flex-col flex-1">
        <p className="text-[11px] uppercase tracking-[0.08em] text-stone-400 font-medium">{product.brand}</p>
        <Link href={`/product/${product.slug}`} className="mt-0.5 text-[14px] font-[520] text-stone-900 leading-snug line-clamp-2 group-hover:text-rose-600 transition-colors">{product.name}</Link>
        <div className="mt-1.5 flex items-center gap-1.5">
          <Stars rating={product.rating} size="h-3 w-3" />
          <span className="text-[11px] text-stone-500">{product.rating} ({product.reviewCount})</span>
        </div>
        <div className="mt-2 flex items-baseline gap-2 flex-wrap">
          <span className="text-[15px] font-[600] text-stone-900">{formatINR(product.price)}</span>
          {pct > 0 && product.originalPrice && <span className="text-xs text-stone-400 line-through">{formatINR(product.originalPrice)}</span>}
        </div>
        <p className={cn("mt-1 text-[11px] font-medium", stock.key === "low" ? "text-amber-600" : stock.key === "out" ? "text-rose-500" : "text-teal-600")}>{stock.key === "in" ? `Delivery in ${product.deliveryDays} day${product.deliveryDays > 1 ? "s" : ""}` : stock.label}</p>
      </div>
    </motion.div>
  );
}
