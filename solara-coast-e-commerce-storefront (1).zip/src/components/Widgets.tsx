"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, LayoutGrid, Search, Heart, ShoppingBag, ArrowUp, Sparkles, X, Send, CheckCircle2, AlertCircle, Info, User } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { useStore } from "@/lib/store-context";
import { formatINR, cn } from "@/lib/utils";
import { DemoTag } from "./ui";

export function MobileBottomNav() {
  const { cartCount, wishlist, setCartOpen, setSearchOpen } = useStore();
  const pathname = usePathname();
  if (pathname?.startsWith("/admin") || pathname?.startsWith("/checkout")) return null;
  const item = "flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium flex-1 h-full";
  const active = (p: string) => (pathname === p ? "text-stone-900" : "text-stone-500");
  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-50 h-16 bg-white/95 backdrop-blur-xl border-t border-stone-200 flex items-stretch px-2 pb-[env(safe-area-inset-bottom)]">
      <Link href="/" className={cn(item, active("/"))}><Home className="h-5 w-5" />Home</Link>
      <Link href="/categories" className={cn(item, active("/categories"))}><LayoutGrid className="h-5 w-5" />Categories</Link>
      <button onClick={() => setSearchOpen(true)} className={cn(item, "text-stone-500")}><span className="h-11 w-11 -mt-6 rounded-full bg-stone-900 text-white flex items-center justify-center shadow-lg shadow-stone-900/30"><Search className="h-5 w-5" /></span>Search</button>
      <Link href="/wishlist" className={cn(item, active("/wishlist"), "relative")}><span className="relative"><Heart className="h-5 w-5" />{wishlist.length > 0 && <span className="absolute -top-1.5 -right-2 h-4 min-w-4 px-1 rounded-full bg-rose-500 text-white text-[9px] flex items-center justify-center">{wishlist.length}</span>}</span>Wishlist</Link>
      <button onClick={() => setCartOpen(true)} className={cn(item, "text-stone-500")}><span className="relative"><ShoppingBag className="h-5 w-5" />{cartCount > 0 && <span className="absolute -top-1.5 -right-2 h-4 min-w-4 px-1 rounded-full bg-stone-900 text-white text-[9px] flex items-center justify-center">{cartCount}</span>}</span>Cart</button>
      <Link href="/account" className={cn(item, active("/account"))}><User className="h-5 w-5" />Account</Link>
    </nav>
  );
}

export function BackToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const h = () => setShow(window.scrollY > 600);
    window.addEventListener("scroll", h, { passive: true });
    return () => window.removeEventListener("scroll", h);
  }, []);
  return (
    <AnimatePresence>
      {show && (
        <motion.button initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="fixed bottom-24 lg:bottom-6 left-4 lg:left-6 z-40 h-10 w-10 rounded-full bg-white shadow-lg ring-1 ring-stone-200 text-stone-700 flex items-center justify-center hover:bg-stone-50" aria-label="Back to top"><ArrowUp className="h-4 w-4" /></motion.button>
      )}
    </AnimatePresence>
  );
}

export function Toaster() {
  const { toasts, dismissToast } = useStore();
  const icons = { success: <CheckCircle2 className="h-4 w-4 text-teal-500" />, error: <AlertCircle className="h-4 w-4 text-rose-500" />, info: <Info className="h-4 w-4 text-amber-500" /> };
  return (
    <div className="fixed top-20 right-4 z-[120] flex flex-col gap-2 w-[calc(100%-2rem)] max-w-sm pointer-events-none">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div key={t.id} initial={{ opacity: 0, x: 40, scale: 0.95 }} animate={{ opacity: 1, x: 0, scale: 1 }} exit={{ opacity: 0, x: 40, scale: 0.95 }} className="pointer-events-auto flex items-start gap-3 rounded-2xl bg-white/95 backdrop-blur border border-stone-200 shadow-xl shadow-stone-900/10 px-4 py-3">
            <span className="mt-0.5">{icons[t.tone || "info"]}</span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-stone-900">{t.title}</p>
              {t.body && <p className="text-xs text-stone-500 truncate">{t.body}</p>}
            </div>
            <button onClick={() => dismissToast(t.id)} className="text-stone-400 hover:text-stone-700"><X className="h-3.5 w-3.5" /></button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

type Msg = { role: "user" | "assistant"; text: string; products?: { id: number; slug: string; name: string; price: string; image: string; brand: string; rating: string; tagline: string | null }[]; mode?: string };

export function AIAssistant() {
  const { assistantOpen, setAssistantOpen } = useStore();
  const pathname = usePathname();
  const [msgs, setMsgs] = useState<Msg[]>([{ role: "assistant", text: "Hi! I'm your Solara shopping assistant. Tell me what you need — e.g. “a phone under ₹30,000 with a good camera” or “a laptop for programming”." }]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, assistantOpen]);
  if (pathname?.startsWith("/admin")) return null;

  const send = async (text: string) => {
    if (!text.trim() || busy) return;
    setMsgs((m) => [...m, { role: "user", text }]);
    setInput("");
    setBusy(true);
    try {
      const res = await fetch("/api/assistant", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: text }) });
      const data = await res.json();
      setMsgs((m) => [...m, { role: "assistant", text: data.reply, products: data.products, mode: data.mode }]);
    } catch {
      setMsgs((m) => [...m, { role: "assistant", text: "Sorry, I couldn't reach the catalog just now. Please try again." }]);
    } finally { setBusy(false); }
  };

  const chips = ["Phone under ₹30,000 with good camera", "Laptop for programming", "Gift under ₹2,000", "Work from home setup"];

  return (
    <>
      <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => setAssistantOpen(!assistantOpen)} className="fixed bottom-20 lg:bottom-6 right-4 lg:right-6 z-40 h-13 px-4 py-3 rounded-full bg-gradient-to-r from-stone-900 to-stone-800 text-white shadow-2xl shadow-stone-900/30 flex items-center gap-2 ring-1 ring-white/10" aria-label="AI Shopping Assistant">
        <Sparkles className="h-4.5 w-4.5 text-amber-300" /><span className="text-sm font-medium hidden sm:inline">Ask Solara</span>
      </motion.button>
      <AnimatePresence>
        {assistantOpen && (
          <motion.div initial={{ opacity: 0, y: 20, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.98 }} className="fixed bottom-[9.5rem] lg:bottom-20 right-4 lg:right-6 z-40 w-[calc(100%-2rem)] max-w-sm h-[min(560px,70vh)] rounded-3xl bg-white shadow-2xl ring-1 ring-stone-200 flex flex-col overflow-hidden">
            <div className="flex items-center justify-between px-4 h-14 bg-stone-950 text-white">
              <div className="flex items-center gap-2"><Sparkles className="h-4 w-4 text-amber-300" /><span className="text-sm font-medium">Solara Assistant</span><DemoTag>{msgs.some((m) => m.mode === "ai") ? "AI" : "Demo engine"}</DemoTag></div>
              <button onClick={() => setAssistantOpen(false)} className="p-1.5 rounded-full hover:bg-white/10"><X className="h-4 w-4" /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-stone-50">
              {msgs.map((m, i) => (
                <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                  <div className={cn("max-w-[88%] rounded-2xl px-3.5 py-2.5 text-sm", m.role === "user" ? "bg-stone-900 text-white rounded-br-md" : "bg-white text-stone-800 ring-1 ring-stone-200 rounded-bl-md")}>
                    <p>{m.text}</p>
                    {m.products && m.products.length > 0 && (
                      <div className="mt-3 space-y-2">
                        {m.products.map((p) => (
                          <Link key={p.id} href={`/product/${p.slug}`} onClick={() => setAssistantOpen(false)} className="flex items-center gap-2.5 rounded-xl bg-stone-50 hover:bg-stone-100 p-2 ring-1 ring-stone-100">
                            <img src={p.image} alt="" className="h-12 w-12 rounded-lg object-cover" />
                            <div className="min-w-0 flex-1">
                              <p className="text-xs font-medium text-stone-900 truncate">{p.name}</p>
                              <p className="text-[11px] text-stone-500 truncate">{p.tagline}</p>
                              <p className="text-xs font-semibold text-stone-900">{formatINR(p.price)} <span className="text-amber-500">★ {p.rating}</span></p>
                            </div>
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {busy && <div className="flex gap-1 px-3 py-2"><span className="h-2 w-2 rounded-full bg-stone-400 animate-bounce" /><span className="h-2 w-2 rounded-full bg-stone-400 animate-bounce [animation-delay:120ms]" /><span className="h-2 w-2 rounded-full bg-stone-400 animate-bounce [animation-delay:240ms]" /></div>}
              <div ref={endRef} />
            </div>
            <div className="p-3 border-t border-stone-100 bg-white">
              <div className="flex gap-1.5 overflow-x-auto pb-2 [scrollbar-width:none]">{chips.map((c) => <button key={c} onClick={() => send(c)} className="shrink-0 px-2.5 py-1 rounded-full bg-stone-100 hover:bg-stone-200 text-[11px] text-stone-700">{c}</button>)}</div>
              <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex gap-2">
                <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask for a recommendation…" className="flex-1 h-10 px-3.5 rounded-full bg-stone-100 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-stone-200" />
                <button type="submit" disabled={busy} className="h-10 w-10 rounded-full bg-stone-900 text-white flex items-center justify-center disabled:opacity-50"><Send className="h-4 w-4" /></button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
