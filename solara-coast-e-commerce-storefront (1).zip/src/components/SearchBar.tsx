"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Search, Mic, Clock, TrendingUp, Tag, Layers, X, ArrowUpRight } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { useStore } from "@/lib/store-context";
import { POPULAR_SEARCHES, formatINR, cn } from "@/lib/utils";

type Suggest = { products: { id: number; name: string; slug: string; image: string; price: string; brand: string; categoryName: string }[]; total: number; brands: string[]; categories: { name: string; slug: string }[] };

export default function SearchBar({ autoFocus, onClose, className }: { autoFocus?: boolean; onClose?: () => void; className?: string }) {
  const router = useRouter();
  const { recentSearches, addRecentSearch } = useStore();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [data, setData] = useState<Suggest | null>(null);
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  useEffect(() => {
    if (!q.trim()) { setData(null); return; }
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
        setData(await res.json());
      } catch {} finally { setLoading(false); }
    }, 220);
    return () => clearTimeout(t);
  }, [q]);

  const go = (query: string) => {
    if (!query.trim()) return;
    addRecentSearch(query);
    setOpen(false);
    onClose?.();
    router.push(`/products?q=${encodeURIComponent(query)}`);
  };

  const voice = () => {
    setListening(true);
    // Voice search UI (demo): simulates a recognised phrase after a short delay.
    setTimeout(() => { setListening(false); setQ("laptop under ₹50000"); setOpen(true); }, 1600);
  };

  return (
    <div ref={ref} className={cn("relative w-full", className)}>
      <form onSubmit={(e) => { e.preventDefault(); go(q); }} className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-stone-400" />
        <input
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          autoFocus={autoFocus}
          placeholder="Search products, brands, “laptop under ₹50000”…"
          className="w-full h-11 pl-11 pr-24 rounded-full bg-stone-100/80 border border-transparent focus:bg-white focus:border-stone-300 focus:ring-4 focus:ring-stone-100 text-sm text-stone-900 placeholder:text-stone-400 outline-none transition-all"
        />
        <div className="absolute right-1.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
          {q && <button type="button" onClick={() => { setQ(""); setData(null); }} className="p-1.5 rounded-full hover:bg-stone-200 text-stone-400" aria-label="Clear"><X className="h-3.5 w-3.5" /></button>}
          <button type="button" onClick={voice} className={cn("p-2 rounded-full transition-colors", listening ? "bg-rose-500 text-white animate-pulse" : "hover:bg-stone-200 text-stone-500")} aria-label="Voice search"><Mic className="h-4 w-4" /></button>
          <button type="submit" className="h-8 px-3.5 rounded-full bg-stone-900 text-white text-xs font-semibold hover:bg-stone-800">Go</button>
        </div>
      </form>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }} transition={{ duration: 0.15 }} className="absolute left-0 right-0 top-[calc(100%+8px)] z-50 rounded-2xl bg-white border border-stone-200 shadow-2xl shadow-stone-900/10 overflow-hidden max-h-[70vh] overflow-y-auto">
            {listening && <div className="px-5 py-4 text-sm text-rose-600 font-medium flex items-center gap-2"><Mic className="h-4 w-4 animate-pulse" /> Listening… (voice search demo)</div>}
            {!q.trim() ? (
              <div className="p-4 grid sm:grid-cols-2 gap-4">
                {recentSearches.length > 0 && (
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-stone-400 mb-2 flex items-center gap-1.5"><Clock className="h-3 w-3" /> Recent</p>
                    <div className="flex flex-wrap gap-1.5">{recentSearches.map((s) => <button key={s} onClick={() => go(s)} className="px-3 py-1.5 rounded-full bg-stone-100 hover:bg-stone-200 text-xs text-stone-700">{s}</button>)}</div>
                  </div>
                )}
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-stone-400 mb-2 flex items-center gap-1.5"><TrendingUp className="h-3 w-3" /> Popular</p>
                  <div className="flex flex-wrap gap-1.5">{POPULAR_SEARCHES.map((s) => <button key={s} onClick={() => go(s)} className="px-3 py-1.5 rounded-full bg-amber-50 hover:bg-amber-100 text-xs text-amber-800">{s}</button>)}</div>
                </div>
              </div>
            ) : (
              <div>
                {(data?.categories?.length || data?.brands?.length) ? (
                  <div className="px-4 pt-4 pb-2 flex flex-wrap gap-1.5">
                    {data?.categories.map((c) => <Link key={c.slug} href={`/products?cat=${c.slug}`} onClick={() => { setOpen(false); onClose?.(); }} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-teal-50 text-teal-800 text-xs hover:bg-teal-100"><Layers className="h-3 w-3" />{c.name}</Link>)}
                    {data?.brands.map((b) => <Link key={b} href={`/products?brand=${encodeURIComponent(b)}`} onClick={() => { setOpen(false); onClose?.(); }} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-violet-50 text-violet-800 text-xs hover:bg-violet-100"><Tag className="h-3 w-3" />{b}</Link>)}
                  </div>
                ) : null}
                {loading && !data && <div className="px-5 py-4 text-sm text-stone-400">Searching…</div>}
                {data && data.products.length === 0 && <div className="px-5 py-6 text-sm text-stone-500">No matches for “{q}”. Try a broader term.</div>}
                {data?.products.map((p) => (
                  <Link key={p.id} href={`/product/${p.slug}`} onClick={() => { addRecentSearch(q); setOpen(false); onClose?.(); }} className="flex items-center gap-3 px-4 py-2.5 hover:bg-stone-50">
                    <img src={p.image} alt="" className="h-11 w-11 rounded-lg object-cover bg-stone-100" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-stone-900 truncate">{p.name}</p>
                      <p className="text-[11px] text-stone-500">{p.brand} · {p.categoryName}</p>
                    </div>
                    <span className="text-sm font-medium text-stone-900">{formatINR(p.price)}</span>
                  </Link>
                ))}
                {data && data.total > 0 && (
                  <button onClick={() => go(q)} className="w-full flex items-center justify-between px-5 py-3 text-sm font-medium text-stone-900 bg-stone-50 hover:bg-stone-100 border-t border-stone-100">
                    See all {data.total} results for “{q}” <ArrowUpRight className="h-4 w-4" />
                  </button>
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
