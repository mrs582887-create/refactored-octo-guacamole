"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Check, Package, MapPin, CreditCard, Copy } from "lucide-react";
import type { Order } from "@/db/schema";
import { ORDER_STATUSES, formatINR, fmtDate, PAYMENT_METHODS, cn } from "@/lib/utils";
import { useStore } from "@/lib/store-context";

export default function OrderTracking({ order }: { order: Order }) {
  const { toast } = useStore();
  const idx = Math.max(0, ORDER_STATUSES.indexOf(order.status as (typeof ORDER_STATUSES)[number]));
  const history = order.statusHistory || [];
  const at = (s: string) => history.find((h) => h.status === s)?.at;
  const items = order.items || [];

  return (
    <div className="grid lg:grid-cols-[1fr_360px] gap-8">
      <div className="space-y-6">
        <div className="rounded-3xl bg-stone-950 text-white p-6 md:p-8 relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(20,184,166,0.25),transparent_60%)]" />
          <div className="relative flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-stone-400">Order ID</p>
              <div className="flex items-center gap-2 mt-1">
                <h1 className="text-2xl md:text-3xl font-mono font-semibold tracking-tight">{order.orderId}</h1>
                <button onClick={() => { navigator.clipboard.writeText(order.orderId); toast({ title: "Order ID copied", tone: "success" }); }} className="p-1.5 rounded-lg hover:bg-white/10"><Copy className="h-4 w-4" /></button>
              </div>
              <p className="text-sm text-stone-400 mt-2">Placed {fmtDate(order.createdAt, { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-[0.2em] text-stone-400">{order.status === "Delivered" ? "Delivered" : "Estimated delivery"}</p>
              <p className="text-lg font-medium mt-1">{fmtDate(order.expectedDelivery, { weekday: "long", day: "numeric", month: "long" })}</p>
              <span className="inline-block mt-2 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold">{order.status}</span>
            </div>
          </div>
        </div>

        <div className="rounded-3xl bg-white border border-stone-200 p-6 md:p-8">
          <h2 className="text-base font-[550] mb-6">Tracking timeline</h2>
          <ol className="relative">
            {ORDER_STATUSES.map((s, i) => {
              const done = i <= idx, current = i === idx;
              return (
                <li key={s} className="flex gap-4 pb-7 last:pb-0 relative">
                  {i < ORDER_STATUSES.length - 1 && <span className={cn("absolute left-[13px] top-7 bottom-0 w-0.5", i < idx ? "bg-teal-500" : "bg-stone-200")} />}
                  <motion.span initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: i * 0.06 }} className={cn("relative z-10 h-7 w-7 rounded-full flex items-center justify-center shrink-0 ring-4 ring-white", done ? "bg-teal-500 text-white" : "bg-stone-200 text-stone-400", current && order.status !== "Delivered" && "bg-stone-900 text-white animate-pulse")}>
                    {done && !current ? <Check className="h-3.5 w-3.5" /> : current ? <span className="h-2 w-2 rounded-full bg-white" /> : <span className="h-2 w-2 rounded-full bg-stone-400" />}
                  </motion.span>
                  <div className="flex-1 -mt-0.5">
                    <p className={cn("text-sm font-medium", done ? "text-stone-900" : "text-stone-400")}>{s}</p>
                    <p className="text-xs text-stone-500 mt-0.5">{at(s) ? fmtDate(at(s), { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : current ? "In progress" : "Pending"}</p>
                    {history.find((h) => h.status === s)?.note && <p className="text-xs text-stone-500 mt-0.5 italic">{history.find((h) => h.status === s)?.note}</p>}
                  </div>
                </li>
              );
            })}
          </ol>
        </div>

        <div className="rounded-3xl bg-white border border-stone-200 p-6 md:p-8">
          <h2 className="text-base font-[550] mb-4 flex items-center gap-2"><Package className="h-4 w-4" /> Items ({items.reduce((s, i) => s + i.qty, 0)})</h2>
          <div className="divide-y divide-stone-100">
            {items.map((i, k) => (
              <div key={k} className="flex items-center gap-3 py-3">
                <img src={i.image} alt="" className="h-14 w-14 rounded-xl object-cover bg-stone-100" />
                <div className="flex-1 min-w-0"><Link href={`/product/${i.slug}`} className="text-sm font-medium hover:underline line-clamp-1">{i.name}</Link><p className="text-xs text-stone-500">{[i.color, i.size].filter(Boolean).join(" · ")} × {i.qty}</p></div>
                <span className="text-sm font-semibold">{formatINR(i.price * i.qty)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <aside className="space-y-4 lg:sticky lg:top-32 self-start">
        <div className="rounded-3xl bg-white border border-stone-200 p-6">
          <h3 className="text-sm font-[550] flex items-center gap-2 mb-3"><MapPin className="h-4 w-4" /> Delivery address</h3>
          <p className="text-sm text-stone-700 leading-relaxed">{order.address.fullName}<br />{order.address.line1}{order.address.line2 ? `, ${order.address.line2}` : ""}<br />{order.address.city}, {order.address.state} {order.address.pincode}<br />{order.address.country}</p>
          <p className="text-xs text-stone-500 mt-2">{order.customerPhone} · {order.customerEmail}</p>
        </div>
        <div className="rounded-3xl bg-white border border-stone-200 p-6">
          <h3 className="text-sm font-[550] flex items-center gap-2 mb-3"><CreditCard className="h-4 w-4" /> Payment</h3>
          <p className="text-sm">{PAYMENT_METHODS.find((p) => p.id === order.paymentMethod)?.label} <span className="text-[10px] font-semibold uppercase text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded ml-1">{order.paymentMode}</span></p>
          <div className="mt-4 space-y-1.5 text-sm text-stone-600">
            <div className="flex justify-between"><span>Subtotal</span><span>{formatINR(order.subtotal)}</span></div>
            {parseFloat(order.discount) > 0 && <div className="flex justify-between text-teal-700"><span>Discount {order.couponCode && `(${order.couponCode})`}</span><span>- {formatINR(order.discount)}</span></div>}
            <div className="flex justify-between"><span>Shipping</span><span>{parseFloat(order.shipping) === 0 ? "FREE" : formatINR(order.shipping)}</span></div>
            <div className="flex justify-between"><span>Tax</span><span>{formatINR(order.tax)}</span></div>
            <div className="flex justify-between pt-2 border-t border-stone-100 text-stone-900 font-semibold text-base"><span>Total</span><span>{formatINR(order.total)}</span></div>
          </div>
        </div>
        <Link href="/account?tab=orders" className="block text-center text-sm text-stone-600 hover:text-stone-900 underline">View all my orders</Link>
      </aside>
    </div>
  );
}
