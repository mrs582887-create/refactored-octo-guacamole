"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Zap, Timer, Smartphone, Shirt, Sofa, Sparkles, Coffee, BookOpen, Dumbbell, Car, Plane, PawPrint, Home as HomeIcon, GraduationCap, Laptop, Gamepad2, Lightbulb, Luggage } from "lucide-react";
import type { Product } from "@/db/schema";
import { DEPARTMENTS } from "@/db/catalog";
import { useStore } from "@/lib/store-context";
import ProductCarousel from "./ProductCarousel";
import { SectionHeader } from "./ui";
import { formatINR } from "@/lib/utils";

const ICONS: Record<string, React.ElementType> = { smartphone: Smartphone, shirt: Shirt, sofa: Sofa, sparkles: Sparkles, coffee: Coffee, book: BookOpen, dumbbell: Dumbbell, car: Car, plane: Plane, paw: PawPrint, home: HomeIcon };

export function Hero({ featured }: { featured: Product[] }) {
  const [i, setI] = useState(0);
  const slides = featured.slice(0, 4);
  useEffect(() => { const t = setInterval(() => setI((x) => (x + 1) % Math.max(1, slides.length)), 4500); return () => clearInterval(t); }, [slides.length]);
  const cur = slides[i];
  return (
    <section className="relative overflow-hidden bg-stone-950 text-white">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-1/3 -right-1/4 h-[80vh] w-[80vh] rounded-full bg-gradient-to-bl from-rose-500/25 via-amber-400/10 to-transparent blur-3xl" />
        <div className="absolute -bottom-1/3 -left-1/4 h-[70vh] w-[70vh] rounded-full bg-gradient-to-tr from-teal-400/25 via-stone-700/20 to-transparent blur-3xl" />
      </div>
      <div className="relative mx-auto max-w-7xl px-4 lg:px-8 py-16 md:py-24 lg:py-28 grid lg:grid-cols-2 gap-10 items-center">
        <div>
          <motion.p initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="text-xs md:text-sm uppercase tracking-[0.22em] text-amber-200/80 font-medium">Everything You Need. One Coast.</motion.p>
          <motion.h1 initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mt-4 text-[clamp(2.6rem,7vw,5.5rem)] font-[460] leading-[0.95] tracking-[-0.045em]">
            Shop the whole <br /><span className="bg-gradient-to-r from-amber-200 via-rose-200 to-teal-200 bg-clip-text text-transparent">coast.</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-6 text-base md:text-lg text-stone-300/90 max-w-lg leading-relaxed font-light">
            Electronics, fashion, home, beauty, grocery and 100+ curated products across 11 departments — with free delivery above ₹999 and easy returns.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-8 flex flex-wrap gap-3">
            <Link href="/products" className="inline-flex items-center gap-2 px-6 py-3.5 bg-white text-stone-950 rounded-full text-sm font-semibold hover:bg-stone-100 shadow-xl shadow-white/10">Shop all products <ArrowRight className="h-4 w-4" /></Link>
            <Link href="/products?sort=discount" className="inline-flex items-center gap-2 px-6 py-3.5 bg-white/5 text-white rounded-full text-sm font-medium hover:bg-white/10 border border-white/10 backdrop-blur-sm"><Zap className="h-4 w-4 text-amber-300" /> Today's deals</Link>
          </motion.div>
          <div className="mt-10 grid grid-cols-3 gap-4 max-w-md text-center">
            {[["11", "Departments"], ["70+", "Categories"], ["4.7★", "Avg. rating"]].map(([n, l]) => <div key={l} className="rounded-2xl bg-white/5 border border-white/10 py-3"><p className="text-xl font-[560]">{n}</p><p className="text-[11px] text-stone-400 uppercase tracking-wider">{l}</p></div>)}
          </div>
        </div>
        {cur && (
          <div className="relative">
            <motion.div key={cur.id} initial={{ opacity: 0, scale: 0.97, x: 20 }} animate={{ opacity: 1, scale: 1, x: 0 }} transition={{ duration: 0.6 }} className="relative rounded-3xl overflow-hidden ring-1 ring-white/10 shadow-2xl shadow-rose-900/20 aspect-[4/5] max-h-[560px] mx-auto w-full max-w-md">
              <img src={cur.imageMain} alt={cur.name} className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/10 to-transparent" />
              <div className="absolute bottom-5 left-5 right-5">
                <p className="text-[10px] uppercase tracking-[0.18em] text-amber-200/80">{cur.categoryName} · {cur.brand}</p>
                <h3 className="text-2xl font-[520] tracking-[-0.02em] mt-1">{cur.name}</h3>
                <div className="mt-2 flex items-center justify-between">
                  <p className="text-lg font-semibold">{formatINR(cur.price)} {cur.originalPrice && <span className="text-sm text-stone-400 line-through font-normal ml-1">{formatINR(cur.originalPrice)}</span>}</p>
                  <Link href={`/product/${cur.slug}`} className="px-4 py-2 rounded-full bg-white text-stone-950 text-xs font-semibold">View</Link>
                </div>
              </div>
            </motion.div>
            <div className="mt-4 flex justify-center gap-1.5">{slides.map((_, k) => <button key={k} onClick={() => setI(k)} className={`h-1.5 rounded-full transition-all ${k === i ? "w-6 bg-white" : "w-1.5 bg-white/30"}`} aria-label={`Slide ${k + 1}`} />)}</div>
          </div>
        )}
      </div>
    </section>
  );
}

export function FlashDeals({ products }: { products: Product[] }) {
  const [left, setLeft] = useState(0);
  useEffect(() => {
    const end = new Date(); end.setHours(23, 59, 59, 999);
    const tick = () => setLeft(Math.max(0, end.getTime() - Date.now()));
    tick(); const t = setInterval(tick, 1000); return () => clearInterval(t);
  }, []);
  const h = Math.floor(left / 3600000), m = Math.floor((left % 3600000) / 60000), s = Math.floor((left % 60000) / 1000);
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    <section className="mx-auto max-w-7xl px-4 lg:px-8 -mt-8 relative z-10">
      <div className="rounded-3xl bg-white shadow-2xl shadow-stone-200/60 border border-stone-100 p-5 md:p-8">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <div className="flex items-center gap-3">
            <span className="h-10 w-10 rounded-2xl bg-gradient-to-br from-amber-400 to-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-500/30"><Zap className="h-5 w-5" /></span>
            <div><h2 className="text-xl md:text-2xl font-[520] tracking-[-0.02em]">Flash Deals</h2><p className="text-xs text-stone-500">Limited time offers — ends tonight</p></div>
          </div>
          <div className="flex items-center gap-1.5 text-sm font-mono">
            <Timer className="h-4 w-4 text-rose-500 mr-1" />
            {[pad(h), pad(m), pad(s)].map((v, k) => <span key={k} className="flex items-center gap-1.5"><span className="px-2 py-1 rounded-lg bg-stone-950 text-white font-semibold tabular-nums">{v}</span>{k < 2 && <span className="text-stone-400">:</span>}</span>)}
          </div>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-2 snap-x [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {products.map((p) => {
            const pct = p.originalPrice ? Math.round(((parseFloat(p.originalPrice) - parseFloat(p.price)) / parseFloat(p.originalPrice)) * 100) : 0;
            const sold = Math.min(95, 30 + ((p.id * 17) % 60));
            return (
              <Link key={p.id} href={`/product/${p.slug}`} className="snap-start shrink-0 w-[160px] md:w-[200px] group">
                <div className="relative aspect-square rounded-2xl overflow-hidden bg-stone-100 ring-1 ring-stone-200/60">
                  <img src={p.imageMain} alt={p.name} className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold">-{pct}%</span>
                </div>
                <p className="mt-2 text-[13px] font-medium text-stone-900 line-clamp-2 leading-snug">{p.name}</p>
                <p className="text-sm font-semibold">{formatINR(p.price)} <span className="text-xs text-stone-400 line-through font-normal">{formatINR(p.originalPrice || p.price)}</span></p>
                <div className="mt-1.5 h-1.5 rounded-full bg-stone-100 overflow-hidden"><div className="h-full bg-gradient-to-r from-amber-400 to-rose-500" style={{ width: `${sold}%` }} /></div>
                <p className="text-[10px] text-stone-500 mt-1">{sold}% claimed</p>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function PopularCategories() {
  return (
    <section className="mx-auto max-w-7xl px-4 lg:px-8 py-12 md:py-16">
      <SectionHeader eyebrow="Browse" title="Popular Categories" subtitle="Eleven departments, one coast." href="/categories" />
      <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        {DEPARTMENTS.map((d, i) => {
          const Icon = ICONS[d.icon] || HomeIcon;
          return (
            <motion.div key={d.slug} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.03 }}>
              <Link href={`/products?dept=${d.slug}`} className="flex flex-col items-center gap-2.5 rounded-2xl bg-white border border-stone-200/70 p-4 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-stone-200/60 transition-all text-center h-full">
                <span className="h-11 w-11 rounded-xl bg-gradient-to-br from-stone-100 to-stone-50 text-stone-700 flex items-center justify-center ring-1 ring-stone-200/60"><Icon className="h-5 w-5" /></span>
                <span className="text-xs font-medium text-stone-800 leading-tight">{d.name}</span>
                <span className="text-[10px] text-stone-400">{d.categories.length} categories</span>
              </Link>
            </motion.div>
          );
        })}
        <Link href="/categories" className="flex flex-col items-center justify-center gap-1 rounded-2xl bg-stone-950 text-white p-4 hover:bg-stone-900 transition text-center"><span className="text-xs font-semibold">All 70+</span><span className="text-[10px] text-stone-400">categories</span><ArrowRight className="h-4 w-4 mt-1" /></Link>
      </div>
    </section>
  );
}

export function TopBrands({ brands }: { brands: string[] }) {
  return (
    <section className="mx-auto max-w-7xl px-4 lg:px-8 py-6">
      <SectionHeader title="Top Brands" subtitle="Solara Coast originals and trusted partners." />
      <div className="flex gap-3 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {brands.map((b) => (
          <Link key={b} href={`/products?brand=${encodeURIComponent(b)}`} className="shrink-0 px-5 py-3 rounded-2xl bg-white border border-stone-200/70 hover:border-stone-900 transition text-sm font-[560] tracking-[-0.01em] text-stone-800">{b}</Link>
        ))}
      </div>
    </section>
  );
}

export function Collections() {
  const items = [
    { t: "Student Essentials", s: "Laptops, stationery, study gear", href: "/products?q=students", Icon: GraduationCap, bg: "from-amber-100 to-orange-50", ink: "text-amber-900" },
    { t: "Work From Home", s: "Desks, chairs, monitors, keyboards", href: "/products?q=work%20from%20home", Icon: Laptop, bg: "from-teal-100 to-emerald-50", ink: "text-teal-900" },
    { t: "Gaming Zone", s: "Consoles, monitors, mice, laptops", href: "/products?q=gaming", Icon: Gamepad2, bg: "from-violet-100 to-fuchsia-50", ink: "text-violet-900" },
    { t: "Smart Home", s: "Hubs, bulbs, doorbells, lighting", href: "/products?q=smart%20home", Icon: Lightbulb, bg: "from-sky-100 to-blue-50", ink: "text-sky-900" },
    { t: "Travel Essentials", s: "Suitcases, backpacks, adapters", href: "/products?q=travel", Icon: Luggage, bg: "from-rose-100 to-pink-50", ink: "text-rose-900" },
    { t: "Seasonal: Summer Edit", s: "Linen, sandals, sunscreen, coolers", href: "/products?q=summer", Icon: Sparkles, bg: "from-lime-100 to-yellow-50", ink: "text-lime-900" },
  ];
  return (
    <section className="mx-auto max-w-7xl px-4 lg:px-8 py-12 md:py-16">
      <SectionHeader eyebrow="Curated" title="Collections for how you live" subtitle="Hand-picked bundles for students, remote workers, gamers, travellers and more." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((c, i) => (
          <motion.div key={c.t} initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
            <Link href={c.href} className={`group relative flex items-center gap-4 rounded-3xl bg-gradient-to-br ${c.bg} p-6 border border-white/60 hover:shadow-xl hover:shadow-stone-200/60 hover:-translate-y-0.5 transition-all overflow-hidden h-full`}>
              <span className={`h-14 w-14 shrink-0 rounded-2xl bg-white/80 ${c.ink} flex items-center justify-center shadow-sm`}><c.Icon className="h-6 w-6" /></span>
              <div className="flex-1"><h3 className={`text-lg font-[560] tracking-[-0.02em] ${c.ink}`}>{c.t}</h3><p className="text-sm text-stone-600">{c.s}</p></div>
              <ArrowRight className={`h-5 w-5 ${c.ink} opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all`} />
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export function RecentlyViewed({ all }: { all: Product[] }) {
  const { recent, hydrated } = useStore();
  if (!hydrated || recent.length === 0) return null;
  const list = recent.map((r) => all.find((p) => p.id === r.id)).filter(Boolean) as Product[];
  if (list.length === 0) return null;
  return <ProductCarousel products={list} title="Recently Viewed" subtitle="Pick up where you left off." />;
}

export function RecommendedForYou({ all }: { all: Product[] }) {
  const { recent, wishlist, hydrated } = useStore();
  let list: Product[] = [];
  if (hydrated && (recent.length || wishlist.length)) {
    const seeds = [...recent, ...wishlist];
    const seen = new Set(seeds.map((s) => s.id));
    const cats = new Set(seeds.map((s) => s.categoryName).filter(Boolean));
    list = all.filter((p) => !seen.has(p.id) && cats.has(p.categoryName)).slice(0, 8);
    if (list.length < 4) list = [...list, ...all.filter((p) => !seen.has(p.id) && p.trending && !list.includes(p))].slice(0, 8);
  } else {
    list = all.filter((p) => p.trending || p.featured).slice(0, 8);
  }
  return <ProductCarousel products={list} eyebrow="Personalised" title="Recommended For You" subtitle={hydrated && recent.length ? "Based on what you've browsed." : "Popular picks to get you started."} href="/products" />;
}
